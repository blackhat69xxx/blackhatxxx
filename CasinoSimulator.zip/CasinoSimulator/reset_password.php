<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$success = false;
$showResetForm = true;
$showNewPasswordForm = false;

// Check if we have a token in the URL
if (isset($_GET['token']) && isset($_GET['phone'])) {
    $token = $_GET['token'];
    $phone = $_GET['phone'];
    
    // Verify token
    if (verifyPasswordResetToken($phone, $token)) {
        $showResetForm = false;
        $showNewPasswordForm = true;
    } else {
        $errors[] = 'Invalid or expired password reset token. Please request a new one.';
    }
}

// Process password reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_reset'])) {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get and sanitize input
        $phone = cleanInput($_POST['phone']);
        
        // Validate phone number
        if (empty($phone)) {
            $errors[] = 'Phone number is required.';
        } elseif (!validatePhone($phone)) {
            $errors[] = 'Please enter a valid Bangladesh phone number.';
        }
        
        // Check if phone exists
        if (empty($errors)) {
            $db = Database::getInstance();
            $conn = $db->getConnection();
            
            $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
            $stmt->bind_param("s", $phone);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $errors[] = 'No account found with this phone number.';
            } else {
                // Generate reset token
                $token = generatePasswordResetToken($phone);
                
                if ($token) {
                    // In a real application, send the token to the user via SMS
                    // For this demo, we'll just display it
                    $resetLink = SITE_URL . "/reset_password.php?token=$token&phone=$phone";
                    
                    $success = true;
                    $showResetForm = false;
                } else {
                    $errors[] = 'Failed to generate reset token. Please try again.';
                }
            }
        }
    }
}

// Process new password form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_new_password'])) {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get and sanitize input
        $phone = cleanInput($_POST['phone']);
        $token = $_POST['token'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // Validate password
        if (empty($password)) {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        }
        
        // Validate password confirmation
        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }
        
        // Verify token again
        if (!verifyPasswordResetToken($phone, $token)) {
            $errors[] = 'Invalid or expired password reset token. Please request a new one.';
        } else {
            // Reset password
            if (empty($errors)) {
                $result = resetPasswordWithToken($phone, $token, $password);
                
                if ($result['success']) {
                    $success = true;
                    $showNewPasswordForm = false;
                } else {
                    $errors[] = $result['message'];
                }
            }
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
include 'templates/header.php';
?>

<div class="auth-container">
    <?php if ($showResetForm): ?>
        <h2>Reset Your Password</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form id="reset-password-form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            <input type="hidden" name="request_reset" value="1">
            
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="reset-phone" name="phone" class="form-control" placeholder="01XXXXXXXXX" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
                <small class="form-text text-muted">Enter the phone number associated with your account</small>
            </div>
            
            <button type="submit" class="auth-btn glow">Request Password Reset</button>
        </form>
        
    <?php elseif ($showNewPasswordForm): ?>
        <h2>Set New Password</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form id="new-password-form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            <input type="hidden" name="set_new_password" value="1">
            <input type="hidden" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            
            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" id="new-password" name="password" class="form-control" placeholder="Create a new password" required>
                <small class="form-text text-muted">At least 6 characters</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm-new-password" name="confirm_password" class="form-control" placeholder="Confirm your new password" required>
            </div>
            
            <button type="submit" class="auth-btn glow">Set New Password</button>
        </form>
        
    <?php elseif ($success && isset($_POST['request_reset'])): ?>
        <h2>Check Your Phone</h2>
        
        <div class="alert alert-success">
            <p>A password reset link has been generated for your account.</p>
        </div>
        
        <div class="reset-instructions">
            <p>In a real application, we would send a message to your phone.</p>
            <p>For this demo, here is your reset link:</p>
            <a href="<?php echo $resetLink; ?>" class="reset-link"><?php echo $resetLink; ?></a>
        </div>
        
        <div class="auth-links">
            <p><a href="login.php">Back to Login</a></p>
        </div>
        
    <?php elseif ($success && isset($_POST['set_new_password'])): ?>
        <h2>Password Reset Complete</h2>
        
        <div class="alert alert-success">
            <p>Your password has been reset successfully. You can now log in with your new password.</p>
        </div>
        
        <div class="auth-links">
            <a href="login.php" class="btn-3d btn-green">Go to Login</a>
        </div>
    <?php endif; ?>
    
    <?php if ($showResetForm || $showNewPasswordForm): ?>
        <div class="auth-links">
            <p>Remember your password? <a href="login.php">Login here</a></p>
        </div>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
