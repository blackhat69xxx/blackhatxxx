/* Payment Processing JavaScript */

// Initialize payment processing
document.addEventListener("DOMContentLoaded", function() {
    initDepositProcess();
    initWithdrawProcess();
    initTransactionHistory();
});

// Initialize deposit process
function initDepositProcess() {
    const depositForm = document.getElementById('deposit-form');
    if (!depositForm) return;
    
    depositForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateDepositForm()) {
            return;
        }
        
        // Disable submit button to prevent multiple submissions
        const submitButton = depositForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';
        
        // Collect form data
        const formData = new FormData(depositForm);
        
        // Send deposit request
        fetch('includes/ajax/process_deposit.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert('Deposit request submitted successfully. Please complete the payment process.', 'success');
                
                // Show payment instructions
                showPaymentInstructions(data.transaction_id, data.amount, data.payment_method);
                
                // Reset form
                depositForm.reset();
            } else {
                showAlert(data.message || 'Failed to process deposit. Please try again.', 'danger');
            }
        })
        .catch(error => {
            console.error('Error processing deposit:', error);
            showAlert('Error processing deposit. Please try again.', 'danger');
        })
        .finally(() => {
            // Re-enable submit button
            submitButton.disabled = false;
            submitButton.textContent = 'Submit Deposit';
        });
    });
}

// Validate deposit form
function validateDepositForm() {
    let isValid = true;
    const amount = document.getElementById('deposit-amount');
    const transactionId = document.getElementById('transaction-id');
    const paymentMethod = document.getElementById('payment-method');
    
    // Validate amount
    if (!amount.value.trim() || isNaN(amount.value) || parseFloat(amount.value) <= 0) {
        showFormError(amount, 'Please enter a valid amount');
        isValid = false;
    } else {
        clearFormError(amount);
    }
    
    // Validate transaction ID
    if (!transactionId.value.trim()) {
        showFormError(transactionId, 'Transaction ID is required');
        isValid = false;
    } else {
        clearFormError(transactionId);
    }
    
    // Validate payment method
    if (!paymentMethod.value) {
        showAlert('Please select a payment method', 'danger');
        isValid = false;
    }
    
    return isValid;
}

// Show payment instructions after submitting deposit
function showPaymentInstructions(transactionId, amount, paymentMethod) {
    const depositForm = document.getElementById('deposit-form');
    const instructionsContainer = document.createElement('div');
    instructionsContainer.className = 'payment-confirmation';
    
    instructionsContainer.innerHTML = `
        <h3>Deposit Request Submitted</h3>
        <div class="confirmation-details">
            <p><strong>Amount:</strong> ${formatAmount(amount)}</p>
            <p><strong>Payment Method:</strong> ${paymentMethod.toUpperCase()}</p>
            <p><strong>Transaction ID:</strong> ${transactionId}</p>
        </div>
        <div class="confirmation-message">
            <p>Your deposit request has been submitted. Our team will verify your payment and update your balance.</p>
            <p>Please keep your transaction details for reference.</p>
        </div>
        <button type="button" class="btn-3d btn-green" id="back-to-deposit">New Deposit</button>
    `;
    
    // Hide the form and show instructions
    depositForm.style.display = 'none';
    depositForm.parentNode.appendChild(instructionsContainer);
    
    // Add event listener to back button
    document.getElementById('back-to-deposit').addEventListener('click', function() {
        instructionsContainer.remove();
        depositForm.style.display = 'block';
    });
}

// Initialize withdraw process
function initWithdrawProcess() {
    const withdrawForm = document.getElementById('withdraw-form');
    if (!withdrawForm) return;
    
    withdrawForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateWithdrawForm()) {
            return;
        }
        
        // Disable submit button to prevent multiple submissions
        const submitButton = withdrawForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';
        
        // Collect form data
        const formData = new FormData(withdrawForm);
        
        // Send withdraw request
        fetch('includes/ajax/process_withdraw.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert('Withdrawal request submitted successfully.', 'success');
                
                // Show withdrawal confirmation
                showWithdrawConfirmation(data.amount, data.payment_method, data.account);
                
                // Reset form
                withdrawForm.reset();
                
                // Update user balance
                updateUserBalance();
            } else {
                showAlert(data.message || 'Failed to process withdrawal. Please try again.', 'danger');
            }
        })
        .catch(error => {
            console.error('Error processing withdrawal:', error);
            showAlert('Error processing withdrawal. Please try again.', 'danger');
        })
        .finally(() => {
            // Re-enable submit button
            submitButton.disabled = false;
            submitButton.textContent = 'Submit Withdrawal';
        });
    });
}

// Validate withdraw form
function validateWithdrawForm() {
    let isValid = true;
    const amount = document.getElementById('withdraw-amount');
    const account = document.getElementById('account-number');
    const paymentMethod = document.getElementById('withdraw-method');
    
    // Validate amount
    if (!amount.value.trim() || isNaN(amount.value) || parseFloat(amount.value) <= 0) {
        showFormError(amount, 'Please enter a valid amount');
        isValid = false;
    } else {
        clearFormError(amount);
    }
    
    // Validate account number
    if (!account.value.trim()) {
        showFormError(account, 'Account number is required');
        isValid = false;
    } else if (!validatePhoneNumber(account.value.trim())) {
        showFormError(account, 'Please enter a valid mobile account number');
        isValid = false;
    } else {
        clearFormError(account);
    }
    
    // Validate payment method
    if (!paymentMethod.value) {
        showAlert('Please select a payment method', 'danger');
        isValid = false;
    }
    
    return isValid;
}

// Show withdrawal confirmation
function showWithdrawConfirmation(amount, paymentMethod, account) {
    const withdrawForm = document.getElementById('withdraw-form');
    const confirmationContainer = document.createElement('div');
    confirmationContainer.className = 'payment-confirmation';
    
    confirmationContainer.innerHTML = `
        <h3>Withdrawal Request Submitted</h3>
        <div class="confirmation-details">
            <p><strong>Amount:</strong> ${formatAmount(amount)}</p>
            <p><strong>Payment Method:</strong> ${paymentMethod.toUpperCase()}</p>
            <p><strong>Account:</strong> ${account}</p>
        </div>
        <div class="confirmation-message">
            <p>Your withdrawal request has been submitted. Our team will process your request within 24 hours.</p>
            <p>You can check the status in your transaction history.</p>
        </div>
        <button type="button" class="btn-3d btn-green" id="back-to-withdraw">New Withdrawal</button>
    `;
    
    // Hide the form and show confirmation
    withdrawForm.style.display = 'none';
    withdrawForm.parentNode.appendChild(confirmationContainer);
    
    // Add event listener to back button
    document.getElementById('back-to-withdraw').addEventListener('click', function() {
        confirmationContainer.remove();
        withdrawForm.style.display = 'block';
    });
}

// Initialize transaction history
function initTransactionHistory() {
    const transactionTable = document.querySelector('.transaction-table tbody');
    if (!transactionTable) return;
    
    // Load transaction history
    fetch('includes/ajax/get_transactions.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Clear existing rows
                transactionTable.innerHTML = '';
                
                // Add transactions to the table
                data.transactions.forEach(tx => {
                    const row = document.createElement('tr');
                    
                    // Determine amount class
                    let amountClass = '';
                    if (['deposit', 'win', 'refund'].includes(tx.type)) {
                        amountClass = 'amount-positive';
                    } else if (['withdrawal', 'bet'].includes(tx.type)) {
                        amountClass = 'amount-negative';
                    }
                    
                    // Determine status class
                    let statusClass = '';
                    if (tx.status === 'pending') {
                        statusClass = 'status-pending';
                    } else if (tx.status === 'completed') {
                        statusClass = 'status-completed';
                    } else if (tx.status === 'rejected') {
                        statusClass = 'status-rejected';
                    }
                    
                    row.innerHTML = `
                        <td>${tx.id}</td>
                        <td>${formatTransactionType(tx.type)}</td>
                        <td class="${amountClass}">${formatAmount(tx.amount)}</td>
                        <td>${tx.payment_method || '-'}</td>
                        <td class="${statusClass}">${tx.status.toUpperCase()}</td>
                        <td>${new Date(tx.created_at).toLocaleString()}</td>
                    `;
                    
                    transactionTable.appendChild(row);
                });
                
                // Show message if no transactions
                if (data.transactions.length === 0) {
                    const emptyRow = document.createElement('tr');
                    emptyRow.innerHTML = '<td colspan="6" style="text-align: center;">No transactions found</td>';
                    transactionTable.appendChild(emptyRow);
                }
            } else {
                showAlert('Failed to load transaction history', 'danger');
            }
        })
        .catch(error => {
            console.error('Error loading transactions:', error);
            showAlert('Error loading transaction history', 'danger');
        });
}

// Format transaction type for display
function formatTransactionType(type) {
    switch (type) {
        case 'deposit':
            return 'Deposit';
        case 'withdrawal':
            return 'Withdrawal';
        case 'bet':
            return 'Game Bet';
        case 'win':
            return 'Game Win';
        case 'refund':
            return 'Refund';
        default:
            return type.charAt(0).toUpperCase() + type.slice(1);
    }
}

// Update user balance
function updateUserBalance() {
    fetch('includes/ajax/get_balance.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const userBalanceElement = document.querySelector('.user-balance-amount');
                if (userBalanceElement) {
                    userBalanceElement.textContent = data.balance;
                }
            }
        })
        .catch(error => console.error('Error updating balance:', error));
}

// Validate Bangladesh phone number
function validatePhoneNumber(phone) {
    // Bangladesh phone number pattern: starts with 01, followed by 3-9, then 8 more digits
    const regex = /^01[3-9][0-9]{8}$/;
    return regex.test(phone);
}
