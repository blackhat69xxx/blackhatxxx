/* Wingo Game JavaScript */

// Game settings
const GAME_TYPES = {
    WINGO_1MIN: 'wingo_1min',
    WINGO_30SEC: 'wingo_30sec'
};

// Game state
let currentGame = {
    type: GAME_TYPES.WINGO_1MIN,
    roundId: null,
    endTime: null,
    countdown: null,
    selectedBetType: null,
    selectedBetValue: null,
    betAmount: 10 // Default bet amount
};

// Initialize the game
document.addEventListener("DOMContentLoaded", function() {
    initWingoGame();
});

function initWingoGame() {
    // Check if we're on the game page
    const gameBoard = document.querySelector('.game-board');
    if (!gameBoard) return;
    
    // Set up game tabs
    initGameTabs();
    
    // Set up betting options
    initBettingOptions();
    
    // Set up bet amount control
    initBetAmountControl();
    
    // Get initial game data
    loadGameData();
    
    // Set up the game refresh interval (every 5 seconds)
    setInterval(loadGameData, 5000);
    
    // Set up place bet button
    const placeBetButton = document.querySelector('.place-bet-btn');
    if (placeBetButton) {
        placeBetButton.addEventListener('click', placeBet);
    }
    
    // Load game history
    loadGameHistory();
}

// Initialize game tabs
function initGameTabs() {
    const gameTabs = document.querySelectorAll('.game-tab');
    if (gameTabs.length === 0) return;
    
    gameTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            gameTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Update game type
            currentGame.type = this.getAttribute('data-game-type');
            
            // Reset selected bet type
            currentGame.selectedBetType = null;
            currentGame.selectedBetValue = null;
            
            // Update UI to reflect changes
            updateBettingOptionsUI();
            
            // Load game data for the selected game type
            loadGameData();
            
            // Load game history for the selected game type
            loadGameHistory();
        });
    });
    
    // Activate the first tab by default
    gameTabs[0].click();
}

// Initialize betting options
function initBettingOptions() {
    // Color betting options (red/green)
    const colorOptions = document.querySelectorAll('.bet-option.bet-red, .bet-option.bet-green');
    colorOptions.forEach(option => {
        option.addEventListener('click', function() {
            currentGame.selectedBetType = this.classList.contains('bet-red') ? 'red' : 'green';
            currentGame.selectedBetValue = null; // Reset bet value for colors
            updateBettingOptionsUI();
        });
    });
    
    // Big/Small betting options
    const sizeOptions = document.querySelectorAll('.bet-option.bet-big, .bet-option.bet-small');
    sizeOptions.forEach(option => {
        option.addEventListener('click', function() {
            currentGame.selectedBetType = this.classList.contains('bet-big') ? 'big' : 'small';
            currentGame.selectedBetValue = null; // Reset bet value for sizes
            updateBettingOptionsUI();
        });
    });
    
    // Number betting options
    const numberOptions = document.querySelectorAll('.number-option');
    numberOptions.forEach(option => {
        option.addEventListener('click', function() {
            currentGame.selectedBetType = 'number';
            currentGame.selectedBetValue = this.getAttribute('data-number');
            updateBettingOptionsUI();
        });
    });
}

// Update betting options UI based on selection
function updateBettingOptionsUI() {
    // Remove active class from all betting options
    document.querySelectorAll('.bet-option, .number-option').forEach(option => {
        option.classList.remove('active');
    });
    
    // Add active class to the selected option
    if (currentGame.selectedBetType === 'red') {
        document.querySelector('.bet-option.bet-red').classList.add('active');
    } else if (currentGame.selectedBetType === 'green') {
        document.querySelector('.bet-option.bet-green').classList.add('active');
    } else if (currentGame.selectedBetType === 'big') {
        document.querySelector('.bet-option.bet-big').classList.add('active');
    } else if (currentGame.selectedBetType === 'small') {
        document.querySelector('.bet-option.bet-small').classList.add('active');
    } else if (currentGame.selectedBetType === 'number' && currentGame.selectedBetValue) {
        document.querySelector(`.number-option[data-number="${currentGame.selectedBetValue}"]`).classList.add('active');
    }
    
    // Update potential win amount
    updatePotentialWin();
}

// Initialize bet amount control
function initBetAmountControl() {
    const betInput = document.getElementById('bet-amount');
    if (!betInput) return;
    
    // Update bet amount on input change
    betInput.addEventListener('input', function() {
        const amount = parseFloat(this.value);
        if (!isNaN(amount) && amount > 0) {
            currentGame.betAmount = amount;
            updatePotentialWin();
        }
    });
    
    // Quick bet amount buttons
    const amountButtons = document.querySelectorAll('.bet-amount-button');
    amountButtons.forEach(button => {
        button.addEventListener('click', function() {
            const amount = parseFloat(this.getAttribute('data-amount'));
            betInput.value = amount;
            currentGame.betAmount = amount;
            updatePotentialWin();
        });
    });
    
    // Set initial bet amount
    betInput.value = currentGame.betAmount;
}

// Update potential win amount based on bet type and amount
function updatePotentialWin() {
    const potentialWinElement = document.getElementById('potential-win');
    if (!potentialWinElement) return;
    
    let multiplier = 0;
    
    if (currentGame.selectedBetType === 'red' || currentGame.selectedBetType === 'green') {
        multiplier = 2; // 1:1 payout
    } else if (currentGame.selectedBetType === 'number') {
        multiplier = 9; // 8:1 payout
    } else if (currentGame.selectedBetType === 'big' || currentGame.selectedBetType === 'small') {
        multiplier = 2; // 1:1 payout
    }
    
    const potentialWin = currentGame.betAmount * multiplier;
    potentialWinElement.textContent = formatAmount(potentialWin);
}

// Load game data from server
function loadGameData() {
    fetch(`includes/ajax/get_game_data.php?game_type=${currentGame.type}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateGameData(data);
            }
        })
        .catch(error => console.error('Error loading game data:', error));
}

// Update game data in the UI
function updateGameData(data) {
    // Update round info with period format
    const roundIdElement = document.getElementById('game-round-id');
    if (roundIdElement) {
        // Use period if available, otherwise fall back to round_id
        roundIdElement.textContent = data.period || data.round_id;
    }
    
    // Update countdown timer
    currentGame.roundId = data.round_id;
    currentGame.endTime = new Date(data.end_time).getTime();
    
    // Start or update countdown
    if (!currentGame.countdown) {
        startCountdown();
    }
    
    // Update user bets for this round if available
    if (data.user_bets && data.user_bets.length > 0) {
        updateUserBets(data.user_bets);
    }
}

// Start countdown timer
function startCountdown() {
    const countdownElement = document.querySelector('.countdown');
    if (!countdownElement) return;
    
    // Clear any existing countdown
    if (currentGame.countdown) {
        clearInterval(currentGame.countdown);
    }
    
    // Update countdown every second
    currentGame.countdown = setInterval(() => {
        // Get current time
        const now = new Date().getTime();
        
        // Find the distance between now and the end time
        const distance = currentGame.endTime - now;
        
        // If the countdown is over, load new game data
        if (distance < 0) {
            clearInterval(currentGame.countdown);
            currentGame.countdown = null;
            loadGameData();
            return;
        }
        
        // Time calculations for minutes and seconds
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Display the result
        countdownElement.innerHTML = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Add pulse animation when less than 10 seconds remaining
        if (distance < 10000) {
            countdownElement.classList.add('pulse');
        } else {
            countdownElement.classList.remove('pulse');
        }
    }, 1000);
}

// Update user bets display
function updateUserBets(bets) {
    const userBetsContainer = document.getElementById('user-bets');
    if (!userBetsContainer) return;
    
    // Clear existing bets
    userBetsContainer.innerHTML = '';
    
    // Add each bet to the container
    bets.forEach(bet => {
        const betElement = document.createElement('div');
        betElement.className = 'user-bet';
        
        let betType = bet.bet_type;
        if (bet.bet_type === 'number') {
            betType = `Number ${bet.bet_value}`;
        }
        
        betElement.innerHTML = `
            <div class="bet-info">
                <span class="bet-type">${betType.toUpperCase()}</span>
                <span class="bet-amount">${formatAmount(bet.amount)}</span>
            </div>
            <div class="bet-potential-win">
                <span>Potential Win: ${formatAmount(bet.potential_win)}</span>
            </div>
        `;
        
        userBetsContainer.appendChild(betElement);
    });
}

// Load game history
function loadGameHistory() {
    const historyTable = document.querySelector('.history-table tbody');
    if (!historyTable) return;
    
    // Get history for the current game type
    fetch(`includes/ajax/get_game_history.php?game_type=${currentGame.type}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Clear existing history
                historyTable.innerHTML = '';
                
                // Add each round to the history table
                data.rounds.forEach(round => {
                    const row = document.createElement('tr');
                    
                    const resultColorClass = round.result_color === 'red' ? 'result-red' : 'result-green';
                    // Handle PostgreSQL boolean format (could be true/t/1/'1')
                    const isSmall = round.is_small === true || round.is_small === 't' || round.is_small === '1' || round.is_small === 1;
                    const sizeText = isSmall ? 'Small' : 'Big';
                    
                    row.innerHTML = `
                        <td>${round.period || round.id}</td>
                        <td>${round.game_type === 'wingo_1min' ? '1 Min' : '30 Sec'}</td>
                        <td class="${resultColorClass}">${round.result_number}</td>
                        <td class="${resultColorClass}">${round.result_color.toUpperCase()}</td>
                        <td>${sizeText}</td>
                        <td>${new Date(round.end_time).toLocaleTimeString()}</td>
                    `;
                    
                    historyTable.appendChild(row);
                });
            }
        })
        .catch(error => console.error('Error loading game history:', error));
}

// Place a bet
function placeBet() {
    // Validate bet selection
    if (!currentGame.selectedBetType) {
        showAlert('Please select a betting option', 'danger');
        return;
    }
    
    // Validate bet amount
    if (!currentGame.betAmount || currentGame.betAmount <= 0) {
        showAlert('Please enter a valid bet amount', 'danger');
        return;
    }
    
    // Build bet data
    const betData = {
        game_round_id: currentGame.roundId,
        bet_type: currentGame.selectedBetType,
        bet_value: currentGame.selectedBetValue || '',
        amount: currentGame.betAmount
    };
    
    // Send bet request to server
    fetch('includes/ajax/place_bet.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(betData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Bet placed successfully!', 'success');
            
            // Update user balance
            updateUserBalance();
            
            // Refresh game data to show user bets
            loadGameData();
        } else {
            showAlert(data.message || 'Failed to place bet. Please try again.', 'danger');
        }
    })
    .catch(error => {
        console.error('Error placing bet:', error);
        showAlert('Error placing bet. Please try again.', 'danger');
    });
}

// Update user balance after placing a bet
function updateUserBalance() {
    fetch('includes/ajax/get_balance.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const userBalanceElement = document.querySelector('.user-balance-amount');
                if (userBalanceElement) {
                    userBalanceElement.textContent = data.balance;
                    
                    // Add animation for balance update
                    userBalanceElement.classList.add('balance-updated');
                    setTimeout(() => {
                        userBalanceElement.classList.remove('balance-updated');
                    }, 1000);
                }
            }
        })
        .catch(error => console.error('Error updating balance:', error));
}
