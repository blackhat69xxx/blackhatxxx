/* Main JavaScript for BDT-WIN Casino */

// Wait for DOM to be loaded
document.addEventListener("DOMContentLoaded", function() {
    // Initialize UI components
    initUI();
    
    // Initialize real-time balance updates
    initBalanceUpdates();
    
    // Initialize authentication forms
    initAuthForms();
    
    // Initialize captcha if it exists
    initCaptcha();
    
    // Initialize payment methods
    initPaymentMethods();
});

// Initialize UI components
function initUI() {
    // Add active class to current nav link
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.navbar-links a');
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href').split('/').pop();
        if (linkHref === currentPage) {
            link.classList.add('active');
        }
    });
    
    // Mobile navigation toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navbarLinks = document.querySelector('.navbar-links');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            navbarLinks.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', function() {
            const tooltipText = this.getAttribute('data-tooltip');
            const tooltipElement = document.createElement('div');
            tooltipElement.className = 'tooltip';
            tooltipElement.textContent = tooltipText;
            document.body.appendChild(tooltipElement);
            
            const rect = this.getBoundingClientRect();
            tooltipElement.style.top = rect.bottom + 10 + 'px';
            tooltipElement.style.left = rect.left + (rect.width / 2) - (tooltipElement.offsetWidth / 2) + 'px';
            
            this.addEventListener('mouseleave', function() {
                document.body.removeChild(tooltipElement);
            }, { once: true });
        });
    });
}

// Initialize real-time balance updates
function initBalanceUpdates() {
    // Check if user is logged in (balance element exists)
    const userBalanceElement = document.querySelector('.user-balance-amount');
    if (!userBalanceElement) return;
    
    // Update balance every 30 seconds
    function updateBalance() {
        fetch('includes/ajax/get_balance.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    userBalanceElement.textContent = data.balance;
                    
                    // Add animation for balance update
                    userBalanceElement.classList.add('balance-updated');
                    setTimeout(() => {
                        userBalanceElement.classList.remove('balance-updated');
                    }, 1000);
                }
            })
            .catch(error => console.error('Error updating balance:', error));
    }
    
    // Initial update
    updateBalance();
    
    // Set interval for regular updates
    setInterval(updateBalance, 30000);
}

// Initialize authentication forms
function initAuthForms() {
    // Login form validation
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            let isValid = true;
            const phone = document.getElementById('login-phone');
            const password = document.getElementById('login-password');
            
            // Simple validation
            if (!phone.value.trim()) {
                showFormError(phone, 'Phone number is required');
                isValid = false;
            } else if (!validatePhoneNumber(phone.value.trim())) {
                showFormError(phone, 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearFormError(phone);
            }
            
            if (!password.value) {
                showFormError(password, 'Password is required');
                isValid = false;
            } else {
                clearFormError(password);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // Registration form validation
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            let isValid = true;
            const phone = document.getElementById('register-phone');
            const password = document.getElementById('register-password');
            const confirmPassword = document.getElementById('register-confirm-password');
            const captcha = document.getElementById('register-captcha');
            
            // Phone validation
            if (!phone.value.trim()) {
                showFormError(phone, 'Phone number is required');
                isValid = false;
            } else if (!validatePhoneNumber(phone.value.trim())) {
                showFormError(phone, 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearFormError(phone);
            }
            
            // Password validation
            if (!password.value) {
                showFormError(password, 'Password is required');
                isValid = false;
            } else if (password.value.length < 6) {
                showFormError(password, 'Password must be at least 6 characters');
                isValid = false;
            } else {
                clearFormError(password);
            }
            
            // Confirm password validation
            if (!confirmPassword.value) {
                showFormError(confirmPassword, 'Please confirm your password');
                isValid = false;
            } else if (confirmPassword.value !== password.value) {
                showFormError(confirmPassword, 'Passwords do not match');
                isValid = false;
            } else {
                clearFormError(confirmPassword);
            }
            
            // Captcha validation
            if (captcha && !captcha.value.trim()) {
                showFormError(captcha, 'Please enter the captcha code');
                isValid = false;
            } else {
                clearFormError(captcha);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // Reset password form validation
    const resetForm = document.getElementById('reset-password-form');
    if (resetForm) {
        resetForm.addEventListener('submit', function(e) {
            let isValid = true;
            const phone = document.getElementById('reset-phone');
            
            if (!phone.value.trim()) {
                showFormError(phone, 'Phone number is required');
                isValid = false;
            } else if (!validatePhoneNumber(phone.value.trim())) {
                showFormError(phone, 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearFormError(phone);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // New Password form validation
    const newPasswordForm = document.getElementById('new-password-form');
    if (newPasswordForm) {
        newPasswordForm.addEventListener('submit', function(e) {
            let isValid = true;
            const password = document.getElementById('new-password');
            const confirmPassword = document.getElementById('confirm-new-password');
            
            if (!password.value) {
                showFormError(password, 'New password is required');
                isValid = false;
            } else if (password.value.length < 6) {
                showFormError(password, 'Password must be at least 6 characters');
                isValid = false;
            } else {
                clearFormError(password);
            }
            
            if (!confirmPassword.value) {
                showFormError(confirmPassword, 'Please confirm your new password');
                isValid = false;
            } else if (confirmPassword.value !== password.value) {
                showFormError(confirmPassword, 'Passwords do not match');
                isValid = false;
            } else {
                clearFormError(confirmPassword);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
}

// Initialize captcha
function initCaptcha() {
    const captchaImg = document.querySelector('.captcha-img');
    const refreshCaptcha = document.querySelector('.refresh-captcha');
    
    if (captchaImg && refreshCaptcha) {
        refreshCaptcha.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Generate a random string for captcha
            const captchaText = generateRandomString(6);
            captchaImg.textContent = captchaText;
            
            // Store the captcha value in a hidden field
            const captchaValue = document.getElementById('captcha-value');
            if (captchaValue) {
                captchaValue.value = captchaText;
            }
        });
        
        // Trigger initial captcha generation
        refreshCaptcha.click();
    }
}

// Initialize payment methods
function initPaymentMethods() {
    const paymentMethods = document.querySelectorAll('.payment-method');
    if (paymentMethods.length > 0) {
        paymentMethods.forEach(method => {
            method.addEventListener('click', function() {
                // Remove active class from all methods
                paymentMethods.forEach(m => m.classList.remove('active'));
                
                // Add active class to selected method
                this.classList.add('active');
                
                // Update hidden input value
                const paymentMethodInput = document.getElementById('payment-method');
                if (paymentMethodInput) {
                    paymentMethodInput.value = this.getAttribute('data-method');
                }
                
                // Show corresponding instructions
                const methodValue = this.getAttribute('data-method');
                const allInstructions = document.querySelectorAll('.payment-instructions');
                allInstructions.forEach(instr => instr.style.display = 'none');
                
                const selectedInstructions = document.getElementById(`${methodValue}-instructions`);
                if (selectedInstructions) {
                    selectedInstructions.style.display = 'block';
                }
            });
        });
        
        // Activate first payment method by default
        paymentMethods[0].click();
    }
    
    // Payment tabs (deposit/withdraw)
    const paymentTabs = document.querySelectorAll('.payment-tab');
    if (paymentTabs.length > 0) {
        paymentTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs
                paymentTabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to selected tab
                this.classList.add('active');
                
                // Show corresponding form
                const formId = this.getAttribute('data-form');
                const allForms = document.querySelectorAll('.payment-form');
                allForms.forEach(form => form.style.display = 'none');
                
                const selectedForm = document.getElementById(formId);
                if (selectedForm) {
                    selectedForm.style.display = 'block';
                }
            });
        });
        
        // Activate first tab by default
        paymentTabs[0].click();
    }
}

// Helper function to show form error
function showFormError(inputElement, errorMessage) {
    // Clear any existing error
    clearFormError(inputElement);
    
    // Create error element
    const errorElement = document.createElement('div');
    errorElement.className = 'form-error';
    errorElement.textContent = errorMessage;
    
    // Insert error after input
    inputElement.parentNode.appendChild(errorElement);
    
    // Add error class to input
    inputElement.classList.add('is-invalid');
}

// Helper function to clear form error
function clearFormError(inputElement) {
    const parentNode = inputElement.parentNode;
    const errorElement = parentNode.querySelector('.form-error');
    
    if (errorElement) {
        parentNode.removeChild(errorElement);
    }
    
    inputElement.classList.remove('is-invalid');
}

// Validate Bangladesh phone number
function validatePhoneNumber(phone) {
    // Bangladesh phone number pattern: starts with 01, followed by 3-9, then 8 more digits
    const regex = /^01[3-9][0-9]{8}$/;
    return regex.test(phone);
}

// Generate random string for captcha
function generateRandomString(length) {
    const characters = '0123456789';
    let result = '';
    
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    
    return result;
}

// Show alert message
function showAlert(message, type = 'success') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} fade-in`;
    alertContainer.textContent = message;
    
    document.body.appendChild(alertContainer);
    
    // Position the alert at the top center
    alertContainer.style.position = 'fixed';
    alertContainer.style.top = '20px';
    alertContainer.style.left = '50%';
    alertContainer.style.transform = 'translateX(-50%)';
    alertContainer.style.zIndex = '9999';
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertContainer.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(alertContainer);
        }, 500);
    }, 5000);
}

// Format amount with currency
function formatAmount(amount) {
    return parseFloat(amount).toFixed(2) + ' BDT';
}
