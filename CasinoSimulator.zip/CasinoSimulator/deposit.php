<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'deposit.php';
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
include 'templates/header.php';
?>

<div class="payment-container">
    <div class="payment-header">
        <h2>Deposit Funds</h2>
        <p>Add funds to your account using your preferred payment method</p>
    </div>
    
    <div class="payment-tabs">
        <div class="payment-tab active" data-form="deposit-form">Deposit</div>
        <div class="payment-tab" data-form="transaction-history">Transaction History</div>
    </div>
    
    <div class="payment-form" id="deposit-form">
        <h3>Select Payment Method</h3>
        
        <div class="payment-methods">
            <div class="payment-method" data-method="bkash">
                <img src="assets/images/bkash.svg" alt="bKash">
                <span>bKash</span>
            </div>
            <div class="payment-method" data-method="nagad">
                <img src="assets/images/nagad.svg" alt="Nagad">
                <span>Nagad</span>
            </div>
        </div>
        
        <div class="payment-instructions" id="bkash-instructions" style="display: none;">
            <h4>bKash Payment Instructions</h4>
            <ol>
                <li>Open your bKash app</li>
                <li>Go to "Send Money"</li>
                <li>Enter: <strong>01600297503</strong></li>
                <li>Enter the exact amount</li>
                <li>Submit your transaction and note the Transaction ID</li>
                <li>Enter the Transaction ID and your bKash number below</li>
            </ol>
        </div>
        
        <div class="payment-instructions" id="nagad-instructions" style="display: none;">
            <h4>Nagad Payment Instructions</h4>
            <ol>
                <li>Send money to our Nagad number: <strong>01712345678</strong></li>
                <li>Use the Send Money option</li>
                <li>Enter the amount you want to deposit</li>
                <li>Complete the payment using your PIN</li>
                <li>Copy the Transaction ID from your Nagad app</li>
                <li>Enter the Transaction ID and amount below</li>
            </ol>
        </div>
        
        <form id="deposit-form-submit" method="post" action="includes/ajax/process_deposit.php">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            <input type="hidden" name="payment_method" id="payment-method" value="">
            
            <div class="form-group">
                <label for="deposit-amount">Amount (BDT)</label>
                <input type="number" id="deposit-amount" name="amount" class="form-control" min="100" placeholder="Minimum 100 BDT" required>
            </div>
            
            <div class="form-group">
                <label for="sender-phone">Your bKash/Nagad Number</label>
                <input type="text" id="sender-phone" name="sender_phone" class="form-control" placeholder="Enter your payment phone number" required>
                <small class="form-text text-muted">Enter the phone number you used to make the payment</small>
            </div>
            
            <div class="form-group">
                <label for="transaction-id">Transaction ID</label>
                <input type="text" id="transaction-id" name="transaction_id" class="form-control" placeholder="Enter transaction ID from payment app" required>
                <small class="form-text text-muted">Enter the Transaction ID you received after making the payment</small>
            </div>
            
            <button type="submit" class="btn-3d btn-green">Submit Deposit</button>
        </form>
    </div>
    
    <div class="payment-form" id="transaction-history" style="display: none;">
        <h3>Deposit History</h3>
        
        <?php
        // Get deposit transactions
        $db = Database::getInstance();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = :user_id AND type = 'deposit' ORDER BY created_at DESC LIMIT 20");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $deposits = $stmt->fetchAll();
        ?>
        
        <?php if (empty($deposits)): ?>
            <div class="empty-state">
                <p>No deposit transactions found.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="transaction-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Transaction ID</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($deposits as $deposit): ?>
                            <tr>
                                <td><?php echo $deposit['id']; ?></td>
                                <td class="amount-positive"><?php echo formatAmount($deposit['amount']); ?></td>
                                <td><?php echo $deposit['payment_method']; ?></td>
                                <td><?php echo $deposit['transaction_ref']; ?></td>
                                <td class="status-<?php echo $deposit['status']; ?>"><?php echo ucfirst($deposit['status']); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($deposit['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Load payment specific JS -->
<script src="assets/js/payment.js"></script>

<?php
// Include footer
include 'templates/footer.php';
?>
