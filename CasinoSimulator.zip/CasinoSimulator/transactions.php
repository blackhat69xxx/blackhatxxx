<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'transactions.php';
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

// Get filter parameters
$type = isset($_GET['type']) ? $_GET['type'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query
$db = Database::getInstance();
$conn = $db->getConnection();

$query = "SELECT * FROM transactions WHERE user_id = ?";
$countQuery = "SELECT COUNT(*) as total FROM transactions WHERE user_id = ?";
$params = [$userId];
$types = "i";

if (!empty($type)) {
    $query .= " AND type = ?";
    $countQuery .= " AND type = ?";
    $params[] = $type;
    $types .= "s";
}

if (!empty($status)) {
    $query .= " AND status = ?";
    $countQuery .= " AND status = ?";
    $params[] = $status;
    $types .= "s";
}

// Add sorting and pagination
$query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

// Prepare and execute count query
$stmt = $conn->prepare($countQuery);
if (!empty($params)) {
    $typesCopy = substr($types, 0, -2); // Remove the 'ii' for limit and offset
    $paramsCopy = array_slice($params, 0, -2); // Remove limit and offset params
    $stmt->bind_param($typesCopy, ...$paramsCopy);
}
$stmt->execute();
$totalRecords = $stmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);

// Prepare and execute main query
$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Page title
$pageTitle = 'Transaction History';

// Include header
include 'templates/header.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="transaction-header">
                <h2>Transaction History</h2>
                <div class="transaction-actions">
                    <a href="deposit.php" class="btn-3d btn-green">Deposit</a>
                    <a href="withdraw.php" class="btn-3d btn-red">Withdraw</a>
                </div>
            </div>
            
            <div class="filter-section">
                <form method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="filter-form">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="type">Transaction Type:</label>
                            <select name="type" id="type" class="form-control">
                                <option value="">All Types</option>
                                <option value="deposit" <?php echo $type === 'deposit' ? 'selected' : ''; ?>>Deposit</option>
                                <option value="withdrawal" <?php echo $type === 'withdrawal' ? 'selected' : ''; ?>>Withdrawal</option>
                                <option value="bet" <?php echo $type === 'bet' ? 'selected' : ''; ?>>Bet</option>
                                <option value="win" <?php echo $type === 'win' ? 'selected' : ''; ?>>Win</option>
                                <option value="refund" <?php echo $type === 'refund' ? 'selected' : ''; ?>>Refund</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="status">Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">All Status</option>
                                <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3 d-flex align-items-end">
                            <button type="submit" class="btn-3d btn-green mr-2">Filter</button>
                            <a href="transactions.php" class="btn-3d btn-red">Reset</a>
                        </div>
                    </div>
                </form>
            </div>
            
            <div class="transaction-history">
                <?php if (empty($transactions)): ?>
                    <div class="empty-state">
                        <p>No transactions found.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Reference</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $tx): ?>
                                    <tr>
                                        <td><?php echo $tx['id']; ?></td>
                                        <td>
                                            <?php 
                                                switch ($tx['type']) {
                                                    case 'deposit':
                                                        echo 'Deposit';
                                                        break;
                                                    case 'withdrawal':
                                                        echo 'Withdrawal';
                                                        break;
                                                    case 'bet':
                                                        echo 'Game Bet';
                                                        break;
                                                    case 'win':
                                                        echo 'Game Win';
                                                        break;
                                                    case 'refund':
                                                        echo 'Refund';
                                                        break;
                                                    default:
                                                        echo ucfirst($tx['type']);
                                                }
                                            ?>
                                        </td>
                                        <td class="<?php echo in_array($tx['type'], ['deposit', 'win', 'refund']) ? 'amount-positive' : 'amount-negative'; ?>">
                                            <?php echo formatAmount($tx['amount']); ?>
                                        </td>
                                        <td><?php echo $tx['payment_method'] ? $tx['payment_method'] : '-'; ?></td>
                                        <td><?php echo $tx['transaction_ref'] ? $tx['transaction_ref'] : '-'; ?></td>
                                        <td class="status-<?php echo $tx['status']; ?>"><?php echo ucfirst($tx['status']); ?></td>
                                        <td><?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination-container">
                            <ul class="pagination">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&type=<?php echo $type; ?>&status=<?php echo $status; ?>">Previous</a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&type=<?php echo $type; ?>&status=<?php echo $status; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&type=<?php echo $type; ?>&status=<?php echo $status; ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
