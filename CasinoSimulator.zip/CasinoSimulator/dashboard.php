<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'dashboard.php';
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

// Get recent transactions
$transactions = getUserTransactions($userId, 10);

// Include header
include 'templates/header.php';
?>

<div class="dashboard-container">
    <div class="dashboard-header">
        <h2>My Dashboard</h2>
        <div class="dashboard-actions">
            <a href="wingo_game.php" class="btn-3d btn-red">Play Games</a>
            <a href="deposit.php" class="btn-3d btn-green">Deposit</a>
        </div>
    </div>
    
    <div class="user-stats">
        <div class="stat-card glow">
            <h3>Account Balance</h3>
            <div class="value"><?php echo formatAmount($userData['balance']); ?></div>
        </div>
        <div class="stat-card">
            <h3>Account Status</h3>
            <div class="value status-<?php echo $userData['status']; ?>"><?php echo ucfirst($userData['status']); ?></div>
        </div>
        <div class="stat-card">
            <h3>Member Since</h3>
            <div class="value"><?php echo date('M d, Y', strtotime($userData['created_at'])); ?></div>
        </div>
    </div>
    
    <div class="dashboard-sections">
        <div class="row">
            <div class="col-md-8">
                <!-- Transaction History -->
                <div class="transaction-history">
                    <h3>Recent Transactions</h3>
                    <?php if (empty($transactions)): ?>
                        <div class="empty-state">
                            <p>No transactions found. Start playing or make a deposit!</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="transaction-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $tx): ?>
                                        <tr>
                                            <td><?php echo $tx['id']; ?></td>
                                            <td>
                                                <?php 
                                                    switch ($tx['type']) {
                                                        case 'deposit':
                                                            echo 'Deposit';
                                                            break;
                                                        case 'withdrawal':
                                                            echo 'Withdrawal';
                                                            break;
                                                        case 'bet':
                                                            echo 'Game Bet';
                                                            break;
                                                        case 'win':
                                                            echo 'Game Win';
                                                            break;
                                                        case 'refund':
                                                            echo 'Refund';
                                                            break;
                                                        default:
                                                            echo ucfirst($tx['type']);
                                                    }
                                                ?>
                                            </td>
                                            <td class="<?php echo in_array($tx['type'], ['deposit', 'win', 'refund']) ? 'amount-positive' : 'amount-negative'; ?>">
                                                <?php echo formatAmount($tx['amount']); ?>
                                            </td>
                                            <td><?php echo $tx['payment_method'] ? $tx['payment_method'] : '-'; ?></td>
                                            <td class="status-<?php echo $tx['status']; ?>"><?php echo ucfirst($tx['status']); ?></td>
                                            <td><?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="view-all">
                            <a href="transactions.php">View All Transactions</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h3>Quick Actions</h3>
                    <div class="action-buttons">
                        <a href="deposit.php" class="btn-3d btn-green btn-block">
                            <i class="fa fa-plus-circle"></i> Deposit Funds
                        </a>
                        <a href="withdraw.php" class="btn-3d btn-red btn-block">
                            <i class="fa fa-minus-circle"></i> Withdraw Funds
                        </a>
                        <a href="wingo_game.php?type=wingo_1min" class="btn-3d btn-gold btn-block">
                            <i class="fa fa-dice"></i> Play Wingo 1 Min
                        </a>
                        <a href="wingo_game.php?type=wingo_30sec" class="btn-3d btn-gold btn-block">
                            <i class="fa fa-dice"></i> Play Wingo 30 Sec
                        </a>
                    </div>
                </div>
                
                <!-- Account Info -->
                <div class="account-info">
                    <h3>Account Information</h3>
                    <div class="info-item">
                        <span class="info-label">Phone Number:</span>
                        <span class="info-value"><?php echo $userData['phone']; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Last Login:</span>
                        <span class="info-value"><?php echo $userData['last_login'] ? date('M d, Y H:i', strtotime($userData['last_login'])) : 'First login'; ?></span>
                    </div>
                    <div class="change-password">
                        <a href="change_password.php">Change Password</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
