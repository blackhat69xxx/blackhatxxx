<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'withdraw.php';
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

// Check if user has sufficient balance (minimum 500 BDT)
$minWithdrawAmount = 500;
$hasSufficientBalance = ($userData['balance'] >= $minWithdrawAmount);

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
include 'templates/header.php';
?>

<div class="payment-container">
    <div class="payment-header">
        <h2>Withdraw Funds</h2>
        <p>Withdraw your funds to your preferred payment method</p>
    </div>
    
    <div class="payment-tabs">
        <div class="payment-tab active" data-form="withdraw-form">Withdraw</div>
        <div class="payment-tab" data-form="withdraw-history">Withdrawal History</div>
    </div>
    
    <div class="payment-form" id="withdraw-form">
        <?php if (!$hasSufficientBalance): ?>
            <div class="alert alert-warning">
                <p>You need at least <?php echo formatAmount($minWithdrawAmount); ?> in your account to make a withdrawal.</p>
                <p>Current Balance: <?php echo formatAmount($userData['balance']); ?></p>
                <p><a href="deposit.php" class="btn-3d btn-green">Deposit Funds</a></p>
            </div>
        <?php else: ?>
            <h3>Select Withdrawal Method</h3>
            
            <div class="payment-methods">
                <div class="payment-method" data-method="bkash">
                    <img src="assets/images/bkash.svg" alt="bKash">
                    <span>bKash</span>
                </div>
                <div class="payment-method" data-method="nagad">
                    <img src="assets/images/nagad.svg" alt="Nagad">
                    <span>Nagad</span>
                </div>
            </div>
            
            <div class="account-info">
                <div class="current-balance">
                    <strong>Current Balance:</strong> <span><?php echo formatAmount($userData['balance']); ?></span>
                </div>
                <div class="withdrawal-limits">
                    <strong>Withdrawal Limits:</strong>
                    <ul>
                        <li>Minimum: 500 BDT</li>
                        <li>Maximum: 50,000 BDT per day</li>
                    </ul>
                </div>
            </div>
            
            <form id="withdraw-form-submit" method="post" action="includes/ajax/process_withdraw.php">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                <input type="hidden" name="withdraw_method" id="withdraw-method" value="">
                
                <div class="form-group">
                    <label for="withdraw-amount">Amount (BDT)</label>
                    <input type="number" id="withdraw-amount" name="amount" class="form-control" min="500" max="<?php echo $userData['balance']; ?>" placeholder="Minimum 500 BDT" required>
                    <small class="form-text text-muted">Enter amount between 500 and <?php echo formatAmount($userData['balance']); ?></small>
                </div>
                
                <div class="form-group">
                    <label for="account-number">Account Number</label>
                    <input type="text" id="account-number" name="account_number" class="form-control" placeholder="Enter your mobile number" required>
                    <small class="form-text text-muted">Enter the phone number associated with your payment account</small>
                </div>
                
                <button type="submit" class="btn-3d btn-red">Submit Withdrawal</button>
            </form>
            
            <div class="withdrawal-note">
                <p><strong>Note:</strong> Withdrawals are processed within 24 hours. You will receive funds in your selected account once approved.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="payment-form" id="withdraw-history" style="display: none;">
        <h3>Withdrawal History</h3>
        
        <?php
        // Get withdrawal transactions
        $db = Database::getInstance();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = :user_id AND type = 'withdrawal' ORDER BY created_at DESC LIMIT 20");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $withdrawals = $stmt->fetchAll();
        ?>
        
        <?php if (empty($withdrawals)): ?>
            <div class="empty-state">
                <p>No withdrawal transactions found.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="transaction-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Account</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($withdrawals as $withdrawal): ?>
                            <tr>
                                <td><?php echo $withdrawal['id']; ?></td>
                                <td class="amount-negative"><?php echo formatAmount($withdrawal['amount']); ?></td>
                                <td><?php echo $withdrawal['payment_method']; ?></td>
                                <td><?php echo $withdrawal['transaction_ref']; ?></td>
                                <td class="status-<?php echo $withdrawal['status']; ?>"><?php echo ucfirst($withdrawal['status']); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($withdrawal['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Load payment specific JS -->
<script src="assets/js/payment.js"></script>

<?php
// Include footer
include 'templates/footer.php';
?>
