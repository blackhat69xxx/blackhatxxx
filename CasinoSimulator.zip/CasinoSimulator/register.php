<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$success = false;

// Process registration form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get and sanitize input
        $phone = cleanInput($_POST['phone']);
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        $captcha = cleanInput($_POST['captcha']);
        $captchaValue = $_POST['captcha_value'];
        
        // Validate phone number
        if (empty($phone)) {
            $errors[] = 'Phone number is required.';
        } elseif (!validatePhone($phone)) {
            $errors[] = 'Please enter a valid Bangladesh phone number.';
        }
        
        // Validate password
        if (empty($password)) {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        }
        
        // Validate password confirmation
        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }
        
        // Validate captcha
        if (empty($captcha)) {
            $errors[] = 'Captcha is required.';
        } elseif ($captcha !== $captchaValue) {
            $errors[] = 'Incorrect captcha, please try again.';
        }
        
        // Register user if no errors
        if (empty($errors)) {
            $result = registerUser($phone, $password);
            
            if ($result['success']) {
                // Auto-login the user
                $_SESSION['user_id'] = $result['user_id'];
                $_SESSION['login_time'] = time();
                
                // Redirect to dashboard
                header('Location: dashboard.php');
                exit;
            } else {
                $errors[] = $result['message'];
            }
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
include 'templates/header.php';
?>

<div class="auth-container">
    <h2>Create an Account</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <form id="register-form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
        <input type="hidden" name="captcha_value" id="captcha-value" value="">
        
        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text" id="register-phone" name="phone" class="form-control" placeholder="01XXXXXXXXX" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
            <small class="form-text text-muted">Enter your Bangladesh phone number (e.g., 01712345678)</small>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="register-password" name="password" class="form-control" placeholder="Create a strong password" required>
            <small class="form-text text-muted">At least 6 characters</small>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="register-confirm-password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
        </div>
        
        <div class="captcha-container">
            <label>Security Verification</label>
            <div class="captcha-img" id="captcha-image"></div>
            <a href="#" class="refresh-captcha">Refresh Captcha</a>
            <input type="text" id="register-captcha" name="captcha" class="form-control" placeholder="Enter the code above" required>
        </div>
        
        <button type="submit" class="auth-btn glow">Register</button>
    </form>
    
    <div class="auth-links">
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
