<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    
    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">
            <a href="index.php" class="logo-text">
                <span class="bdt-text">BDT-</span><span class="win-text">WIN</span>
            </a>
        </div>
        
        <div class="navbar-links">
            <a href="index.php">Home</a>
            <a href="wingo_game.php">Games</a>
            <a href="deposit.php">Deposit</a>
            <a href="withdraw.php">Withdraw</a>
            <?php if (isLoggedIn()): ?>
                <a href="dashboard.php">Dashboard</a>
            <?php endif; ?>
        </div>
        
        <div class="navbar-account">
            <?php if (isLoggedIn() && isset($userData)): ?>
                <div class="user-balance">
                    Balance: <span class="user-balance-amount"><?php echo formatAmount($userData['balance']); ?></span>
                </div>
                <a href="logout.php" class="btn-3d btn-red">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn-3d btn-green">Login</a>
                <a href="register.php" class="btn-3d btn-red">Register</a>
            <?php endif; ?>
        </div>
        
        <div class="mobile-menu-btn">
            <span></span>
        </div>
    </nav>
    
    <!-- Main Content -->
    <main>
