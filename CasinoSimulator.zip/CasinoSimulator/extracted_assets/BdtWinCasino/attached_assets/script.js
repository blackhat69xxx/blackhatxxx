function showForm(formName) {
  document.querySelectorAll('form').forEach(form => form.classList.remove('active'));
  document.getElementById(formName + 'Form').classList.add('active');

  document.querySelectorAll('.tabs div').forEach(tab => tab.classList.remove('active'));
  if (formName !== 'forgot') {
    document.querySelector(`.tabs div:nth-child(${formName === 'login' ? '1' : '2'})`).classList.add('active');
  }
}

// Canvas Background Animation
function initCanvas() {
  const canvas = document.getElementById('bgCanvas');
  const ctx = canvas.getContext('2d');
  
  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  const particles = [];
  const particleCount = 50;

  for(let i = 0; i < particleCount; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      size: Math.random() * 3 + 1,
      speedX: Math.random() * 1 - 0.5,
      speedY: Math.random() * 1 - 0.5
    });
  }

  function drawParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#0a0f2c';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    particles.forEach(particle => {
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 215, 0, 0.3)';
      ctx.fill();
      
      // Update position
      particle.x += particle.speedX;
      particle.y += particle.speedY;
      
      // Wrap around screen
      if(particle.x < 0) particle.x = canvas.width;
      if(particle.x > canvas.width) particle.x = 0;
      if(particle.y < 0) particle.y = canvas.height;
      if(particle.y > canvas.height) particle.y = 0;
    });
    
    // Draw connections
    particles.forEach((p1, i) => {
      particles.slice(i + 1).forEach(p2 => {
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if(distance < 100) {
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(255, 215, 0, ${0.2 * (1 - distance/100)})`;
          ctx.stroke();
        }
      });
    });
    
    requestAnimationFrame(drawParticles);
  }
  
  drawParticles();
}

function toggleSupport() {
  const popup = document.getElementById('supportPopup');
  popup.style.display = popup.style.display === 'none' ? 'block' : 'none';
}

function sendMessage() {
  const input = document.getElementById('messageInput');
  const messages = document.getElementById('supportMessages');
  
  if (input.value.trim()) {
    // Add user message
    const userMsg = document.createElement('div');
    userMsg.className = 'message user';
    userMsg.textContent = input.value;
    messages.appendChild(userMsg);
    
    // Clear input
    input.value = '';
    
    // Simulate support reply
    setTimeout(() => {
      const supportMsg = document.createElement('div');
      supportMsg.className = 'message support';
      supportMsg.textContent = "Thank you for your message. Our support team will get back to you soon.";
      messages.appendChild(supportMsg);
      messages.scrollTop = messages.scrollHeight;
    }, 1000);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initCanvas();
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const forgotForm = document.getElementById('forgotForm');
    const toggleBtns = document.querySelectorAll('.toggle-btn');
    const forgotBtn = document.getElementById('forgotBtn');
    const backToLogin = document.getElementById('backToLogin');

    // Form toggle functionality
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const formName = btn.dataset.form;
            showForm(formName);
            toggleBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // Forgot password toggle
    forgotBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showForm('forgot');
    });

    backToLogin.addEventListener('click', () => {
        showForm('login');
    });

    const forms = document.querySelectorAll('form');

    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const password = form.querySelector('input[name="password"]');
            const confirmPassword = form.querySelector('input[name="confirm_password"]');
            
            if (password && password.value.length < 6) {
                alert('Password must be at least 6 characters long');
                return;
            }
            
            if (confirmPassword && password.value !== confirmPassword.value) {
                alert('Passwords do not match');
                return;
            }
            
            console.log('Form submitted:', form.id);
        });

        // Password validation on input
        const passwordInputs = form.querySelectorAll('input[type="password"]');
        passwordInputs.forEach(input => {
            input.addEventListener('input', () => {
                if (input.value.length < 6) {
                    input.style.borderColor = 'red';
                    input.style.boxShadow = '0 0 5px rgba(255, 0, 0, 0.4)';
                } else {
                    input.style.borderColor = 'rgb(255, 215, 0)';
                    input.style.boxShadow = '0 0 5px rgba(255, 215, 0, 0.4)';
                }
            });
        });

        const phoneInput = form.querySelector('input[name="phone"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 10) {
                    value = value.slice(0, 10);
                }
                e.target.value = value;
            });
        }
    });
});