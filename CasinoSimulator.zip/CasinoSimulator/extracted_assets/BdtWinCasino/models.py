import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    balance = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    transactions = db.relationship('Transaction', backref='user', lazy=True)
    bets = db.relationship('Bet', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # 'deposit' or 'withdrawal'
    status = db.Column(db.String(20), default='pending')  # 'pending', 'approved', 'rejected'
    payment_method = db.Column(db.String(20))  # 'bKash', 'Nagad', etc.
    payment_details = db.Column(db.String(255))  # Transaction ID, phone number, etc.
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class GameResult(db.Model):
    __tablename__ = 'game_results'
    
    id = db.Column(db.Integer, primary_key=True)
    game_type = db.Column(db.String(20), nullable=False)  # '1min' or '30s'
    result_number = db.Column(db.Integer, nullable=False)  # The actual number result
    is_red = db.Column(db.Boolean)  # True if red, False if green
    is_big = db.Column(db.Boolean)  # True if big (>4), False if small (≤4)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    bets = db.relationship('Bet', backref='game_result', lazy=True)

class Bet(db.Model):
    __tablename__ = 'bets'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    game_result_id = db.Column(db.Integer, db.ForeignKey('game_results.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    bet_type = db.Column(db.String(20), nullable=False)  # 'red', 'green', 'big', 'small'
    won = db.Column(db.Boolean, nullable=True)  # True if won, False if lost, None if pending
    payout = db.Column(db.Float, nullable=True)  # Amount won, null if pending or lost
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class OTP(db.Model):
    __tablename__ = 'otps'
    
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), nullable=False)
    otp_code = db.Column(db.String(6), nullable=False)
    purpose = db.Column(db.String(20), nullable=False)  # 'registration', 'login', 'reset_password'
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
