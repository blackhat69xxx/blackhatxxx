import random
import threading
import time
import json
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify
from app import app, db
from models import User, GameResult, Bet

game_bp = Blueprint('game', __name__, url_prefix='/game')

# Global variables to track game states
game_state = {
    '1min': {
        'countdown': 60,
        'last_result': None,
        'next_result': None,
        'is_running': False,
        'total_bets': 0,
        'hot_numbers': [],
        'cold_numbers': [],
        'streak': {
            'type': None,
            'count': 0
        }
    },
    '30s': {
        'countdown': 30,
        'last_result': None,
        'next_result': None,
        'is_running': False,
        'total_bets': 0,
        'hot_numbers': [],
        'cold_numbers': [],
        'streak': {
            'type': None,
            'count': 0
        }
    }
}

# Number frequency tracking
number_frequency = {
    '1min': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0},
    '30s': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0}
}

# Payout multipliers for different bet types
payout_multipliers = {
    'red': 2.0,     # 1:1 payout (2x the bet)
    'green': 2.0,   # 1:1 payout (2x the bet)
    'big': 2.0,     # 1:1 payout (2x the bet)
    'small': 2.0,   # 1:1 payout (2x the bet)
    'exact': 9.0,   # 8:1 payout (9x the bet)
    'triple': 3.0,  # 2:1 payout (3x the bet)
    'combo': 4.5    # 3.5:1 payout (4.5x the bet)
}

def generate_result():
    """Generate a random game result (1-9)"""
    return random.randint(1, 9)

def is_red(number):
    """Determine if a number is red (odd) or green (even)"""
    return number % 2 == 1

def is_big(number):
    """Determine if a number is big (>4) or small (≤4)"""
    return number > 4

def update_streaks(game_type, current_result):
    """Update winning streaks for a game type"""
    current_streak = game_state[game_type]['streak']
    
    # Check for color streak
    is_current_red = is_red(current_result)
    color_type = 'red' if is_current_red else 'green'
    
    if current_streak['type'] == color_type:
        current_streak['count'] += 1
    else:
        current_streak['type'] = color_type
        current_streak['count'] = 1
    
    # Update hot and cold numbers
    number_frequency[game_type][current_result] += 1
    
    # Calculate hot and cold numbers (top 3 and bottom 3)
    freq_list = [(num, freq) for num, freq in number_frequency[game_type].items()]
    freq_list.sort(key=lambda x: x[1], reverse=True)
    
    game_state[game_type]['hot_numbers'] = [num for num, _ in freq_list[:3]]
    game_state[game_type]['cold_numbers'] = [num for num, _ in freq_list[-3:]]

def is_triple_outcome(game_type, bet_type):
    """Check if the bet type is for a triple outcome (red+big, red+small, green+big, green+small)"""
    if '+' not in bet_type:
        return False
    
    parts = bet_type.split('+')
    if len(parts) != 2:
        return False
    
    color, size = parts
    return (color in ['red', 'green'] and size in ['big', 'small'])

def game_thread(game_type):
    """Background thread to run the game"""
    global game_state
    
    # Set initial countdown
    countdown = 60 if game_type == '1min' else 30
    game_state[game_type]['countdown'] = countdown
    game_state[game_type]['is_running'] = True
    
    # Pre-generate the first result
    next_result = generate_result()
    game_state[game_type]['next_result'] = next_result
    
    while game_state[game_type]['is_running']:
        # Update countdown
        game_state[game_type]['countdown'] = countdown
        
        # When countdown reaches zero, update results and process bets
        if countdown <= 0:
            with app.app_context():
                # Save the result to database
                result_number = game_state[game_type]['next_result']
                result = GameResult(
                    game_type=game_type,
                    result_number=result_number,
                    is_red=is_red(result_number),
                    is_big=is_big(result_number)
                )
                db.session.add(result)
                db.session.commit()
                
                # Process all pending bets for this game round
                process_bets(result)
                
                # Update game state
                game_state[game_type]['last_result'] = result_number
                
                # Update streaks and patterns
                update_streaks(game_type, result_number)
                
                # Generate next result (with some basic balancing to avoid long streaks)
                if random.random() < 0.8:  # 80% chance of random result
                    next_result = generate_result()
                else:
                    # 20% chance of a "balancing" result to avoid too many of the same type
                    current_streak = game_state[game_type]['streak']
                    if current_streak['count'] >= 3:
                        # If there's a streak of 3+ same colors, 
                        # try to break the streak with a different color
                        current_type = current_streak['type']
                        if current_type == 'red':  # Generate an even number
                            next_result = random.choice([2, 4, 6, 8])
                        else:  # Generate an odd number
                            next_result = random.choice([1, 3, 5, 7, 9])
                    else:
                        next_result = generate_result()
                
                game_state[game_type]['next_result'] = next_result
                
                # Reset countdown
                countdown = 60 if game_type == '1min' else 30
                
                # Log game round completion
                app.logger.info(f"Game {game_type} completed: Result {result_number} (Red: {is_red(result_number)}, Big: {is_big(result_number)})")
                
        time.sleep(1)
        countdown -= 1

def process_bets(result):
    """Process all pending bets for the given game result"""
    # Find all bets for this game round
    bets = Bet.query.filter_by(game_result_id=result.id).all()
    
    for bet in bets:
        # Determine if bet won based on bet_type and result
        won = False
        payout = 0
        
        # Extract bet_type and check for special bet formats
        bet_type = bet.bet_type
        
        # For exact number bets (e.g., "exact_5")
        if bet_type.startswith('exact_'):
            try:
                exact_number = int(bet_type.split('_')[1])
                if result.result_number == exact_number:
                    won = True
                    payout = bet.amount * payout_multipliers['exact']
            except (IndexError, ValueError):
                app.logger.error(f"Invalid exact bet format: {bet_type}")
        
        # For combined bets (e.g., "red+big")
        elif '+' in bet_type:
            parts = bet_type.split('+')
            if len(parts) == 2:
                color_part, size_part = parts
                color_match = (color_part == 'red' and result.is_red) or (color_part == 'green' and not result.is_red)
                size_match = (size_part == 'big' and result.is_big) or (size_part == 'small' and not result.is_big)
                
                if color_match and size_match:
                    won = True
                    payout = bet.amount * payout_multipliers['combo']
        
        # Standard bets
        elif bet_type == 'red' and result.is_red:
            won = True
            payout = bet.amount * payout_multipliers['red']
        elif bet_type == 'green' and not result.is_red:
            won = True
            payout = bet.amount * payout_multipliers['green']
        elif bet_type == 'big' and result.is_big:
            won = True
            payout = bet.amount * payout_multipliers['big']
        elif bet_type == 'small' and not result.is_big:
            won = True
            payout = bet.amount * payout_multipliers['small']
        
        # Update bet record
        bet.won = won
        bet.payout = payout if won else 0
        
        # Update user balance if bet won
        if won:
            user = User.query.get(bet.user_id)
            if user:
                user.balance += payout
                app.logger.info(f"User {user.phone} won {payout} on bet type {bet_type}")
        
        # Update total bets count for statistics
        game_state[result.game_type]['total_bets'] += 1
    
    # Commit all changes
    db.session.commit()

# Start game threads function
def start_game_threads():
    for game_type in ['1min', '30s']:
        thread = threading.Thread(target=game_thread, args=(game_type,))
        thread.daemon = True
        thread.start()

@game_bp.route('/history/<game_type>')
def game_history(game_type):
    """Get detailed game history for analysis"""
    if game_type not in ['1min', '30s']:
        return jsonify({"success": False, "message": "Invalid game type"}), 400
    
    days = int(request.args.get('days', 1))
    days = max(1, min(30, days))  # Limit between 1-30 days
    
    # Calculate date range
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Get results in date range
    results = GameResult.query.filter(
        GameResult.game_type == game_type,
        GameResult.created_at >= start_date,
        GameResult.created_at <= end_date
    ).order_by(GameResult.created_at.asc()).all()
    
    # Get bets for this game type
    bets = Bet.query.join(GameResult).filter(
        GameResult.game_type == game_type,
        GameResult.created_at >= start_date,
        GameResult.created_at <= end_date
    ).all()
    
    # Calculate statistics
    total_results = len(results)
    red_count = sum(1 for r in results if r.is_red)
    green_count = total_results - red_count
    big_count = sum(1 for r in results if r.is_big)
    small_count = total_results - big_count
    
    number_distribution = {}
    for i in range(1, 10):
        number_distribution[str(i)] = sum(1 for r in results if r.result_number == i)
    
    total_bets = len(bets)
    total_bet_amount = sum(b.amount for b in bets)
    total_payout = sum(b.payout or 0 for b in bets)
    house_edge = total_bet_amount - total_payout
    
    # Daily breakdown
    daily_data = {}
    current_date = start_date.date()
    while current_date <= end_date.date():
        daily_results = [r for r in results if r.created_at.date() == current_date]
        daily_bets = [b for b in bets if b.created_at.date() == current_date]
        
        daily_data[str(current_date)] = {
            'results_count': len(daily_results),
            'bets_count': len(daily_bets),
            'bet_amount': sum(b.amount for b in daily_bets),
            'payout_amount': sum(b.payout or 0 for b in daily_bets),
            'profit': sum(b.amount for b in daily_bets) - sum(b.payout or 0 for b in daily_bets)
        }
        
        current_date += timedelta(days=1)
    
    return jsonify({
        'success': True,
        'game_type': game_type,
        'days_analyzed': days,
        'statistics': {
            'total_results': total_results,
            'total_bets': total_bets,
            'total_bet_amount': total_bet_amount,
            'total_payout': total_payout,
            'house_edge': house_edge,
            'house_edge_percentage': round((house_edge / total_bet_amount) * 100) if total_bet_amount > 0 else 0,
            'red_percentage': round((red_count / total_results) * 100) if total_results > 0 else 0,
            'green_percentage': round((green_count / total_results) * 100) if total_results > 0 else 0,
            'big_percentage': round((big_count / total_results) * 100) if total_results > 0 else 0,
            'small_percentage': round((small_count / total_results) * 100) if total_results > 0 else 0,
            'number_distribution': number_distribution
        },
        'daily_data': daily_data
    })

# Start the game threads when blueprint is registered
with app.app_context():
    start_game_threads()

@game_bp.route('/')
def game_page():
    """Render the main game page"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user = User.query.get(session['user_id'])
    
    # Get last 10 results for each game type
    results_1min = GameResult.query.filter_by(game_type='1min').order_by(GameResult.created_at.desc()).limit(10).all()
    results_30s = GameResult.query.filter_by(game_type='30s').order_by(GameResult.created_at.desc()).limit(10).all()
    
    # Get user's recent bets
    recent_bets = Bet.query.filter_by(user_id=user.id).order_by(Bet.created_at.desc()).limit(10).all()
    
    return render_template('game.html', 
                          user=user, 
                          results_1min=results_1min, 
                          results_30s=results_30s,
                          recent_bets=recent_bets,
                          game_state=game_state)

@game_bp.route('/place_bet', methods=['POST'])
def place_bet():
    """Handle bet placement"""
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Not logged in"}), 401
    
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    # Get bet details from form
    game_type = request.form.get('game_type')
    bet_type = request.form.get('bet_type')
    amount = float(request.form.get('amount', 0))
    
    # Min and max bet amounts
    min_bet = 10  # Minimum bet amount
    max_bet = 10000  # Maximum bet amount
    
    # Validate input
    if not game_type or game_type not in ['1min', '30s']:
        return jsonify({"success": False, "message": "Invalid game type"}), 400
    
    # Get countdown to validate if bet can be placed
    countdown = game_state[game_type]['countdown']
    if countdown <= 5:  # Don't allow bets in last 5 seconds
        return jsonify({"success": False, "message": "Betting closed for this round. Please wait for the next round."}), 400
    
    # Enhanced bet type validation for all possible bet types
    valid_bet = False
    
    # Simple bet types
    if bet_type in ['red', 'green', 'big', 'small']:
        valid_bet = True
    
    # Exact number bet (e.g., "exact_5")
    elif bet_type.startswith('exact_'):
        try:
            number = int(bet_type.split('_')[1])
            if 1 <= number <= 9:
                valid_bet = True
        except (IndexError, ValueError):
            valid_bet = False
    
    # Combined bet types (e.g., "red+big")
    elif '+' in bet_type:
        parts = bet_type.split('+')
        if len(parts) == 2:
            color, size = parts
            if color in ['red', 'green'] and size in ['big', 'small']:
                valid_bet = True
    
    if not valid_bet:
        return jsonify({"success": False, "message": "Invalid bet type"}), 400
    
    # Validate amount
    if amount < min_bet:
        return jsonify({"success": False, "message": f"Minimum bet amount is ৳{min_bet}"}), 400
    
    if amount > max_bet:
        return jsonify({"success": False, "message": f"Maximum bet amount is ৳{max_bet}"}), 400
    
    if user.balance < amount:
        return jsonify({"success": False, "message": "Insufficient balance"}), 400
    
    # Find the current game round or create a new one
    current_game = GameResult.query.filter_by(game_type=game_type).order_by(GameResult.created_at.desc()).first()
    
    if not current_game:
        # Create a new game round if none exists
        result_number = game_state[game_type]['next_result']
        current_game = GameResult(
            game_type=game_type,
            result_number=result_number,
            is_red=is_red(result_number),
            is_big=is_big(result_number)
        )
        db.session.add(current_game)
        db.session.commit()
    
    # Create the bet
    bet = Bet(
        user_id=user_id,
        game_result_id=current_game.id,
        amount=amount,
        bet_type=bet_type
    )
    
    # Deduct amount from user balance
    user.balance -= amount
    
    db.session.add(bet)
    db.session.commit()
    
    # Get payout multiplier for message
    multiplier = 2.0  # Default multiplier
    if bet_type.startswith('exact_'):
        multiplier = payout_multipliers['exact']
    elif '+' in bet_type:
        multiplier = payout_multipliers['combo']
    else:
        multiplier = payout_multipliers.get(bet_type, 2.0)
    
    # Format bet type name for display
    display_bet_type = bet_type
    if bet_type.startswith('exact_'):
        display_bet_type = f"Exact number {bet_type.split('_')[1]}"
    elif '+' in bet_type:
        parts = bet_type.split('+')
        display_bet_type = f"{parts[0].capitalize()} + {parts[1].capitalize()}"
    else:
        display_bet_type = bet_type.capitalize()
    
    return jsonify({
        "success": True,
        "message": f"Bet placed successfully: ৳{amount} on {display_bet_type} (x{multiplier})",
        "new_balance": user.balance,
        "bet_type": bet_type,
        "potential_win": amount * multiplier
    })

@game_bp.route('/game_status')
def game_status():
    """AJAX endpoint to get current game status"""
    game_type = request.args.get('game_type', None)
    
    if game_type and game_type in game_state:
        # Return status for specific game type with pattern analysis
        status = game_state[game_type]
        
        # Add additional data for frontend display
        response_data = {
            'countdown': status['countdown'],
            'last_result': status['last_result'],
            'is_running': status['is_running'],
            'hot_numbers': status['hot_numbers'],
            'cold_numbers': status['cold_numbers'],
            'current_streak': {
                'type': status['streak']['type'],
                'count': status['streak']['count']
            },
            'patterns': {
                'red_percentage': calculate_percentage('red', game_type),
                'big_percentage': calculate_percentage('big', game_type),
                'number_frequency': {str(num): freq for num, freq in number_frequency[game_type].items()}
            },
            'bet_allowed': status['countdown'] > 5,
            'total_bets': status['total_bets']
        }
        
        return jsonify(response_data)
    
    # Return full game state if no specific type requested
    enhanced_state = {}
    for game_type, status in game_state.items():
        enhanced_state[game_type] = {
            'countdown': status['countdown'],
            'last_result': status['last_result'],
            'is_running': status['is_running'],
            'hot_numbers': status['hot_numbers'],
            'cold_numbers': status['cold_numbers'],
            'current_streak': {
                'type': status['streak']['type'],
                'count': status['streak']['count']
            },
            'bet_allowed': status['countdown'] > 5
        }
    
    return jsonify(enhanced_state)

def calculate_percentage(outcome_type, game_type):
    """Calculate percentage of a particular outcome in recent games"""
    # Get last 20 results
    results = GameResult.query.filter_by(game_type=game_type).order_by(GameResult.created_at.desc()).limit(20).all()
    
    if not results:
        return 50  # Default to 50% if no results
    
    count = 0
    for result in results:
        if outcome_type == 'red' and result.is_red:
            count += 1
        elif outcome_type == 'green' and not result.is_red:
            count += 1
        elif outcome_type == 'big' and result.is_big:
            count += 1
        elif outcome_type == 'small' and not result.is_big:
            count += 1
    
    return round((count / len(results)) * 100)

@game_bp.route('/recent_results')
def recent_results():
    """AJAX endpoint to get recent game results with statistics"""
    game_type = request.args.get('game_type', '1min')
    limit = int(request.args.get('limit', 10))
    
    # Limit to reasonable range (5-50)
    limit = max(5, min(50, limit))
    
    if game_type not in ['1min', '30s']:
        return jsonify({"success": False, "message": "Invalid game type"}), 400
    
    # Get recent results
    results = GameResult.query.filter_by(game_type=game_type).order_by(GameResult.created_at.desc()).limit(limit).all()
    
    # Prepare results data
    results_data = [{
        "id": r.id,
        "number": r.result_number,
        "is_red": r.is_red,
        "is_big": r.is_big,
        "created_at": r.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for r in results]
    
    # Calculate statistics
    stats = {
        "total_count": len(results),
        "red_count": sum(1 for r in results if r.is_red),
        "green_count": sum(1 for r in results if not r.is_red),
        "big_count": sum(1 for r in results if r.is_big),
        "small_count": sum(1 for r in results if not r.is_big),
        "number_distribution": {}
    }
    
    # Calculate number distribution
    for i in range(1, 10):
        stats["number_distribution"][i] = sum(1 for r in results if r.result_number == i)
    
    # Calculate red/green and big/small percentages
    if results:
        stats["red_percentage"] = round((stats["red_count"] / stats["total_count"]) * 100)
        stats["green_percentage"] = round((stats["green_count"] / stats["total_count"]) * 100)
        stats["big_percentage"] = round((stats["big_count"] / stats["total_count"]) * 100)
        stats["small_percentage"] = round((stats["small_count"] / stats["total_count"]) * 100)
    else:
        stats["red_percentage"] = 50
        stats["green_percentage"] = 50
        stats["big_percentage"] = 50
        stats["small_percentage"] = 50
    
    # Identify current streaks
    current_color_streak = identify_streak(results, 'color')
    current_size_streak = identify_streak(results, 'size')
    
    # Get betting trends from recent bets
    recent_bets = Bet.query.join(GameResult).filter(GameResult.game_type == game_type).order_by(Bet.created_at.desc()).limit(50).all()
    
    betting_trends = {
        "red_bets": sum(1 for b in recent_bets if b.bet_type == 'red'),
        "green_bets": sum(1 for b in recent_bets if b.bet_type == 'green'),
        "big_bets": sum(1 for b in recent_bets if b.bet_type == 'big'),
        "small_bets": sum(1 for b in recent_bets if b.bet_type == 'small'),
        "exact_bets": sum(1 for b in recent_bets if b.bet_type.startswith('exact_')),
        "combo_bets": sum(1 for b in recent_bets if '+' in b.bet_type),
    }
    
    return jsonify({
        "success": True,
        "results": results_data,
        "stats": stats,
        "streaks": {
            "color": current_color_streak,
            "size": current_size_streak
        },
        "betting_trends": betting_trends,
        "payout_multipliers": payout_multipliers
    })

def identify_streak(results, streak_type):
    """Identify the current streak in results"""
    if not results:
        return {"type": None, "count": 0}
    
    streak = {"type": None, "count": 0}
    
    for result in results:
        if streak_type == 'color':
            current_type = 'red' if result.is_red else 'green'
        elif streak_type == 'size':
            current_type = 'big' if result.is_big else 'small'
        else:
            return streak
        
        if streak["type"] == current_type:
            streak["count"] += 1
        else:
            if streak["count"] > 0:
                # Streak has ended
                break
            streak["type"] = current_type
            streak["count"] = 1
    
    return streak

@game_bp.route('/user_bets')
def user_bets():
    """Get user's betting history and statistics"""
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Not logged in"}), 401
    
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({"success": False, "message": "User not found"}), 404
    
    # Get query parameters
    days = int(request.args.get('days', 7))
    days = max(1, min(30, days))  # Limit between 1-30 days
    
    game_type = request.args.get('game_type', None)
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 20))
    
    # Set up date range
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Build base query
    query = Bet.query.filter(
        Bet.user_id == user_id,
        Bet.created_at >= start_date,
        Bet.created_at <= end_date
    )
    
    # Apply game type filter if specified
    if game_type in ['1min', '30s']:
        query = query.join(GameResult).filter(GameResult.game_type == game_type)
    
    # Get total items for pagination
    total_items = query.count()
    
    # Apply pagination
    paginated_bets = query.order_by(Bet.created_at.desc()).offset((page - 1) * per_page).limit(per_page).all()
    
    # Format bet data
    bets_data = []
    for bet in paginated_bets:
        game_result = GameResult.query.get(bet.game_result_id)
        if game_result:
            bet_data = {
                "id": bet.id,
                "amount": float(bet.amount),
                "bet_type": bet.bet_type,
                "won": bet.won,
                "payout": float(bet.payout) if bet.payout else 0,
                "created_at": bet.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                "game_type": game_result.game_type,
                "result_number": game_result.result_number,
                "is_red": game_result.is_red,
                "is_big": game_result.is_big
            }
            bets_data.append(bet_data)
    
    # Calculate statistics
    all_bets = query.all()
    total_bets = len(all_bets)
    total_bet_amount = sum(bet.amount for bet in all_bets)
    winning_bets = [bet for bet in all_bets if bet.won]
    total_winnings = sum(bet.payout for bet in winning_bets if bet.payout)
    
    win_rate = (len(winning_bets) / total_bets) * 100 if total_bets > 0 else 0
    profit_loss = total_winnings - total_bet_amount
    
    # Group by bet type
    bet_type_stats = {}
    for bet in all_bets:
        bet_type = bet.bet_type
        if bet_type not in bet_type_stats:
            bet_type_stats[bet_type] = {
                "count": 0,
                "amount": 0,
                "winnings": 0,
                "wins": 0
            }
        
        stats = bet_type_stats[bet_type]
        stats["count"] += 1
        stats["amount"] += bet.amount
        
        if bet.won:
            stats["wins"] += 1
            stats["winnings"] += bet.payout if bet.payout else 0
    
    # Calculate win rates and profit for each bet type
    for bet_type, stats in bet_type_stats.items():
        stats["win_rate"] = (stats["wins"] / stats["count"]) * 100 if stats["count"] > 0 else 0
        stats["profit"] = stats["winnings"] - stats["amount"]
    
    return jsonify({
        "success": True,
        "bets": bets_data,
        "pagination": {
            "current_page": page,
            "per_page": per_page,
            "total_items": total_items,
            "total_pages": (total_items + per_page - 1) // per_page
        },
        "statistics": {
            "total_bets": total_bets,
            "total_bet_amount": float(total_bet_amount),
            "winning_bets": len(winning_bets),
            "total_winnings": float(total_winnings),
            "win_rate": round(win_rate, 2),
            "profit_loss": float(profit_loss),
            "profit_loss_percentage": round((profit_loss / total_bet_amount) * 100, 2) if total_bet_amount > 0 else 0,
            "bet_type_stats": bet_type_stats
        }
    })
