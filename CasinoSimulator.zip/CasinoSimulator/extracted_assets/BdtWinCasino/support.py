import os
from flask import Blueprint, render_template, request, jsonify, session, flash
from app import app, db
from models import User

support_bp = Blueprint('support', __name__, url_prefix='/support')

# Telegram bot username for customer support
TELEGRAM_SUPPORT_USERNAME = "BDTWin_Support"

@support_bp.route('/chat', methods=['POST'])
def chat():
    """Handle customer support chat messages"""
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Please login to use support chat"}), 401
    
    user_message = request.form.get('message', '')
    if not user_message:
        return jsonify({"success": False, "message": "Message cannot be empty"}), 400
    
    # Get user info for context
    user = User.query.get(session['user_id'])
    
    # Simple rule-based responses for common questions
    lower_message = user_message.lower()
    
    if any(keyword in lower_message for keyword in ["deposit", "payment", "bkash", "nagad"]):
        return jsonify({
            "success": True,
            "response": f"For deposit queries, please check our deposit page or contact us on Telegram: @{TELEGRAM_SUPPORT_USERNAME} for assistance with your payment."
        })
    
    elif any(keyword in lower_message for keyword in ["withdraw", "withdrawal", "cash out"]):
        return jsonify({
            "success": True,
            "response": f"For withdrawal queries, please check our withdrawal page or contact us on Telegram: @{TELEGRAM_SUPPORT_USERNAME} for assistance."
        })
    
    elif any(keyword in lower_message for keyword in ["game", "bet", "wingo", "red", "green", "big", "small"]):
        return jsonify({
            "success": True,
            "response": f"For game-related queries, please review the game rules or contact us on Telegram: @{TELEGRAM_SUPPORT_USERNAME} for specific questions about betting."
        })
    
    elif any(keyword in lower_message for keyword in ["account", "login", "register", "password", "forgot"]):
        return jsonify({
            "success": True,
            "response": f"For account-related queries, please check your profile page or contact us on Telegram: @{TELEGRAM_SUPPORT_USERNAME} for personal assistance."
        })
    
    # Default response for other queries
    return jsonify({
        "success": True,
        "response": f"Thank you for your message. For personalized support, please contact us directly on Telegram: @{TELEGRAM_SUPPORT_USERNAME}. Our support team is available 24/7 to assist you."
    })