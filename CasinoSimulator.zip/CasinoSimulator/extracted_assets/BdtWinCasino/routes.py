from flask import render_template, redirect, url_for, session, request, jsonify, flash
from app import app, db
from models import User, Transaction, GameResult, Bet
from flask_login import current_user, login_required
import datetime

@app.route('/')
def index():
    """Homepage route that redirects to game or login based on authentication status"""
    if 'user_id' in session:
        return redirect(url_for('game.game_page'))
    return redirect(url_for('auth.login_register'))

@app.route('/user_balance')
def user_balance():
    """AJAX endpoint to get user balance"""
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Not logged in"}), 401
    
    user = User.query.get(session['user_id'])
    if not user:
        return jsonify({"success": False, "message": "User not found"}), 404
    
    return jsonify({
        "success": True,
        "balance": user.balance
    })

@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    user = User.query.get(session['user_id'])
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    bets = Bet.query.filter_by(user_id=user.id).order_by(Bet.created_at.desc()).limit(10).all()
    
    return render_template('profile.html', user=user, transactions=transactions, bets=bets)

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    app.logger.error(f"Server error: {e}")
    return render_template('500.html'), 500

@app.context_processor
def inject_user():
    """Inject user data into all templates"""
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return {'user': user}
    return {'user': None}
