import random
import string
from datetime import datetime, timedelta
import re

def generate_random_string(length=10):
    """Generate a random string of fixed length"""
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for _ in range(length))

def is_valid_phone(phone):
    """Validate phone number format"""
    # Simple pattern for Bangladesh phone numbers
    pattern = r'^\+?88?01[3-9]\d{8}$'
    return bool(re.match(pattern, phone))

def format_currency(amount):
    """Format currency amount"""
    return f"৳{amount:.2f}"

def get_time_difference(timestamp):
    """Get human-readable time difference from timestamp"""
    now = datetime.utcnow()
    diff = now - timestamp
    
    if diff.days > 0:
        return f"{diff.days} day(s) ago"
    elif diff.seconds >= 3600:
        return f"{diff.seconds // 3600} hour(s) ago"
    elif diff.seconds >= 60:
        return f"{diff.seconds // 60} minute(s) ago"
    else:
        return f"{diff.seconds} second(s) ago"

def get_transaction_status_class(status):
    """Get CSS class for transaction status"""
    if status == 'approved':
        return 'text-success'
    elif status == 'rejected':
        return 'text-danger'
    else:
        return 'text-warning'

def get_bet_result_class(won):
    """Get CSS class for bet result"""
    if won is True:
        return 'text-success'
    elif won is False:
        return 'text-danger'
    else:
        return 'text-warning'

def get_number_color_class(is_red):
    """Get CSS class for number color"""
    return 'text-danger' if is_red else 'text-success'

def get_number_size_class(is_big):
    """Get CSS class for number size"""
    return 'big' if is_big else 'small'
