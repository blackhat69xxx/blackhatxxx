// Support chat functionality
document.addEventListener('DOMContentLoaded', function() {
    initSupportChat();
});

function initSupportChat() {
    const supportChatButton = document.getElementById('support-chat-button');
    const supportChatPanel = document.getElementById('support-chat-panel');
    const supportChatClose = document.getElementById('support-chat-close');
    const supportChatForm = document.getElementById('support-chat-form');
    const supportChatInput = document.getElementById('support-chat-input');
    const supportChatMessages = document.getElementById('support-chat-messages');
    const supportChatLoading = document.getElementById('support-chat-loading');

    if (!supportChatButton) return;

    // Add welcome message
    addBotMessage("Hello! 👋 I'm your BDT-WIN support assistant. How can I help you today? For personalized support, you can also contact us on Telegram: @BDTWin_Support");

    // Add Telegram direct link
    addTelegramLink();

    // Toggle chat panel visibility
    supportChatButton.addEventListener('click', function() {
        supportChatPanel.classList.toggle('active');
        if (supportChatPanel.classList.contains('active')) {
            supportChatInput.focus();
        }
    });

    // Close chat panel (minimize)
    supportChatClose.addEventListener('click', function() {
        supportChatPanel.classList.remove('active');
    });

    // Send message
    supportChatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const message = supportChatInput.value.trim();
        if (!message) return;
        
        // Add user message to chat
        addUserMessage(message);
        
        // Clear input
        supportChatInput.value = '';
        
        // Show loading indicator
        supportChatLoading.classList.add('active');
        
        // Scroll to bottom of chat
        scrollToBottom();
        
        // Send to server
        fetch('/support/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                'message': message
            })
        })
        .then(response => response.json())
        .then(data => {
            // Hide loading indicator
            supportChatLoading.classList.remove('active');
            
            if (data.success) {
                // Add bot response
                addBotMessage(data.response);
            } else {
                // Show error
                addBotMessage("Sorry, I'm having trouble responding right now. Please contact us on Telegram: @BDTWin_Support");
                console.error('Support chat error:', data.message);
            }
            
            // Scroll to bottom of chat
            scrollToBottom();
        })
        .catch(error => {
            // Hide loading indicator
            supportChatLoading.classList.remove('active');
            
            // Show error
            addBotMessage("Sorry, there was a problem connecting to the support service. Please contact us directly on Telegram: @BDTWin_Support");
            console.error('Support chat error:', error);
            
            // Scroll to bottom of chat
            scrollToBottom();
        });
    });

    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'support-message support-message-user';
        messageElement.textContent = message;
        supportChatMessages.appendChild(messageElement);
        scrollToBottom();
    }

    function addBotMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'support-message support-message-bot';
        
        // Convert Telegram mentions to links
        message = message.replace(/@BDTWin_Support/g, '<a href="https://t.me/BDTWin_Support" target="_blank">@BDTWin_Support</a>');
        
        messageElement.innerHTML = message.replace(/\n/g, '<br>');
        supportChatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    function addTelegramLink() {
        const messageElement = document.createElement('div');
        messageElement.className = 'support-message support-message-bot support-telegram-link';
        messageElement.innerHTML = `
            <div class="telegram-button">
                <a href="https://t.me/BDTWin_Support" target="_blank">
                    <i class="fab fa-telegram"></i> Contact us on Telegram
                </a>
            </div>
        `;
        supportChatMessages.appendChild(messageElement);
        scrollToBottom();
    }

    function scrollToBottom() {
        supportChatMessages.scrollTop = supportChatMessages.scrollHeight;
    }
}