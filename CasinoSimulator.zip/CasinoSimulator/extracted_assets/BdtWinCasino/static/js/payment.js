document.addEventListener('DOMContentLoaded', function() {
    // Payment method selection
    const paymentMethods = document.querySelectorAll('.payment-method-card');
    let selectedPaymentMethod = null;
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            const methodName = this.getAttribute('data-method');
            
            // Toggle selection
            paymentMethods.forEach(m => m.classList.remove('active'));
            this.classList.add('active');
            
            selectedPaymentMethod = methodName;
            
            // Update hidden input
            const paymentMethodInput = document.getElementById('payment-method');
            if (paymentMethodInput) {
                paymentMethodInput.value = methodName;
            }
            
            // Update payment details section
            updatePaymentDetails(methodName);
            
            // Update submit button state
            updateSubmitButtonState();
        });
    });
    
    // Function to update payment details section based on selected method
    function updatePaymentDetails(methodName) {
        const detailsContainer = document.getElementById('payment-details');
        
        if (!detailsContainer) return;
        
        let paymentInfo = '';
        
        if (methodName === 'bKash') {
            paymentInfo = `
                <div class="payment-info">
                    <h4 class="mb-3">bKash Payment Instructions</h4>
                    <ol class="payment-steps">
                        <li>Open your bKash app</li>
                        <li>Go to "Send Money"</li>
                        <li>Enter: <strong>01600297503</strong></li>
                        <li>Enter the exact amount</li>
                        <li>Submit your transaction and note the Transaction ID</li>
                        <li>Enter the Transaction ID and your bKash number below</li>
                    </ol>
                </div>
            `;
        } else if (methodName === 'Nagad') {
            paymentInfo = `
                <div class="payment-info">
                    <h4 class="mb-3">Nagad Payment Instructions</h4>
                    <ol class="payment-steps">
                        <li>Open your Nagad app</li>
                        <li>Go to "Send Money"</li>
                        <li>Enter: <strong>01600297503</strong></li>
                        <li>Enter the exact amount</li>
                        <li>Submit your transaction and note the Transaction ID</li>
                        <li>Enter the Transaction ID and your Nagad number below</li>
                    </ol>
                </div>
            `;
        }
        
        detailsContainer.innerHTML = paymentInfo;
    }
    
    // Deposit amount input validation
    const amountInput = document.getElementById('deposit-amount');
    
    if (amountInput) {
        amountInput.addEventListener('input', function() {
            // Allow only numbers and decimal point
            this.value = this.value.replace(/[^0-9.]/g, '');
            
            // Ensure only one decimal point
            const parts = this.value.split('.');
            if (parts.length > 2) {
                this.value = parts[0] + '.' + parts.slice(1).join('');
            }
            
            // Update submit button state
            updateSubmitButtonState();
        });
    }
    
    // Phone number input validation
    const phoneInput = document.getElementById('payment-phone');
    
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            // Allow only numbers and plus sign
            this.value = this.value.replace(/[^0-9+]/g, '');
            
            // Update submit button state
            updateSubmitButtonState();
        });
    }
    
    // Transaction ID input validation
    const transactionIdInput = document.getElementById('transaction-id');
    
    if (transactionIdInput) {
        transactionIdInput.addEventListener('input', function() {
            // Update submit button state
            updateSubmitButtonState();
        });
    }
    
    // Update submit button state
    function updateSubmitButtonState() {
        const submitButton = document.getElementById('payment-submit');
        
        if (!submitButton) return;
        
        let isValid = true;
        
        // Check payment method
        if (!selectedPaymentMethod) {
            isValid = false;
        }
        
        // Check amount
        if (amountInput) {
            const amount = parseFloat(amountInput.value);
            if (!amount || isNaN(amount) || amount <= 0) {
                isValid = false;
            }
        }
        
        // Check phone
        if (phoneInput) {
            // Simple pattern for Bangladesh phone numbers
            const phonePattern = /^\+?88?01[3-9]\d{8}$/;
            if (!phonePattern.test(phoneInput.value)) {
                isValid = false;
            }
        }
        
        // Check transaction ID for deposit
        if (transactionIdInput && submitButton.classList.contains('deposit-submit')) {
            if (!transactionIdInput.value.trim()) {
                isValid = false;
            }
        }
        
        submitButton.disabled = !isValid;
    }
    
    // Quick amount selection
    const quickAmounts = document.querySelectorAll('.quick-amount');
    
    quickAmounts.forEach(btn => {
        btn.addEventListener('click', function() {
            const amount = this.getAttribute('data-amount');
            
            if (amountInput) {
                amountInput.value = amount;
                
                // Update submit button state
                updateSubmitButtonState();
            }
        });
    });
    
    // Deposit form submission
    const depositForm = document.getElementById('deposit-form');
    
    if (depositForm) {
        depositForm.addEventListener('submit', function(e) {
            if (!validatePaymentForm(e, 'deposit')) {
                return;
            }
            
            // Show loading state
            const submitButton = document.getElementById('payment-submit');
            const originalButtonText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
            
            // Form will submit normally
        });
    }
    
    // Withdrawal form submission
    const withdrawForm = document.getElementById('withdraw-form');
    
    if (withdrawForm) {
        withdrawForm.addEventListener('submit', function(e) {
            if (!validatePaymentForm(e, 'withdraw')) {
                return;
            }
            
            // Additional check for withdraw - check balance
            const amount = parseFloat(amountInput.value);
            const userBalance = parseFloat(document.getElementById('user-balance').getAttribute('data-balance'));
            
            if (amount > userBalance) {
                e.preventDefault();
                showPaymentAlert('Insufficient balance', 'error');
                return;
            }
            
            // Show loading state
            const submitButton = document.getElementById('payment-submit');
            const originalButtonText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
            
            // Form will submit normally
        });
    }
    
    // Validate payment form
    function validatePaymentForm(e, type) {
        // Basic validation
        if (!selectedPaymentMethod) {
            e.preventDefault();
            showPaymentAlert('Please select a payment method', 'error');
            return false;
        }
        
        if (amountInput) {
            const amount = parseFloat(amountInput.value);
            if (!amount || isNaN(amount) || amount <= 0) {
                e.preventDefault();
                showPaymentAlert('Please enter a valid amount', 'error');
                return false;
            }
        }
        
        if (phoneInput) {
            // Simple pattern for Bangladesh phone numbers
            const phonePattern = /^\+?88?01[3-9]\d{8}$/;
            if (!phonePattern.test(phoneInput.value)) {
                e.preventDefault();
                showPaymentAlert('Please enter a valid Bangladesh phone number', 'error');
                return false;
            }
        }
        
        // Transaction ID only required for deposits
        if (type === 'deposit' && transactionIdInput) {
            if (!transactionIdInput.value.trim()) {
                e.preventDefault();
                showPaymentAlert('Please enter your transaction ID', 'error');
                return false;
            }
        }
        
        return true;
    }
    
    // Initialize the payment page
    function initPaymentPage() {
        // Set first payment method as active by default if none selected
        if (paymentMethods.length > 0 && !selectedPaymentMethod) {
            paymentMethods[0].click();
        }
    }
    
    // Initialize if we're on a payment page
    if (document.querySelector('.payment-container')) {
        initPaymentPage();
    }
});

// Helper function to show alert messages in payment
function showPaymentAlert(message, type) {
    const alertContainer = document.getElementById('payment-alert-container');
    
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alertDiv);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}
