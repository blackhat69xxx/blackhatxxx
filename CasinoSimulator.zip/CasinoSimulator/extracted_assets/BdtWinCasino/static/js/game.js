document.addEventListener('DOMContentLoaded', function() {
    // Game tab switching functionality
    const gameTabs = document.querySelectorAll('.game-tab');
    const gameContents = document.querySelectorAll('.game-content');
    
    gameTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const gameType = this.getAttribute('data-game');
            
            // Update active tab
            gameTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding content
            gameContents.forEach(content => {
                if (content.getAttribute('data-game') === gameType) {
                    content.classList.add('active');
                } else {
                    content.classList.remove('active');
                }
            });
            
            // Update betting options and history for this game type
            updateGameData(gameType);
        });
    });
    
    // Betting option selection
    const betOptions = document.querySelectorAll('.bet-card');
    let selectedBetType = null;
    
    betOptions.forEach(option => {
        option.addEventListener('click', function() {
            const betType = this.getAttribute('data-bet-type');
            
            // Toggle selection
            betOptions.forEach(o => o.classList.remove('active'));
            this.classList.add('active');
            
            selectedBetType = betType;
            
            // Update place bet button status
            updatePlaceBetButtonStatus();
        });
    });
    
    // Quick amount selection
    const quickAmounts = document.querySelectorAll('.bet-quick-amount');
    const betAmountInput = document.getElementById('bet-amount');
    
    quickAmounts.forEach(btn => {
        btn.addEventListener('click', function() {
            const amount = this.getAttribute('data-amount');
            betAmountInput.value = amount;
            
            // Update place bet button status
            updatePlaceBetButtonStatus();
        });
    });
    
    // Bet amount input validation
    if (betAmountInput) {
        betAmountInput.addEventListener('input', function() {
            // Allow only numbers and decimal point
            this.value = this.value.replace(/[^0-9.]/g, '');
            
            // Ensure only one decimal point
            const parts = this.value.split('.');
            if (parts.length > 2) {
                this.value = parts[0] + '.' + parts.slice(1).join('');
            }
            
            // Update place bet button status
            updatePlaceBetButtonStatus();
        });
    }
    
    // Place bet button status update
    function updatePlaceBetButtonStatus() {
        const placeBetButton = document.getElementById('place-bet-btn');
        const betAmount = parseFloat(betAmountInput.value);
        const userBalance = parseFloat(document.getElementById('user-balance').getAttribute('data-balance'));
        
        if (placeBetButton) {
            if (!selectedBetType || !betAmount || isNaN(betAmount) || betAmount <= 0 || betAmount > userBalance) {
                placeBetButton.disabled = true;
            } else {
                placeBetButton.disabled = false;
            }
        }
    }
    
    // Place bet form submission
    const betForm = document.getElementById('bet-form');
    
    if (betForm) {
        betForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const activeTab = document.querySelector('.game-tab.active');
            const gameType = activeTab.getAttribute('data-game');
            const betAmount = parseFloat(betAmountInput.value);
            const userBalance = parseFloat(document.getElementById('user-balance').getAttribute('data-balance'));
            
            // Form validation
            if (!selectedBetType || !betAmount || isNaN(betAmount) || betAmount <= 0) {
                showGameAlert('Please select a bet type and enter a valid amount', 'error');
                return;
            }
            
            if (betAmount > userBalance) {
                showGameAlert('Insufficient balance', 'error');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('game_type', gameType);
            formData.append('bet_type', selectedBetType);
            formData.append('amount', betAmount);
            
            // Show loading state
            const placeBetButton = document.getElementById('place-bet-btn');
            const originalButtonText = placeBetButton.textContent;
            placeBetButton.disabled = true;
            placeBetButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
            
            // Submit bet via AJAX
            fetch('/game/place_bet', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update user balance
                    document.getElementById('user-balance').textContent = data.new_balance.toFixed(2);
                    document.getElementById('user-balance').setAttribute('data-balance', data.new_balance);
                    
                    // Show success message
                    showGameAlert(data.message, 'success');
                    
                    // Reset form
                    betOptions.forEach(o => o.classList.remove('active'));
                    selectedBetType = null;
                    betAmountInput.value = '';
                    
                    // Refresh bet history
                    updateBetHistory();
                } else {
                    showGameAlert(data.message || 'Error placing bet', 'error');
                }
            })
            .catch(error => {
                console.error('Error placing bet:', error);
                showGameAlert('Error placing bet. Please try again.', 'error');
            })
            .finally(() => {
                // Reset button state
                placeBetButton.disabled = false;
                placeBetButton.textContent = originalButtonText;
            });
        });
    }
    
    // Game countdown timer
    function updateCountdown() {
        fetch('/game/game_status')
            .then(response => response.json())
            .then(data => {
                // Update countdowns for both game types
                const countdown1min = document.getElementById('countdown-1min');
                const countdown30s = document.getElementById('countdown-30s');
                
                if (countdown1min) {
                    countdown1min.textContent = data['1min'].countdown;
                }
                
                if (countdown30s) {
                    countdown30s.textContent = data['30s'].countdown;
                }
                
                // When countdown reaches 0, update history
                if (data['1min'].countdown <= 1 || data['30s'].countdown <= 1) {
                    setTimeout(() => {
                        updateGameData();
                        updateBetHistory();
                        updateUserBalance();
                    }, 2000);
                }
            })
            .catch(error => console.error('Error updating countdown:', error));
    }
    
    // Start the countdown timer
    setInterval(updateCountdown, 1000);
    
    // Update game data (history, stats)
    function updateGameData(gameType = null) {
        if (!gameType) {
            // If no game type specified, update both
            updateGameHistory('1min');
            updateGameHistory('30s');
        } else {
            updateGameHistory(gameType);
        }
    }
    
    function updateGameHistory(gameType) {
        fetch(`/game/recent_results?game_type=${gameType}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const historyContainer = document.getElementById(`history-numbers-${gameType}`);
                    
                    if (historyContainer) {
                        // Clear existing history
                        historyContainer.innerHTML = '';
                        
                        // Add new history items
                        data.results.forEach(result => {
                            const historyNumber = document.createElement('div');
                            historyNumber.className = `history-number ${result.is_red ? 'red' : 'green'}`;
                            historyNumber.textContent = result.number;
                            historyContainer.appendChild(historyNumber);
                        });
                    }
                    
                    // Update pattern statistics
                    updatePatternStats(gameType, data.results);
                }
            })
            .catch(error => console.error(`Error updating ${gameType} history:`, error));
    }
    
    function updatePatternStats(gameType, results) {
        // Skip if no results
        if (!results || results.length === 0) return;
        
        // Count patterns
        let redCount = 0;
        let greenCount = 0;
        let bigCount = 0;
        let smallCount = 0;
        
        results.forEach(result => {
            if (result.is_red) redCount++;
            else greenCount++;
            
            if (result.is_big) bigCount++;
            else smallCount++;
        });
        
        // Update pattern display
        const redPattern = document.getElementById(`pattern-red-${gameType}`);
        const greenPattern = document.getElementById(`pattern-green-${gameType}`);
        const bigPattern = document.getElementById(`pattern-big-${gameType}`);
        const smallPattern = document.getElementById(`pattern-small-${gameType}`);
        
        if (redPattern) redPattern.textContent = redCount;
        if (greenPattern) greenPattern.textContent = greenCount;
        if (bigPattern) bigPattern.textContent = bigCount;
        if (smallPattern) smallPattern.textContent = smallCount;
    }
    
    // Update user's bet history
    function updateBetHistory() {
        const betHistoryContainer = document.getElementById('bet-history-container');
        
        if (!betHistoryContainer) return;
        
        // Add loading spinner
        betHistoryContainer.innerHTML = `
            <div class="spinner-container">
                <div class="spinner"></div>
            </div>
        `;
        
        // Fetch latest bets for user
        fetch('/game/my_bets')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.bets.length === 0) {
                        betHistoryContainer.innerHTML = '<p class="text-center text-muted">No bet history yet</p>';
                        return;
                    }
                    
                    let html = '';
                    
                    data.bets.forEach(bet => {
                        let statusClass = '';
                        let statusText = '';
                        
                        if (bet.won === true) {
                            statusClass = 'won';
                            statusText = 'Won';
                        } else if (bet.won === false) {
                            statusClass = 'lost';
                            statusText = 'Lost';
                        } else {
                            statusClass = 'pending';
                            statusText = 'Pending';
                        }
                        
                        html += `
                            <div class="bet-item">
                                <div class="bet-details">
                                    <div class="bet-game">${bet.game_type} Game - ${new Date(bet.created_at).toLocaleTimeString()}</div>
                                    <div class="bet-type ${bet.bet_type}">${bet.bet_type.charAt(0).toUpperCase() + bet.bet_type.slice(1)}</div>
                                    <div class="bet-amount">₹${bet.amount.toFixed(2)}</div>
                                </div>
                                <div class="bet-result">
                                    <div class="bet-status ${statusClass}">${statusText}</div>
                                    <div class="bet-payout ${statusClass}">${bet.won ? '₹' + bet.payout.toFixed(2) : '-'}</div>
                                </div>
                            </div>
                        `;
                    });
                    
                    betHistoryContainer.innerHTML = html;
                } else {
                    betHistoryContainer.innerHTML = '<p class="text-center text-danger">Error loading bet history</p>';
                }
            })
            .catch(error => {
                console.error('Error updating bet history:', error);
                betHistoryContainer.innerHTML = '<p class="text-center text-danger">Error loading bet history</p>';
            });
    }
    
    // Update user balance
    function updateUserBalance() {
        fetch('/user_balance')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const userBalanceElement = document.getElementById('user-balance');
                    
                    if (userBalanceElement) {
                        userBalanceElement.textContent = data.balance.toFixed(2);
                        userBalanceElement.setAttribute('data-balance', data.balance);
                        
                        // Update place bet button status
                        updatePlaceBetButtonStatus();
                    }
                }
            })
            .catch(error => console.error('Error updating user balance:', error));
    }
    
    // Initialize the game page
    function initGamePage() {
        // Load initial game data
        updateGameData();
        updateBetHistory();
        
        // Set first tab as active by default
        if (gameTabs.length > 0 && gameContents.length > 0) {
            gameTabs[0].classList.add('active');
            gameContents[0].classList.add('active');
        }
    }
    
    // Initialize if we're on the game page
    if (document.querySelector('.game-container')) {
        initGamePage();
    }
});

// Helper function to show alert messages in game
function showGameAlert(message, type) {
    const alertContainer = document.getElementById('game-alert-container');
    
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alertDiv);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}
