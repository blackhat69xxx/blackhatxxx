document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar on mobile
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const adminSidebar = document.querySelector('.admin-sidebar');
    
    if (sidebarToggle && adminSidebar) {
        sidebarToggle.addEventListener('click', function() {
            adminSidebar.classList.toggle('active');
        });
    }
    
    // Transaction approval handling
    const approveButtons = document.querySelectorAll('.approve-transaction');
    const rejectButtons = document.querySelectorAll('.reject-transaction');
    
    approveButtons.forEach(button => {
        button.addEventListener('click', function() {
            const transactionId = this.getAttribute('data-id');
            
            if (confirm('Are you sure you want to approve this transaction?')) {
                // Show loading state
                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                
                // Submit form for approval
                document.getElementById(`approve-form-${transactionId}`).submit();
            }
        });
    });
    
    rejectButtons.forEach(button => {
        button.addEventListener('click', function() {
            const transactionId = this.getAttribute('data-id');
            
            if (confirm('Are you sure you want to reject this transaction?')) {
                // Show loading state
                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                
                // Submit form for rejection
                document.getElementById(`reject-form-${transactionId}`).submit();
            }
        });
    });
    
    // Game result preview handling
    const gameResultForm = document.querySelectorAll('.game-result-form');
    
    gameResultForm.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const gameType = this.getAttribute('data-game-type');
            const resultInput = this.querySelector('.result-input');
            const result = parseInt(resultInput.value);
            
            if (isNaN(result) || result < 1 || result > 9) {
                showAdminAlert('Result must be a number between 1 and 9', 'error');
                return;
            }
            
            // Show loading state
            const submitButton = this.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Setting...';
            
            // Create form data
            const formData = new FormData();
            formData.append('game_type', gameType);
            formData.append('result', result);
            
            // Submit via AJAX
            fetch('/admin/set_game_result', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAdminAlert(data.message, 'success');
                    
                    // Update the preview
                    const previewElement = document.getElementById(`preview-result-${gameType}`);
                    if (previewElement) {
                        previewElement.textContent = result;
                        
                        // Update class based on red/green
                        if (result % 2 === 1) {
                            previewElement.className = 'preview-result red';
                        } else {
                            previewElement.className = 'preview-result green';
                        }
                    }
                    
                    // Update details
                    const isRedElement = document.getElementById(`preview-is-red-${gameType}`);
                    const isBigElement = document.getElementById(`preview-is-big-${gameType}`);
                    
                    if (isRedElement) isRedElement.textContent = result % 2 === 1 ? 'Red' : 'Green';
                    if (isBigElement) isBigElement.textContent = result > 4 ? 'Big' : 'Small';
                } else {
                    showAdminAlert(data.message || 'Error setting game result', 'error');
                }
            })
            .catch(error => {
                console.error('Error setting game result:', error);
                showAdminAlert('Error setting game result. Please try again.', 'error');
            })
            .finally(() => {
                // Reset button state
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
            });
        });
    });
    
    // User search handling
    const userSearchForm = document.getElementById('user-search-form');
    
    if (userSearchForm) {
        userSearchForm.addEventListener('submit', function(e) {
            // Form will submit normally, no need to prevent default
            // This is just to show a loading state
            const submitButton = this.querySelector('button[type="submit"]');
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Searching...';
        });
    }
    
    // Transaction filter handling
    const transactionFilterForm = document.getElementById('transaction-filter-form');
    
    if (transactionFilterForm) {
        const typeSelect = document.getElementById('filter-type');
        const statusSelect = document.getElementById('filter-status');
        
        // Auto-submit form when filters change
        if (typeSelect) {
            typeSelect.addEventListener('change', function() {
                transactionFilterForm.submit();
            });
        }
        
        if (statusSelect) {
            statusSelect.addEventListener('change', function() {
                transactionFilterForm.submit();
            });
        }
    }
    
    // Dashboard charts and statistics
    const transactionChart = document.getElementById('transaction-chart');
    const betChart = document.getElementById('bet-chart');
    
    if (window.Chart) {
        if (transactionChart) {
            new Chart(transactionChart, {
                type: 'line',
                data: {
                    labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
                    datasets: [
                        {
                            label: 'Deposits',
                            data: [65, 59, 80, 81, 56, 55, 40],
                            borderColor: '#27ae60',
                            backgroundColor: 'rgba(39, 174, 96, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Withdrawals',
                            data: [28, 48, 40, 19, 86, 27, 90],
                            borderColor: '#ff3131',
                            backgroundColor: 'rgba(255, 49, 49, 0.1)',
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#b0b0b0'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#b0b0b0'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: {
                                color: '#f5f5f5'
                            }
                        }
                    }
                }
            });
        }
        
        if (betChart) {
            new Chart(betChart, {
                type: 'doughnut',
                data: {
                    labels: ['Red', 'Green', 'Big', 'Small'],
                    datasets: [
                        {
                            data: [30, 25, 25, 20],
                            backgroundColor: ['#ff3131', '#27ae60', '#f39c12', '#3498db']
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                color: '#f5f5f5'
                            }
                        }
                    }
                }
            });
        }
    }
});

// Helper function to show alert messages in admin area
function showAdminAlert(message, type) {
    const alertContainer = document.getElementById('admin-alert-container');
    
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alertDiv);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}
