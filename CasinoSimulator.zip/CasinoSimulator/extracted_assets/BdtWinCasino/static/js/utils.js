// Format currency
function formatCurrency(amount) {
    return '৳' + parseFloat(amount).toFixed(2);
}

// Format date and time
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

// Get time ago string
function timeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval >= 1) {
        return interval + ' year' + (interval === 1 ? '' : 's') + ' ago';
    }
    
    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) {
        return interval + ' month' + (interval === 1 ? '' : 's') + ' ago';
    }
    
    interval = Math.floor(seconds / 86400);
    if (interval >= 1) {
        return interval + ' day' + (interval === 1 ? '' : 's') + ' ago';
    }
    
    interval = Math.floor(seconds / 3600);
    if (interval >= 1) {
        return interval + ' hour' + (interval === 1 ? '' : 's') + ' ago';
    }
    
    interval = Math.floor(seconds / 60);
    if (interval >= 1) {
        return interval + ' minute' + (interval === 1 ? '' : 's') + ' ago';
    }
    
    return Math.floor(seconds) + ' second' + (seconds === 1 ? '' : 's') + ' ago';
}

// Validate Bangladesh phone number
function isValidBangladeshPhone(phone) {
    const phonePattern = /^\+?88?01[3-9]\d{8}$/;
    return phonePattern.test(phone);
}

// Copy text to clipboard
function copyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
}

// Show loading spinner
function showLoading(element, text = 'Loading...') {
    const originalContent = element.innerHTML;
    element.setAttribute('data-original-content', originalContent);
    element.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${text}`;
    element.disabled = true;
}

// Hide loading spinner
function hideLoading(element) {
    const originalContent = element.getAttribute('data-original-content');
    if (originalContent) {
        element.innerHTML = originalContent;
        element.removeAttribute('data-original-content');
        element.disabled = false;
    }
}

// Confirm action with custom dialog
function confirmAction(message, confirmCallback, cancelCallback = null) {
    if (confirm(message)) {
        if (typeof confirmCallback === 'function') {
            confirmCallback();
        }
    } else if (typeof cancelCallback === 'function') {
        cancelCallback();
    }
}

// Capitalize first letter of string
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Get color class based on transaction status
function getStatusColorClass(status) {
    switch(status.toLowerCase()) {
        case 'approved':
            return 'text-success';
        case 'rejected':
            return 'text-danger';
        case 'pending':
            return 'text-warning';
        default:
            return '';
    }
}

// Get color class based on bet type
function getBetTypeColorClass(betType) {
    switch(betType.toLowerCase()) {
        case 'red':
            return 'color-red';
        case 'green':
            return 'color-green';
        case 'big':
            return 'text-warning';
        case 'small':
            return 'text-info';
        default:
            return '';
    }
}

// Get random animation delay for elements
function getRandomDelay() {
    return (Math.random() * 0.5).toFixed(2) + 's';
}
