document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const loginTab = document.getElementById('login-tab');
    const registerTab = document.getElementById('register-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    // Preselect +880 for phone number inputs
    const loginPhone = document.getElementById('login-phone');
    const registerPhone = document.getElementById('register-phone');
    const forgotPhone = document.getElementById('forgot-phone');
    
    // Set default value for phone inputs
    if (loginPhone && !loginPhone.value) {
        loginPhone.value = '+880';
    }
    
    if (registerPhone && !registerPhone.value) {
        registerPhone.value = '+880';
    }
    
    if (forgotPhone && !forgotPhone.value) {
        forgotPhone.value = '+880';
    }
    
    if (loginTab && registerTab) {
        loginTab.addEventListener('click', function() {
            loginTab.classList.add('active');
            registerTab.classList.remove('active');
            loginForm.style.display = 'block';
            registerForm.style.display = 'none';
        });
        
        registerTab.addEventListener('click', function() {
            registerTab.classList.add('active');
            loginTab.classList.remove('active');
            registerForm.style.display = 'block';
            loginForm.style.display = 'none';
        });
    }
    
    // Captcha generation and refresh
    const captchaQuestion = document.getElementById('captcha-question');
    const captchaRefresh = document.getElementById('captcha-refresh');
    
    function generateCaptcha() {
        fetch('/auth/generate_captcha')
            .then(response => response.json())
            .then(data => {
                if (captchaQuestion) {
                    captchaQuestion.textContent = data.question;
                }
            })
            .catch(error => console.error('Error generating captcha:', error));
    }
    
    if (captchaRefresh) {
        captchaRefresh.addEventListener('click', function(e) {
            e.preventDefault();
            generateCaptcha();
        });
    }
    
    // Generate captcha on page load
    if (captchaQuestion) {
        generateCaptcha();
    }
    
    // Form validation
    const loginFormElement = document.getElementById('login-form');
    const registerFormElement = document.getElementById('register-form');
    
    if (loginFormElement) {
        loginFormElement.addEventListener('submit', function(e) {
            const phone = document.getElementById('login-phone').value;
            const password = document.getElementById('login-password').value;
            
            if (!phone || !password) {
                e.preventDefault();
                showAlert('Please fill in all fields', 'error');
            }
        });
    }
    
    if (registerFormElement) {
        registerFormElement.addEventListener('submit', function(e) {
            const phone = document.getElementById('register-phone').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            const captcha = document.getElementById('register-captcha').value;
            
            if (!phone || !password || !confirmPassword || !captcha) {
                e.preventDefault();
                showAlert('Please fill in all fields', 'error');
                return;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                showAlert('Passwords do not match', 'error');
                return;
            }
            
            // Simple phone validation for Bangladesh
            const phonePattern = /^\+?88?01[3-9]\d{8}$/;
            if (!phonePattern.test(phone)) {
                e.preventDefault();
                showAlert('Please enter a valid Bangladesh phone number', 'error');
                return;
            }
            
            // Password strength validation
            if (password.length < 6) {
                e.preventDefault();
                showAlert('Password must be at least 6 characters', 'error');
                return;
            }
        });
    }
    
    // Success message animation
    const successMessage = document.querySelector('.success-message');
    if (successMessage) {
        setTimeout(() => {
            successMessage.classList.add('fade-in');
        }, 300);
    }
    
    // Forgot password form validation
    const forgotForm = document.getElementById('forgot-password-form');
    if (forgotForm) {
        forgotForm.addEventListener('submit', function(e) {
            const phone = document.getElementById('forgot-phone').value;
            
            if (!phone) {
                e.preventDefault();
                showAlert('Please enter your phone number', 'error');
                return;
            }
            
            // Simple phone validation for Bangladesh
            const phonePattern = /^\+?88?01[3-9]\d{8}$/;
            if (!phonePattern.test(phone)) {
                e.preventDefault();
                showAlert('Please enter a valid Bangladesh phone number', 'error');
                return;
            }
        });
    }
    
    // OTP verification form validation
    const otpForm = document.getElementById('otp-form');
    if (otpForm) {
        otpForm.addEventListener('submit', function(e) {
            const otpCode = document.getElementById('otp-code').value;
            
            if (!otpCode || otpCode.length !== 6) {
                e.preventDefault();
                showAlert('Please enter a valid 6-digit OTP', 'error');
                return;
            }
        });
    }
    
    // Reset password form validation
    const resetForm = document.getElementById('reset-password-form');
    if (resetForm) {
        resetForm.addEventListener('submit', function(e) {
            const password = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-new-password').value;
            
            if (!password || !confirmPassword) {
                e.preventDefault();
                showAlert('Please fill in all fields', 'error');
                return;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                showAlert('Passwords do not match', 'error');
                return;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                showAlert('Password must be at least 6 characters', 'error');
                return;
            }
        });
    }
});

// Helper function to show alert messages
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alertDiv);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}
