from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify
from app import db
from models import User, Transaction
from datetime import datetime

payment_bp = Blueprint('payment', __name__, url_prefix='/payment')

@payment_bp.route('/deposit')
def deposit():
    """Render deposit page"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user = User.query.get(session['user_id'])
    
    # Get user's recent deposits
    recent_deposits = Transaction.query.filter_by(
        user_id=user.id, 
        type='deposit'
    ).order_by(Transaction.created_at.desc()).limit(5).all()
    
    return render_template('deposit.html', user=user, recent_deposits=recent_deposits)

@payment_bp.route('/deposit', methods=['POST'])
def deposit_submit():
    """Handle deposit form submission"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user_id = session['user_id']
    
    amount = float(request.form.get('amount', 0))
    payment_method = request.form.get('payment_method')
    transaction_id = request.form.get('transaction_id')
    phone = request.form.get('phone')
    
    # Validate input
    if amount <= 0:
        flash('Please enter a valid amount', 'error')
        return redirect(url_for('payment.deposit'))
    
    if not payment_method or payment_method not in ['bKash', 'Nagad']:
        flash('Please select a valid payment method', 'error')
        return redirect(url_for('payment.deposit'))
    
    if not transaction_id:
        flash('Please enter your transaction ID', 'error')
        return redirect(url_for('payment.deposit'))
    
    if not phone:
        flash('Please enter your payment phone number', 'error')
        return redirect(url_for('payment.deposit'))
    
    # Create deposit transaction
    transaction = Transaction(
        user_id=user_id,
        amount=amount,
        type='deposit',
        status='pending',
        payment_method=payment_method,
        payment_details=f"Transaction ID: {transaction_id}, Phone: {phone}"
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    flash('Deposit request submitted successfully! It will be processed shortly.', 'success')
    return redirect(url_for('payment.deposit'))

@payment_bp.route('/withdraw')
def withdraw():
    """Render withdrawal page"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user = User.query.get(session['user_id'])
    
    # Get user's recent withdrawals
    recent_withdrawals = Transaction.query.filter_by(
        user_id=user.id, 
        type='withdrawal'
    ).order_by(Transaction.created_at.desc()).limit(5).all()
    
    return render_template('withdraw.html', user=user, recent_withdrawals=recent_withdrawals)

@payment_bp.route('/withdraw', methods=['POST'])
def withdraw_submit():
    """Handle withdrawal form submission"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    amount = float(request.form.get('amount', 0))
    payment_method = request.form.get('payment_method')
    phone = request.form.get('phone')
    
    # Validate input
    if amount <= 0:
        flash('Please enter a valid amount', 'error')
        return redirect(url_for('payment.withdraw'))
    
    if not payment_method or payment_method not in ['bKash', 'Nagad']:
        flash('Please select a valid payment method', 'error')
        return redirect(url_for('payment.withdraw'))
    
    if not phone:
        flash('Please enter your payment phone number', 'error')
        return redirect(url_for('payment.withdraw'))
    
    # Check if user has sufficient balance
    if user.balance < amount:
        flash('Insufficient balance', 'error')
        return redirect(url_for('payment.withdraw'))
    
    # Create withdrawal transaction
    transaction = Transaction(
        user_id=user_id,
        amount=amount,
        type='withdrawal',
        status='pending',
        payment_method=payment_method,
        payment_details=f"Phone: {phone}"
    )
    
    # Don't deduct from balance until approved by admin
    
    db.session.add(transaction)
    db.session.commit()
    
    flash('Withdrawal request submitted successfully! It will be processed shortly.', 'success')
    return redirect(url_for('payment.withdraw'))

@payment_bp.route('/transactions')
def transactions():
    """View user's transaction history"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login_register'))
    
    user_id = session['user_id']
    
    # Get all transactions for this user
    transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).all()
    
    return render_template('transactions.html', transactions=transactions)
