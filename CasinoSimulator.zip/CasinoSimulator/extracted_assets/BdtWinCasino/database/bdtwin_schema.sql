-- BDT-WIN Casino Database Schema

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    phone VARCHAR(20) NOT NULL UNIQUE,
    password_hash VARCHAR(256) NOT NULL,
    balance DECIMAL(15, 2) DEFAULT 0.00,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create default admin user (password: admin123)
INSERT INTO users (phone, password_hash, balance, is_admin)
VALUES ('01712345678', 'pbkdf2:sha256:150000$KU99uaVg$456898ea76f83dcdbb3e34028fd1c0cfbf2f52dc62beac966acbad048a2c6b91', 10000.00, TRUE);

-- Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    type VARCHAR(20) NOT NULL,  -- 'deposit' or 'withdrawal'
    status VARCHAR(20) DEFAULT 'pending',  -- 'pending', 'approved', 'rejected'
    payment_method VARCHAR(20),  -- 'bKash', 'Nagad', etc.
    payment_details TEXT,  -- Transaction ID, phone number, etc.
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Game Results Table
CREATE TABLE IF NOT EXISTS game_results (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    game_type VARCHAR(20) NOT NULL,  -- '1min' or '30s'
    result_number INTEGER NOT NULL,  -- The actual number result
    is_red BOOLEAN,  -- TRUE if red, FALSE if green
    is_big BOOLEAN,  -- TRUE if big (>4), FALSE if small (≤4)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Bets Table
CREATE TABLE IF NOT EXISTS bets (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    game_result_id INTEGER NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    bet_type VARCHAR(20) NOT NULL,  -- 'red', 'green', 'big', 'small'
    won BOOLEAN,  -- TRUE if won, FALSE if lost, NULL if pending
    payout DECIMAL(15, 2),  -- Amount won, NULL if pending or lost
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_result_id) REFERENCES game_results(id)
);

-- OTP Table
CREATE TABLE IF NOT EXISTS otps (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    phone VARCHAR(20) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    purpose VARCHAR(20) NOT NULL,  -- 'registration', 'login', 'reset_password'
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for better performance
CREATE INDEX idx_user_phone ON users(phone);
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_type ON transactions(type);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_game_results_game_type ON game_results(game_type);
CREATE INDEX idx_bets_user_id ON bets(user_id);
CREATE INDEX idx_bets_game_result_id ON bets(game_result_id);
CREATE INDEX idx_otps_phone ON otps(phone);
