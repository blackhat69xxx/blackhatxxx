import random
import string
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, OTP

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login_register')
def login_register():
    """Render the combined login/register page"""
    if 'user_id' in session:
        return redirect(url_for('game.game_page'))
    return render_template('login_register.html')

@auth_bp.route('/login', methods=['POST'])
def login():
    """Handle user login"""
    phone = request.form.get('phone')
    password = request.form.get('password')
    
    # Validate input
    if not phone or not password:
        flash('Please provide both phone number and password', 'error')
        return redirect(url_for('auth.login_register'))
    
    user = User.query.filter_by(phone=phone).first()
    
    if not user or not user.check_password(password):
        flash('Invalid phone number or password', 'error')
        return redirect(url_for('auth.login_register'))
    
    # Set session data
    session['user_id'] = user.id
    session['is_admin'] = user.is_admin
    
    flash('Login successful!', 'success')
    
    # Redirect admin users to admin dashboard
    if user.is_admin:
        return redirect(url_for('admin.dashboard'))
    
    return redirect(url_for('game.game_page'))

@auth_bp.route('/register', methods=['POST'])
def register():
    """Handle user registration"""
    phone = request.form.get('phone')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    captcha = request.form.get('captcha')
    captcha_answer = session.get('captcha_answer')
    
    # Validate input
    if not phone or not password or not confirm_password or not captcha:
        flash('All fields are required', 'error')
        return redirect(url_for('auth.login_register'))
    
    if password != confirm_password:
        flash('Passwords do not match', 'error')
        return redirect(url_for('auth.login_register'))
    
    if captcha != captcha_answer:
        flash('Invalid captcha', 'error')
        return redirect(url_for('auth.login_register'))
    
    # Check if user already exists
    existing_user = User.query.filter_by(phone=phone).first()
    if existing_user:
        flash('Phone number already registered', 'error')
        return redirect(url_for('auth.login_register'))
    
    # Create new user
    new_user = User(phone=phone)
    new_user.set_password(password)
    
    db.session.add(new_user)
    db.session.commit()
    
    flash('Registration successful! Please login', 'success')
    return redirect(url_for('auth.login_register'))

@auth_bp.route('/logout')
def logout():
    """Handle user logout"""
    session.pop('user_id', None)
    session.pop('is_admin', None)
    flash('You have been logged out', 'success')
    return redirect(url_for('auth.login_register'))

@auth_bp.route('/forgot_password')
def forgot_password():
    """Render forgot password page"""
    return render_template('forgot.html')

@auth_bp.route('/forgot_password', methods=['POST'])
def forgot_password_submit():
    """Handle forgot password submission"""
    phone = request.form.get('phone')
    
    if not phone:
        flash('Please provide your phone number', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    user = User.query.filter_by(phone=phone).first()
    
    if not user:
        flash('No account found with that phone number', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    # Generate OTP
    otp_code = ''.join(random.choices(string.digits, k=6))
    expires_at = datetime.utcnow() + timedelta(minutes=15)
    
    # Store OTP in database
    otp = OTP(
        phone=phone,
        otp_code=otp_code,
        purpose='reset_password',
        expires_at=expires_at
    )
    
    db.session.add(otp)
    db.session.commit()
    
    # In a real implementation, send the OTP via SMS
    # For this example, we'll display it in the flash message
    flash(f'OTP sent to your phone: {otp_code}', 'success')
    
    # Store phone in session for verification step
    session['reset_phone'] = phone
    
    return redirect(url_for('auth.verify_otp'))

@auth_bp.route('/verify_otp')
def verify_otp():
    """Render OTP verification page"""
    if 'reset_phone' not in session:
        flash('Please start the password reset process', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    return render_template('verify_otp.html')

@auth_bp.route('/verify_otp', methods=['POST'])
def verify_otp_submit():
    """Handle OTP verification submission"""
    otp_code = request.form.get('otp_code')
    
    if not otp_code:
        flash('Please provide the OTP sent to your phone', 'error')
        return redirect(url_for('auth.verify_otp'))
    
    phone = session.get('reset_phone')
    
    if not phone:
        flash('Please start the password reset process', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    # Verify OTP
    otp = OTP.query.filter_by(
        phone=phone,
        otp_code=otp_code,
        purpose='reset_password'
    ).order_by(OTP.created_at.desc()).first()
    
    if not otp or otp.expires_at < datetime.utcnow():
        flash('Invalid or expired OTP', 'error')
        return redirect(url_for('auth.verify_otp'))
    
    # OTP verified, allow password reset
    session['otp_verified'] = True
    
    return redirect(url_for('auth.reset_password'))

@auth_bp.route('/reset_password')
def reset_password():
    """Render reset password page"""
    if 'reset_phone' not in session or 'otp_verified' not in session:
        flash('Please complete the verification process', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    return render_template('reset_password.html')

@auth_bp.route('/reset_password', methods=['POST'])
def reset_password_submit():
    """Handle reset password submission"""
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    
    if not password or not confirm_password:
        flash('Please provide and confirm your new password', 'error')
        return redirect(url_for('auth.reset_password'))
    
    if password != confirm_password:
        flash('Passwords do not match', 'error')
        return redirect(url_for('auth.reset_password'))
    
    phone = session.get('reset_phone')
    
    if not phone or 'otp_verified' not in session:
        flash('Please complete the verification process', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    # Update user password
    user = User.query.filter_by(phone=phone).first()
    
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    user.set_password(password)
    db.session.commit()
    
    # Clear session data
    session.pop('reset_phone', None)
    session.pop('otp_verified', None)
    
    flash('Password reset successful! Please login with your new password', 'success')
    return redirect(url_for('auth.login_register'))

@auth_bp.route('/generate_captcha')
def generate_captcha():
    """Generate a simple math captcha"""
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    answer = num1 + num2
    
    session['captcha_answer'] = str(answer)
    
    return jsonify({
        'question': f'{num1} + {num2} = ?'
    })
