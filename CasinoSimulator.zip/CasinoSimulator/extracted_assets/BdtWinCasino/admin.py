from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify, abort, Response
from app import db, app
from models import User, Transaction, GameResult, Bet
from datetime import datetime, timedelta
import csv
import io
import functools
import logging

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    """Decorator to ensure only admins can access admin routes"""
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in', 'error')
            return redirect(url_for('auth.login_register'))
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            app.logger.warning(f"Unauthorized access attempt to admin area by user ID: {session.get('user_id')}")
            flash('Admin access required', 'error')
            return redirect(url_for('game.game_page'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.before_request
def check_admin():
    """Middleware to ensure only admins can access admin routes"""
    # Skip the check for static resources
    if request.path.startswith('/static'):
        return
        
    if request.endpoint and 'admin' in request.endpoint:
        if 'user_id' not in session:
            flash('Please log in', 'error')
            return redirect(url_for('auth.login_register'))
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            app.logger.warning(f"Unauthorized access attempt to admin area by user ID: {session.get('user_id')}")
            flash('Admin access required', 'error')
            return redirect(url_for('game.game_page'))

@admin_bp.route('/')
@admin_required
def dashboard():
    """Admin dashboard page"""
    # Get counts for dashboard
    user_count = User.query.filter_by(is_admin=False).count()
    pending_deposits = Transaction.query.filter_by(type='deposit', status='pending').count()
    pending_withdrawals = Transaction.query.filter_by(type='withdrawal', status='pending').count()
    
    # Get game statistics
    total_bets = Bet.query.count()
    total_bet_amount = db.session.query(db.func.sum(Bet.amount)).scalar() or 0
    total_payout = db.session.query(db.func.sum(Bet.payout)).scalar() or 0
    
    # Get recent transactions
    recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(5).all()
    
    # Get today's statistics
    today = datetime.now().date()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    today_deposits = db.session.query(db.func.sum(Transaction.amount)).filter(
        Transaction.type == 'deposit',
        Transaction.status == 'approved',
        Transaction.created_at.between(today_start, today_end)
    ).scalar() or 0
    
    today_withdrawals = db.session.query(db.func.sum(Transaction.amount)).filter(
        Transaction.type == 'withdrawal',
        Transaction.status == 'approved',
        Transaction.created_at.between(today_start, today_end)
    ).scalar() or 0
    
    # Get today's bets
    today_bets_count = Bet.query.filter(Bet.created_at.between(today_start, today_end)).count()
    today_bet_amount = db.session.query(db.func.sum(Bet.amount)).filter(
        Bet.created_at.between(today_start, today_end)
    ).scalar() or 0
    today_payout = db.session.query(db.func.sum(Bet.payout)).filter(
        Bet.created_at.between(today_start, today_end),
        Bet.won == True
    ).scalar() or 0
    
    # Get new users from today
    new_users_today = User.query.filter(
        User.created_at.between(today_start, today_end),
        User.is_admin == False
    ).count()
    
    return render_template('admin/dashboard.html',
                          user_count=user_count,
                          pending_deposits=pending_deposits,
                          pending_withdrawals=pending_withdrawals,
                          total_bets=total_bets,
                          total_bet_amount=total_bet_amount,
                          total_payout=total_payout,
                          profit=total_bet_amount - total_payout,
                          recent_transactions=recent_transactions,
                          today_deposits=today_deposits,
                          today_withdrawals=today_withdrawals,
                          today_bets_count=today_bets_count,
                          today_bet_amount=today_bet_amount,
                          today_payout=today_payout,
                          today_profit=today_bet_amount - today_payout,
                          new_users_today=new_users_today)

@admin_bp.route('/transactions')
@admin_required
def transactions():
    """Admin transactions management page"""
    transaction_type = request.args.get('type', 'all')
    status = request.args.get('status', 'all')
    search = request.args.get('search', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Base query
    query = Transaction.query.join(User, Transaction.user_id == User.id)
    
    # Apply filters
    if transaction_type != 'all':
        query = query.filter(Transaction.type == transaction_type)
    
    if status != 'all':
        query = query.filter(Transaction.status == status)
        
    if search:
        query = query.filter(User.phone.like(f'%{search}%'))
    
    if date_from:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
            query = query.filter(Transaction.created_at >= date_from_obj)
        except ValueError:
            flash('Invalid date format for Date From', 'error')
    
    if date_to:
        try:
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d')
            date_to_obj = datetime.combine(date_to_obj.date(), datetime.max.time())
            query = query.filter(Transaction.created_at <= date_to_obj)
        except ValueError:
            flash('Invalid date format for Date To', 'error')
    
    # Get transactions with pagination
    page = request.args.get('page', 1, type=int)
    per_page = 20
    transactions = query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Get summary statistics for filtered transactions
    total_count = query.count()
    total_deposits = db.session.query(db.func.sum(Transaction.amount)).filter(
        Transaction.type == 'deposit',
        Transaction.id.in_([t.id for t in query.all()])
    ).scalar() or 0
    
    total_withdrawals = db.session.query(db.func.sum(Transaction.amount)).filter(
        Transaction.type == 'withdrawal',
        Transaction.id.in_([t.id for t in query.all()])
    ).scalar() or 0
    
    return render_template('admin/transactions.html', 
                          transactions=transactions,
                          transaction_type=transaction_type,
                          status=status,
                          search=search,
                          date_from=date_from,
                          date_to=date_to,
                          total_count=total_count,
                          total_deposits=total_deposits,
                          total_withdrawals=total_withdrawals)

@admin_bp.route('/export_transactions')
@admin_required
def export_transactions():
    """Export transactions to CSV"""
    transaction_type = request.args.get('type', 'all')
    status = request.args.get('status', 'all')
    search = request.args.get('search', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Base query
    query = Transaction.query.join(User, Transaction.user_id == User.id)
    
    # Apply same filters as in transactions view
    if transaction_type != 'all':
        query = query.filter(Transaction.type == transaction_type)
    
    if status != 'all':
        query = query.filter(Transaction.status == status)
        
    if search:
        query = query.filter(User.phone.like(f'%{search}%'))
    
    if date_from:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
            query = query.filter(Transaction.created_at >= date_from_obj)
        except ValueError:
            pass
    
    if date_to:
        try:
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d')
            date_to_obj = datetime.combine(date_to_obj.date(), datetime.max.time())
            query = query.filter(Transaction.created_at <= date_to_obj)
        except ValueError:
            pass
    
    # Get all transactions matching the filter
    transactions = query.order_by(Transaction.created_at.desc()).all()
    
    # Create CSV file in memory
    si = io.StringIO()
    writer = csv.writer(si)
    
    # Write header
    writer.writerow(['Transaction ID', 'Date', 'User Phone', 'Type', 'Amount', 'Method', 'Details', 'Status'])
    
    # Write transaction data
    for tx in transactions:
        writer.writerow([
            tx.id,
            tx.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            tx.user.phone,
            tx.type.capitalize(),
            f'৳{tx.amount:.2f}',
            tx.payment_method,
            tx.payment_details,
            tx.status.capitalize()
        ])
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output = si.getvalue()
    si.close()
    
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-disposition": f"attachment; filename=transactions_{timestamp}.csv"}
    )

@admin_bp.route('/approve_transaction/<int:id>', methods=['POST'])
@admin_required
def approve_transaction(id):
    """Approve a pending transaction"""
    transaction = Transaction.query.get_or_404(id)
    
    if transaction.status != 'pending':
        flash('Transaction is not in pending status', 'error')
        return redirect(url_for('admin.transactions'))
    
    # Get user to verify balance
    user = User.query.get(transaction.user_id)
    
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('admin.transactions'))
    
    # Record the current balance for logging
    previous_balance = user.balance
    
    # For withdrawals, ensure user has sufficient balance
    if transaction.type == 'withdrawal' and user.balance < transaction.amount:
        flash('User has insufficient balance', 'error')
        return redirect(url_for('admin.transactions'))
    
    # Update transaction status
    transaction.status = 'approved'
    transaction.updated_at = datetime.now()
    
    # Update user balance
    if transaction.type == 'deposit':
        user.balance += transaction.amount
    elif transaction.type == 'withdrawal':
        user.balance -= transaction.amount
    
    # Log the action
    admin_user = User.query.get(session['user_id'])
    app.logger.info(f"Transaction {id} ({transaction.type}) of BDT {transaction.amount} approved by admin {admin_user.phone}. " +
                  f"User {user.phone} balance changed from {previous_balance} to {user.balance}")
    
    # Save changes
    db.session.commit()
    
    # Return JSON response if it's an AJAX request
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True, 
            'message': 'Transaction approved successfully',
            'transaction_id': transaction.id,
            'new_status': 'approved',
            'user_balance': user.balance
        })
    
    # Otherwise redirect to the transactions page
    flash('Transaction approved successfully', 'success')
    return redirect(url_for('admin.transactions'))

@admin_bp.route('/reject_transaction/<int:id>', methods=['POST'])
@admin_required
def reject_transaction(id):
    """Reject a pending transaction"""
    transaction = Transaction.query.get_or_404(id)
    
    if transaction.status != 'pending':
        flash('Transaction is not in pending status', 'error')
        return redirect(url_for('admin.transactions'))
    
    # Get user info for logging
    user = User.query.get(transaction.user_id)
    
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('admin.transactions'))
    
    # Update transaction status
    transaction.status = 'rejected'
    transaction.updated_at = datetime.now()
    
    # Log the action
    admin_user = User.query.get(session['user_id'])
    app.logger.info(f"Transaction {id} ({transaction.type}) of BDT {transaction.amount} rejected by admin {admin_user.phone}. " +
                  f"User {user.phone}.")
    
    # Save changes
    db.session.commit()
    
    # Return JSON response if it's an AJAX request
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True, 
            'message': 'Transaction rejected successfully',
            'transaction_id': transaction.id,
            'new_status': 'rejected'
        })
    
    # Otherwise redirect to the transactions page
    flash('Transaction rejected successfully', 'success')
    return redirect(url_for('admin.transactions'))

@admin_bp.route('/game_preview')
@admin_required
def game_preview():
    """Admin game result preview and management"""
    # Get next results from game state (imported from game module)
    from game import game_state
    
    next_result_1min = game_state['1min']['next_result']
    next_result_30s = game_state['30s']['next_result']
    
    # Get recent results
    recent_results_1min = GameResult.query.filter_by(game_type='1min').order_by(GameResult.created_at.desc()).limit(20).all()
    recent_results_30s = GameResult.query.filter_by(game_type='30s').order_by(GameResult.created_at.desc()).limit(20).all()
    
    # Calculate statistics for each game
    total_results_1min = GameResult.query.filter_by(game_type='1min').count()
    total_results_30s = GameResult.query.filter_by(game_type='30s').count()
    
    # Get latest active bets
    active_bets_1min = Bet.query.join(GameResult).filter(
        GameResult.game_type == '1min',
        Bet.won == None
    ).order_by(Bet.created_at.desc()).limit(10).all()
    
    active_bets_30s = Bet.query.join(GameResult).filter(
        GameResult.game_type == '30s', 
        Bet.won == None
    ).order_by(Bet.created_at.desc()).limit(10).all()
    
    # Calculate win/loss balance by game type
    total_bet_amount_1min = db.session.query(db.func.sum(Bet.amount)).join(GameResult).filter(
        GameResult.game_type == '1min'
    ).scalar() or 0
    
    total_payout_1min = db.session.query(db.func.sum(Bet.payout)).join(GameResult).filter(
        GameResult.game_type == '1min',
        Bet.won == True
    ).scalar() or 0
    
    total_bet_amount_30s = db.session.query(db.func.sum(Bet.amount)).join(GameResult).filter(
        GameResult.game_type == '30s'
    ).scalar() or 0
    
    total_payout_30s = db.session.query(db.func.sum(Bet.payout)).join(GameResult).filter(
        GameResult.game_type == '30s',
        Bet.won == True
    ).scalar() or 0
    
    # For detailed analysis of patterns, count occurrences of each number
    number_counts_1min = {}
    for num in range(1, 10):
        count = GameResult.query.filter_by(game_type='1min', result_number=num).count()
        number_counts_1min[num] = count
    
    number_counts_30s = {}
    for num in range(1, 10):
        count = GameResult.query.filter_by(game_type='30s', result_number=num).count()
        number_counts_30s[num] = count
    
    return render_template('admin/game_preview.html',
                          next_result_1min=next_result_1min,
                          next_result_30s=next_result_30s,
                          recent_results_1min=recent_results_1min,
                          recent_results_30s=recent_results_30s,
                          game_state=game_state,
                          total_results_1min=total_results_1min,
                          total_results_30s=total_results_30s,
                          active_bets_1min=active_bets_1min,
                          active_bets_30s=active_bets_30s,
                          total_bet_amount_1min=total_bet_amount_1min,
                          total_payout_1min=total_payout_1min,
                          profit_1min=total_bet_amount_1min - total_payout_1min,
                          total_bet_amount_30s=total_bet_amount_30s,
                          total_payout_30s=total_payout_30s,
                          profit_30s=total_bet_amount_30s - total_payout_30s,
                          number_counts_1min=number_counts_1min,
                          number_counts_30s=number_counts_30s)

@admin_bp.route('/set_game_result', methods=['POST'])
@admin_required
def set_game_result():
    """Set the next game result (admin override)"""
    game_type = request.form.get('game_type')
    result = int(request.form.get('result', 1))
    
    if game_type not in ['1min', '30s']:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Invalid game type'})
        flash('Invalid game type', 'error')
        return redirect(url_for('admin.game_preview'))
    
    if result < 1 or result > 9:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Result must be between 1 and 9'})
        flash('Result must be between 1 and 9', 'error')
        return redirect(url_for('admin.game_preview'))
    
    # Update the next result in game state
    from game import game_state
    
    # Record previous result for logging
    previous_result = game_state[game_type]['next_result']
    game_state[game_type]['next_result'] = result
    
    # Determine color and size for the frontend
    is_red = result % 2 == 1  # Red if odd
    is_big = result > 4  # Big if > 4
    
    # Log the action
    admin_user = User.query.get(session['user_id'])
    app.logger.info(f"Game result for {game_type} changed from {previous_result} to {result} by admin {admin_user.phone if admin_user else 'Unknown'}")
    
    # Return JSON response if it's an AJAX request
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True,
            'message': f'Next result for {game_type} game set to {result}',
            'result': result,
            'is_red': is_red,
            'is_big': is_big,
            'color_name': 'Red' if is_red else 'Green',
            'size_name': 'Big' if is_big else 'Small'
        })
    
    # Otherwise flash and redirect
    flash(f'Next result for {game_type} game set to {result}', 'success')
    return redirect(url_for('admin.game_preview'))

@admin_bp.route('/users')
@admin_required
def users():
    """Admin user management page"""
    search_term = request.args.get('search', '')
    filter_type = request.args.get('filter', 'all')
    
    # Base query
    query = User.query
    
    # Apply search filter if provided
    if search_term:
        query = query.filter(User.phone.like(f'%{search_term}%'))
    
    # Apply user type filter
    if filter_type == 'admin':
        query = query.filter(User.is_admin == True)
    elif filter_type == 'user':
        query = query.filter(User.is_admin == False)
    
    # Get users with pagination
    page = request.args.get('page', 1, type=int)
    per_page = 20
    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Get user statistics
    total_users = User.query.count()
    total_admins = User.query.filter_by(is_admin=True).count()
    total_regular_users = User.query.filter_by(is_admin=False).count()
    
    total_user_balance = db.session.query(db.func.sum(User.balance)).scalar() or 0
    avg_user_balance = db.session.query(db.func.avg(User.balance)).filter(User.is_admin == False).scalar() or 0
    
    # Get recent users
    recent_users = User.query.filter_by(is_admin=False).order_by(User.created_at.desc()).limit(5).all()
    
    # Get bet statistics by user
    user_bet_stats = {}
    for user in recent_users:
        bet_count = Bet.query.filter_by(user_id=user.id).count()
        total_bet = db.session.query(db.func.sum(Bet.amount)).filter_by(user_id=user.id).scalar() or 0
        total_win = db.session.query(db.func.sum(Bet.payout)).filter_by(user_id=user.id, won=True).scalar() or 0
        
        user_bet_stats[user.id] = {
            'bet_count': bet_count,
            'total_bet': total_bet,
            'total_win': total_win,
            'net_profit': total_win - total_bet
        }
    
    return render_template('admin/users.html', 
                          users=users,
                          search_term=search_term,
                          filter_type=filter_type,
                          total_users=total_users,
                          total_admins=total_admins,
                          total_regular_users=total_regular_users,
                          total_user_balance=total_user_balance,
                          avg_user_balance=avg_user_balance,
                          recent_users=recent_users,
                          user_bet_stats=user_bet_stats)

@admin_bp.route('/edit_user/<int:id>', methods=['GET', 'POST'])
@admin_required
def edit_user(id):
    """Edit user details"""
    user = User.query.get_or_404(id)
    
    # Get user's transaction and bet history for the detail page
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    bets = Bet.query.filter_by(user_id=user.id).order_by(Bet.created_at.desc()).limit(10).all()
    
    # Calculate statistics
    total_deposits = db.session.query(db.func.sum(Transaction.amount)).filter_by(
        user_id=user.id, type='deposit', status='approved'
    ).scalar() or 0
    
    total_withdrawals = db.session.query(db.func.sum(Transaction.amount)).filter_by(
        user_id=user.id, type='withdrawal', status='approved'
    ).scalar() or 0
    
    total_bets = db.session.query(db.func.sum(Bet.amount)).filter_by(user_id=user.id).scalar() or 0
    total_wins = db.session.query(db.func.sum(Bet.payout)).filter_by(user_id=user.id, won=True).scalar() or 0
    
    if request.method == 'POST':
        # Get the original balance for logging
        original_balance = user.balance
        
        # Update user details
        new_balance = float(request.form.get('balance', user.balance))
        is_admin = 'is_admin' in request.form
        
        # Update user
        user.balance = new_balance
        user.is_admin = is_admin
        user.updated_at = datetime.now()
        
        # Log the action, especially balance changes
        admin_user = User.query.get(session['user_id'])
        if original_balance != new_balance:
            app.logger.info(f"User {user.phone} balance manually changed from {original_balance} to {new_balance} by admin {admin_user.phone if admin_user else 'Unknown'}")
        
        if user.is_admin != is_admin:
            app.logger.info(f"User {user.phone} admin status changed to {is_admin} by admin {admin_user.phone if admin_user else 'Unknown'}")
        
        db.session.commit()
        flash('User updated successfully', 'success')
        
        # Return JSON response if it's an AJAX request
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': True,
                'message': 'User updated successfully',
                'user': {
                    'id': user.id,
                    'phone': user.phone,
                    'balance': user.balance,
                    'is_admin': user.is_admin
                }
            })
        
        return redirect(url_for('admin.users'))
    
    return render_template('admin/edit_user.html', 
                          user=user,
                          transactions=transactions,
                          bets=bets,
                          total_deposits=total_deposits,
                          total_withdrawals=total_withdrawals,
                          total_bets=total_bets,
                          total_wins=total_wins,
                          net_gambling=total_wins - total_bets)

@admin_bp.route('/user_transactions/<int:user_id>')
@admin_required
def user_transactions(user_id):
    """Get all transactions for a specific user"""
    user = User.query.get_or_404(user_id)
    
    # Get all transactions for the user
    transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).all()
    
    # Calculate totals
    total_deposits = db.session.query(db.func.sum(Transaction.amount)).filter_by(
        user_id=user_id, type='deposit', status='approved'
    ).scalar() or 0
    
    total_withdrawals = db.session.query(db.func.sum(Transaction.amount)).filter_by(
        user_id=user_id, type='withdrawal', status='approved'
    ).scalar() or 0
    
    return render_template('admin/user_transactions.html',
                          user=user,
                          transactions=transactions,
                          total_deposits=total_deposits,
                          total_withdrawals=total_withdrawals)

@admin_bp.route('/user_bets/<int:user_id>')
@admin_required
def user_bets(user_id):
    """Get all bets for a specific user"""
    user = User.query.get_or_404(user_id)
    
    # Get all bets for the user
    bets = Bet.query.filter_by(user_id=user_id).order_by(Bet.created_at.desc()).all()
    
    # Calculate betting statistics
    total_bet_amount = db.session.query(db.func.sum(Bet.amount)).filter_by(user_id=user_id).scalar() or 0
    total_winnings = db.session.query(db.func.sum(Bet.payout)).filter_by(user_id=user_id, won=True).scalar() or 0
    
    win_count = Bet.query.filter_by(user_id=user_id, won=True).count()
    loss_count = Bet.query.filter_by(user_id=user_id, won=False).count()
    
    win_rate = (win_count / (win_count + loss_count) * 100) if (win_count + loss_count) > 0 else 0
    
    return render_template('admin/user_bets.html',
                          user=user,
                          bets=bets,
                          total_bet_amount=total_bet_amount,
                          total_winnings=total_winnings,
                          net_profit=total_winnings - total_bet_amount,
                          win_count=win_count,
                          loss_count=loss_count,
                          win_rate=win_rate)
