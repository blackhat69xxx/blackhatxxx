<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Get transaction ID and action
$transactionId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Validate input
if ($transactionId <= 0 || !in_array($action, ['approve', 'reject'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request parameters']);
    exit;
}

// Get transaction details
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
$stmt->bind_param("i", $transactionId);
$stmt->execute();
$transaction = $stmt->get_result()->fetch_assoc();

if (!$transaction) {
    echo json_encode(['success' => false, 'message' => 'Transaction not found']);
    exit;
}

// Check if transaction is already processed
if ($transaction['status'] !== 'pending') {
    echo json_encode(['success' => false, 'message' => 'Transaction is already processed']);
    exit;
}

// Process transaction based on action
$db->beginTransaction();

try {
    // Update transaction status
    $status = $action === 'approve' ? 'completed' : 'rejected';
    updateTransactionStatus($transactionId, $status);
    
    // If approving a deposit, update user balance
    if ($action === 'approve' && $transaction['type'] === 'deposit') {
        updateUserBalance($transaction['user_id'], abs($transaction['amount']));
    }
    
    // If rejecting a withdrawal, refund the amount
    if ($action === 'reject' && $transaction['type'] === 'withdrawal') {
        // Refund the withdrawal amount to user's balance
        updateUserBalance($transaction['user_id'], abs($transaction['amount']));
        
        // Create a refund transaction record
        createTransaction(
            $transaction['user_id'],
            'refund',
            abs($transaction['amount']),
            $transaction['payment_method'],
            'Refund for transaction #' . $transactionId,
            'completed'
        );
    }
    
    // Commit transaction
    $db->commit();
    
    echo json_encode(['success' => true, 'message' => 'Transaction ' . $action . 'd successfully']);
} catch (Exception $e) {
    // Rollback transaction
    $db->rollback();
    
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
