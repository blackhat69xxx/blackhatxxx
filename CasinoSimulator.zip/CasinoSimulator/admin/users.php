<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$adminData = $stmt->get_result()->fetch_assoc();

// Handle user status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    
    if ($userId > 0 && in_array($status, ['active', 'suspended'])) {
        $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $userId);
        
        if ($stmt->execute()) {
            $success = "User status updated successfully.";
        } else {
            $error = "Failed to update user status.";
        }
    } else {
        $error = "Invalid request parameters.";
    }
}

// Get filter parameters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query
$query = "SELECT * FROM users WHERE 1=1";
$countQuery = "SELECT COUNT(*) as total FROM users WHERE 1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND (phone LIKE ?)";
    $countQuery .= " AND (phone LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $types .= "s";
}

if (!empty($status)) {
    $query .= " AND status = ?";
    $countQuery .= " AND status = ?";
    $params[] = $status;
    $types .= "s";
}

// Add sorting and pagination
$query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

// Prepare and execute count query
$stmt = $conn->prepare($countQuery);
if (!empty($params)) {
    $typesCopy = substr($types, 0, -2); // Remove the 'ii' for limit and offset
    $paramsCopy = array_slice($params, 0, -2); // Remove limit and offset params
    
    if (!empty($paramsCopy)) {
        $stmt->bind_param($typesCopy, ...$paramsCopy);
    }
}
$stmt->execute();
$totalRecords = $stmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);

// Prepare and execute main query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Page title
$pageTitle = 'Manage Users';

// Include header
include 'templates/header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <div class="admin-title">
            <h2><?php echo $pageTitle; ?></h2>
        </div>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="admin-alert admin-alert-success">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="admin-alert admin-alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <div class="admin-table-container">
        <div class="admin-table-header">
            <div class="admin-filter-form">
                <form method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="admin-filters">
                    <div class="filter-group">
                        <label for="status">Status:</label>
                        <select name="status" id="status" class="admin-form-control">
                            <option value="">All</option>
                            <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="suspended" <?php echo $status === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="search">Search:</label>
                        <input type="text" name="search" id="search" class="admin-form-control" value="<?php echo htmlspecialchars($search); ?>" placeholder="Phone number">
                    </div>
                    
                    <div class="filter-group">
                        <button type="submit" class="admin-btn admin-btn-primary">Filter</button>
                        <a href="users.php" class="admin-btn admin-btn-secondary">Reset</a>
                    </div>
                </form>
            </div>
        </div>
        
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Phone</th>
                    <th>Balance</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">No users found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo $user['phone']; ?></td>
                            <td><?php echo formatAmount($user['balance']); ?></td>
                            <td>
                                <span class="admin-table-status status-<?php echo $user['status']; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($user['created_at'])); ?></td>
                            <td><?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                            <td class="admin-table-actions">
                                <button class="btn-view" data-id="<?php echo $user['id']; ?>">View</button>
                                <?php if ($user['status'] === 'active'): ?>
                                    <button class="btn-suspend" data-id="<?php echo $user['id']; ?>">Suspend</button>
                                <?php else: ?>
                                    <button class="btn-activate" data-id="<?php echo $user['id']; ?>">Activate</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div class="admin-pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $status; ?>&search=<?php echo $search; ?>" class="admin-btn admin-btn-secondary">Previous</a>
                <?php endif; ?>
                
                <div class="admin-pagination-info">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $status; ?>&search=<?php echo $search; ?>" class="admin-btn admin-btn-secondary">Next</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- User Action Modal -->
<div class="modal" id="userModal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>User Details</h3>
        <div id="userDetails"></div>
        <div class="modal-actions">
            <button id="confirmAction" class="admin-btn admin-btn-primary">Confirm</button>
            <button id="cancelAction" class="admin-btn admin-btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<script>
    // Handle user view
    document.querySelectorAll('.btn-view').forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            
            // Get user details with AJAX
            fetch(`get_user.php?id=${userId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Format user details
                    const user = data.user;
                    let detailsHtml = `
                        <div class="user-detail-item">
                            <strong>ID:</strong> ${user.id}
                        </div>
                        <div class="user-detail-item">
                            <strong>Phone:</strong> ${user.phone}
                        </div>
                        <div class="user-detail-item">
                            <strong>Balance:</strong> ${parseFloat(user.balance).toFixed(2)} BDT
                        </div>
                        <div class="user-detail-item">
                            <strong>Status:</strong> ${user.status}
                        </div>
                        <div class="user-detail-item">
                            <strong>Created:</strong> ${new Date(user.created_at).toLocaleString()}
                        </div>
                        <div class="user-detail-item">
                            <strong>Last Login:</strong> ${user.last_login ? new Date(user.last_login).toLocaleString() : 'Never'}
                        </div>
                    `;
                    
                    const modal = document.getElementById('userModal');
                    const details = document.getElementById('userDetails');
                    const confirmBtn = document.getElementById('confirmAction');
                    const cancelBtn = document.getElementById('cancelAction');
                    
                    details.innerHTML = detailsHtml;
                    modal.style.display = 'block';
                    
                    // Hide action buttons for view mode
                    confirmBtn.style.display = 'none';
                    cancelBtn.textContent = 'Close';
                    
                    // Set up close button
                    cancelBtn.onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close button
                    document.querySelector('.close').onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close modal when clicking outside
                    window.onclick = function(event) {
                        if (event.target === modal) {
                            modal.style.display = 'none';
                        }
                    };
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
    
    // Handle user suspend/activate
    document.querySelectorAll('.btn-suspend, .btn-activate').forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            const action = this.classList.contains('btn-suspend') ? 'suspend' : 'activate';
            
            // Show confirmation modal
            const modal = document.getElementById('userModal');
            const details = document.getElementById('userDetails');
            const confirmBtn = document.getElementById('confirmAction');
            
            details.innerHTML = `Are you sure you want to <strong>${action}</strong> this user?`;
            modal.style.display = 'block';
            
            // Show action buttons
            confirmBtn.style.display = 'inline-block';
            document.getElementById('cancelAction').textContent = 'Cancel';
            
            // Set up confirm button
            confirmBtn.onclick = function() {
                // Create form and submit
                const form = document.createElement('form');
                form.method = 'post';
                form.action = 'users.php';
                
                const userIdInput = document.createElement('input');
                userIdInput.type = 'hidden';
                userIdInput.name = 'user_id';
                userIdInput.value = userId;
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = action === 'suspend' ? 'suspended' : 'active';
                
                const updateInput = document.createElement('input');
                updateInput.type = 'hidden';
                updateInput.name = 'update_status';
                updateInput.value = '1';
                
                form.appendChild(userIdInput);
                form.appendChild(statusInput);
                form.appendChild(updateInput);
                
                document.body.appendChild(form);
                form.submit();
            };
            
            // Set up cancel button
            document.getElementById('cancelAction').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close button
            document.querySelector('.close').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close modal when clicking outside
            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            };
        });
    });
</script>

<?php
// Include footer
include 'templates/footer.php';
?>
