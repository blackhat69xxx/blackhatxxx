<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$adminData = $stmt->get_result()->fetch_assoc();

// Process form submission for creating a new game round
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_game'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        $gameType = $_POST['game_type'];
        $resultNumber = (int)$_POST['result_number'];
        $resultColor = $_POST['result_color'];
        $isSmall = ($resultNumber < 5) ? 1 : 0;
        
        // Calculate start and end times
        $now = new DateTime();
        $startTime = $now->format('Y-m-d H:i:s');
        
        // Set end time based on game type
        if ($gameType === 'wingo_1min') {
            $endTime = $now->modify('+1 minute')->format('Y-m-d H:i:s');
        } else {
            $endTime = $now->modify('+30 seconds')->format('Y-m-d H:i:s');
        }
        
        // Insert the new game round
        $stmt = $conn->prepare("INSERT INTO game_rounds (game_type, result_number, result_color, is_small, start_time, end_time, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisissi", $gameType, $resultNumber, $resultColor, $isSmall, $startTime, $endTime, $adminId);
        
        if ($stmt->execute()) {
            $success = true;
            $message = "Game round created successfully!";
        } else {
            $error = "Failed to create game round: " . $conn->error;
        }
    }
}

// Get game rounds - paginated
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Count total rows for pagination
$countStmt = $conn->prepare("SELECT COUNT(*) as total FROM game_rounds");
$countStmt->execute();
$totalRecords = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);

// Get game rounds
$stmt = $conn->prepare("SELECT * FROM game_rounds ORDER BY start_time DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$gameRounds = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get upcoming games
$now = date('Y-m-d H:i:s');
$stmt = $conn->prepare("SELECT * FROM game_rounds WHERE end_time > ? ORDER BY start_time ASC LIMIT 5");
$stmt->bind_param("s", $now);
$stmt->execute();
$upcomingGames = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Page title
$pageTitle = 'Manage Game Results';

// Include header
include 'templates/header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <div class="admin-title">
            <h2><?php echo $pageTitle; ?></h2>
        </div>
    </div>
    
    <?php if (isset($success) && $success): ?>
        <div class="admin-alert admin-alert-success">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="admin-alert admin-alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <div class="admin-cards">
        <?php foreach ($upcomingGames as $game): ?>
            <div class="admin-card">
                <div class="admin-card-header">
                    <div class="admin-card-title">Upcoming Game #<?php echo $game['id']; ?></div>
                </div>
                <div class="admin-card-value result-<?php echo $game['result_color']; ?>"><?php echo $game['result_number']; ?></div>
                <div class="admin-card-description">
                    <?php echo $game['game_type'] === 'wingo_1min' ? '1 Minute Game' : '30 Second Game'; ?> <br>
                    <?php echo ucfirst($game['result_color']); ?> / <?php echo $game['is_small'] ? 'Small' : 'Big'; ?>
                </div>
                <div class="admin-card-footer">
                    <div class="countdown" data-end="<?php echo $game['end_time']; ?>">
                        <?php 
                            $endTime = new DateTime($game['end_time']);
                            $now = new DateTime();
                            $interval = $now->diff($endTime);
                            echo sprintf('%02d:%02d', $interval->i, $interval->s);
                        ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div class="admin-form-container">
        <h3 class="admin-form-title">Create New Game Round</h3>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            <input type="hidden" name="create_game" value="1">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="admin-form-group">
                        <label>Game Type:</label>
                        <div class="admin-radio-group">
                            <label class="admin-radio">
                                <input type="radio" name="game_type" value="wingo_1min" checked> 1 Minute Game
                            </label>
                            <label class="admin-radio">
                                <input type="radio" name="game_type" value="wingo_30sec"> 30 Second Game
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="game-result-form">
                        <div class="result-field">
                            <div class="result-field-title">Result Number:</div>
                            <div class="number-grid">
                                <?php for ($i = 0; $i <= 9; $i++): ?>
                                    <div class="number-item" data-number="<?php echo $i; ?>"><?php echo $i; ?></div>
                                <?php endfor; ?>
                            </div>
                            <input type="hidden" name="result_number" id="result-number-input" value="0">
                        </div>
                        
                        <div class="result-field">
                            <div class="result-field-title">Result Color:</div>
                            <div class="color-options">
                                <div class="color-option color-red" data-color="red">Red</div>
                                <div class="color-option color-green" data-color="green">Green</div>
                            </div>
                            <input type="hidden" name="result_color" id="result-color-input" value="red">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="admin-form-buttons">
                <button type="submit" class="admin-btn admin-btn-primary">Create Game Round</button>
            </div>
        </form>
    </div>
    
    <div class="admin-table-container">
        <div class="admin-table-header">
            <div class="admin-table-title">Recent Game Rounds</div>
        </div>
        
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Game Type</th>
                    <th>Result</th>
                    <th>Color</th>
                    <th>Size</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Created By</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($gameRounds)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">No game rounds found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($gameRounds as $round): ?>
                        <tr>
                            <td><?php echo $round['id']; ?></td>
                            <td><?php echo $round['game_type'] === 'wingo_1min' ? '1 Minute Game' : '30 Second Game'; ?></td>
                            <td class="result-<?php echo $round['result_color']; ?>"><?php echo $round['result_number']; ?></td>
                            <td class="result-<?php echo $round['result_color']; ?>"><?php echo ucfirst($round['result_color']); ?></td>
                            <td><?php echo $round['is_small'] ? 'Small' : 'Big'; ?></td>
                            <td><?php echo date('M d, Y H:i:s', strtotime($round['start_time'])); ?></td>
                            <td><?php echo date('M d, Y H:i:s', strtotime($round['end_time'])); ?></td>
                            <td><?php echo $round['created_by'] ? 'Admin #' . $round['created_by'] : 'System'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div class="admin-pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="admin-btn admin-btn-secondary">Previous</a>
                <?php endif; ?>
                
                <div class="admin-pagination-info">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="admin-btn admin-btn-secondary">Next</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    // Handle number selection
    document.querySelectorAll('.number-item').forEach(item => {
        item.addEventListener('click', function() {
            // Remove selected class from all items
            document.querySelectorAll('.number-item').forEach(i => i.classList.remove('selected'));
            
            // Add selected class to clicked item
            this.classList.add('selected');
            
            // Update hidden input
            document.getElementById('result-number-input').value = this.getAttribute('data-number');
            
            // Update color automatically based on number
            const number = parseInt(this.getAttribute('data-number'));
            const isEven = number % 2 === 0;
            
            // Red is even (0, 2, 4, 6, 8), Green is odd (1, 3, 5, 7, 9)
            if (isEven) {
                document.querySelector('.color-option[data-color="red"]').click();
            } else {
                document.querySelector('.color-option[data-color="green"]').click();
            }
        });
    });
    
    // Handle color selection
    document.querySelectorAll('.color-option').forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            document.querySelectorAll('.color-option').forEach(o => o.classList.remove('selected'));
            
            // Add selected class to clicked option
            this.classList.add('selected');
            
            // Update hidden input
            document.getElementById('result-color-input').value = this.getAttribute('data-color');
        });
    });
    
    // Select default values
    document.querySelector('.number-item[data-number="0"]').classList.add('selected');
    document.querySelector('.color-option[data-color="red"]').classList.add('selected');
    
    // Update countdown timers
    function updateCountdowns() {
        document.querySelectorAll('.countdown').forEach(countdown => {
            const endTime = new Date(countdown.getAttribute('data-end')).getTime();
            const now = new Date().getTime();
            const distance = endTime - now;
            
            if (distance <= 0) {
                countdown.textContent = '00:00';
                countdown.classList.add('expired');
            } else {
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);
                countdown.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        });
    }
    
    // Update countdowns every second
    setInterval(updateCountdowns, 1000);
</script>

<?php
// Include footer
include 'templates/footer.php';
?>
