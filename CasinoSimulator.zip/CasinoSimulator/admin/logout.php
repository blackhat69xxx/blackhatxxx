<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Logout admin
logoutAdmin();

// Redirect to login page
header('Location: login.php');
exit;
?>
