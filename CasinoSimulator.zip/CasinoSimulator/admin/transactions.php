<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$adminData = $stmt->get_result()->fetch_assoc();

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query
$query = "SELECT t.*, u.phone FROM transactions t JOIN users u ON t.user_id = u.id WHERE 1=1";
$countQuery = "SELECT COUNT(*) as total FROM transactions t JOIN users u ON t.user_id = u.id WHERE 1=1";
$params = [];
$types = "";

if (!empty($status)) {
    $query .= " AND t.status = ?";
    $countQuery .= " AND t.status = ?";
    $params[] = $status;
    $types .= "s";
}

if (!empty($type)) {
    $query .= " AND t.type = ?";
    $countQuery .= " AND t.type = ?";
    $params[] = $type;
    $types .= "s";
}

if (!empty($search)) {
    $query .= " AND (u.phone LIKE ? OR t.transaction_ref LIKE ?)";
    $countQuery .= " AND (u.phone LIKE ? OR t.transaction_ref LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $types .= "ss";
}

// Add sorting and pagination
$query .= " ORDER BY t.created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

// Prepare and execute count query
$stmt = $conn->prepare($countQuery);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalRecords = $stmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);

// Prepare and execute main query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Page title
$pageTitle = 'Manage Transactions';

// Include header
include 'templates/header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <div class="admin-title">
            <h2><?php echo $pageTitle; ?></h2>
        </div>
    </div>
    
    <div class="admin-table-container">
        <div class="admin-table-header">
            <div class="admin-filter-form">
                <form method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="admin-filters">
                    <div class="filter-group">
                        <label for="status">Status:</label>
                        <select name="status" id="status" class="admin-form-control">
                            <option value="">All</option>
                            <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="type">Type:</label>
                        <select name="type" id="type" class="admin-form-control">
                            <option value="">All</option>
                            <option value="deposit" <?php echo $type === 'deposit' ? 'selected' : ''; ?>>Deposit</option>
                            <option value="withdrawal" <?php echo $type === 'withdrawal' ? 'selected' : ''; ?>>Withdrawal</option>
                            <option value="bet" <?php echo $type === 'bet' ? 'selected' : ''; ?>>Bet</option>
                            <option value="win" <?php echo $type === 'win' ? 'selected' : ''; ?>>Win</option>
                            <option value="refund" <?php echo $type === 'refund' ? 'selected' : ''; ?>>Refund</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="search">Search:</label>
                        <input type="text" name="search" id="search" class="admin-form-control" value="<?php echo htmlspecialchars($search); ?>" placeholder="Phone or Ref ID">
                    </div>
                    
                    <div class="filter-group">
                        <button type="submit" class="admin-btn admin-btn-primary">Filter</button>
                        <a href="transactions.php" class="admin-btn admin-btn-secondary">Reset</a>
                    </div>
                </form>
            </div>
        </div>
        
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transactions)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center;">No transactions found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($transactions as $tx): ?>
                        <tr>
                            <td><?php echo $tx['id']; ?></td>
                            <td><?php echo $tx['phone']; ?></td>
                            <td><?php echo ucfirst($tx['type']); ?></td>
                            <td><?php echo number_format($tx['amount'], 2); ?> BDT</td>
                            <td><?php echo $tx['payment_method'] ? $tx['payment_method'] : '-'; ?></td>
                            <td><?php echo $tx['transaction_ref'] ? $tx['transaction_ref'] : '-'; ?></td>
                            <td>
                                <span class="admin-table-status status-<?php echo $tx['status']; ?>">
                                    <?php echo ucfirst($tx['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?></td>
                            <td class="admin-table-actions">
                                <?php if ($tx['status'] === 'pending'): ?>
                                    <button class="btn-approve" data-id="<?php echo $tx['id']; ?>" data-type="<?php echo $tx['type']; ?>">Approve</button>
                                    <button class="btn-reject" data-id="<?php echo $tx['id']; ?>" data-type="<?php echo $tx['type']; ?>">Reject</button>
                                <?php else: ?>
                                    <button class="btn-view" data-id="<?php echo $tx['id']; ?>">View</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div class="admin-pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $status; ?>&type=<?php echo $type; ?>&search=<?php echo $search; ?>" class="admin-btn admin-btn-secondary">Previous</a>
                <?php endif; ?>
                
                <div class="admin-pagination-info">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $status; ?>&type=<?php echo $type; ?>&search=<?php echo $search; ?>" class="admin-btn admin-btn-secondary">Next</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Transaction Action Modal -->
<div class="modal" id="transactionModal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Transaction Details</h3>
        <div id="transactionDetails"></div>
        <div class="modal-actions">
            <button id="confirmAction" class="admin-btn admin-btn-primary">Confirm</button>
            <button id="cancelAction" class="admin-btn admin-btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<script>
    // Handle transaction approval/rejection
    document.querySelectorAll('.btn-approve, .btn-reject').forEach(button => {
        button.addEventListener('click', function() {
            const txId = this.getAttribute('data-id');
            const txType = this.getAttribute('data-type');
            const action = this.classList.contains('btn-approve') ? 'approve' : 'reject';
            
            // Show confirmation modal
            const modal = document.getElementById('transactionModal');
            const details = document.getElementById('transactionDetails');
            const confirmBtn = document.getElementById('confirmAction');
            
            details.innerHTML = `Are you sure you want to <strong>${action}</strong> the ${txType} transaction #${txId}?`;
            modal.style.display = 'block';
            
            // Set up confirm button
            confirmBtn.onclick = function() {
                // Process the action
                fetch(`process_transaction.php?id=${txId}&action=${action}`, {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`Transaction ${action}d successfully!`);
                        window.location.reload();
                    } else {
                        alert(`Error: ${data.message}`);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
                
                // Close the modal
                modal.style.display = 'none';
            };
            
            // Set up cancel button
            document.getElementById('cancelAction').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close button
            document.querySelector('.close').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close modal when clicking outside
            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            };
        });
    });
    
    // Handle view transaction
    document.querySelectorAll('.btn-view').forEach(button => {
        button.addEventListener('click', function() {
            const txId = this.getAttribute('data-id');
            
            // Fetch transaction details
            fetch(`get_transaction.php?id=${txId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show details modal
                    const modal = document.getElementById('transactionModal');
                    const details = document.getElementById('transactionDetails');
                    const confirmBtn = document.getElementById('confirmAction');
                    const cancelBtn = document.getElementById('cancelAction');
                    
                    // Format transaction details
                    let detailsHtml = `
                        <div class="transaction-detail-item">
                            <strong>ID:</strong> ${data.transaction.id}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>User:</strong> ${data.transaction.phone}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Type:</strong> ${data.transaction.type}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Amount:</strong> ${parseFloat(data.transaction.amount).toFixed(2)} BDT
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Payment Method:</strong> ${data.transaction.payment_method || '-'}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Reference:</strong> ${data.transaction.transaction_ref || '-'}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Status:</strong> ${data.transaction.status}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Created:</strong> ${new Date(data.transaction.created_at).toLocaleString()}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Updated:</strong> ${data.transaction.updated_at ? new Date(data.transaction.updated_at).toLocaleString() : '-'}
                        </div>
                    `;
                    
                    details.innerHTML = detailsHtml;
                    modal.style.display = 'block';
                    
                    // Hide action buttons for view mode
                    confirmBtn.style.display = 'none';
                    cancelBtn.textContent = 'Close';
                    
                    // Set up close button
                    cancelBtn.onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close button
                    document.querySelector('.close').onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close modal when clicking outside
                    window.onclick = function(event) {
                        if (event.target === modal) {
                            modal.style.display = 'none';
                        }
                    };
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
</script>

<?php
// Include footer
include 'templates/footer.php';
?>
