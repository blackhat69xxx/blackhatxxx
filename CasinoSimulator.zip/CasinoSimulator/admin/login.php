<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Redirect if already logged in
if (isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$success = false;

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get and sanitize input
        $username = cleanInput($_POST['username']);
        $password = $_POST['password'];
        
        // Validate username
        if (empty($username)) {
            $errors[] = 'Username is required.';
        }
        
        // Validate password
        if (empty($password)) {
            $errors[] = 'Password is required.';
        }
        
        // Attempt login if no errors
        if (empty($errors)) {
            $result = loginAdmin($username, $password);
            
            if ($result['success']) {
                // Redirect to admin dashboard
                header('Location: index.php');
                exit;
            } else {
                $errors[] = $result['message'];
            }
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Page title
$pageTitle = 'Admin Login';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | <?php echo SITE_NAME; ?></title>
    
    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="../assets/images/logo.svg">
</head>
<body>
    <div class="admin-login-container">
        <div class="admin-login-form">
            <div class="admin-login-logo">
                <h1><span class="bdt-text">BDT-</span><span class="win-text">WIN</span> <span>Admin</span></h1>
            </div>
            
            <h2 class="admin-login-title">Admin Login</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="admin-alert admin-alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="admin-form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" class="admin-form-control" placeholder="Enter your username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                </div>
                
                <div class="admin-form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="admin-form-control" placeholder="Enter your password" required>
                </div>
                
                <button type="submit" class="admin-login-btn">Login</button>
            </form>
        </div>
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
