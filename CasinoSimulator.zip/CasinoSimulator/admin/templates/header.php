<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME . ' Admin' : SITE_NAME . ' Admin'; ?></title>
    
    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="../assets/images/logo.svg">
</head>
<body>
    <div class="admin-container">
        <!-- Admin Sidebar -->
        <div class="admin-sidebar" id="admin-sidebar">
            <div class="admin-logo">
                <h1><span class="bdt-text">BDT-</span><span class="win-text">WIN</span> <span>Admin</span></h1>
            </div>
            
            <ul class="admin-menu">
                <li class="admin-menu-item">
                    <a href="index.php" class="admin-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="users.php" class="admin-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>">
                        <i class="fa fa-users"></i> Users
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="transactions.php" class="admin-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'transactions.php' ? 'active' : ''; ?>">
                        <i class="fa fa-money-bill-transfer"></i> Transactions
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="game_results.php" class="admin-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'game_results.php' ? 'active' : ''; ?>">
                        <i class="fa fa-dice"></i> Game Results
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="logout.php" class="admin-menu-link">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Mobile Menu Toggle -->
        <div class="admin-menu-toggle" id="admin-menu-toggle">
            <span></span>
        </div>
