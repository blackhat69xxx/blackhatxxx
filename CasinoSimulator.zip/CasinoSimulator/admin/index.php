<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$adminData = $stmt->get_result()->fetch_assoc();

// Get dashboard stats
// Total users
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users");
$stmt->execute();
$totalUsers = $stmt->get_result()->fetch_assoc()['total'];

// Active users (last 24 hours)
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE last_login >= NOW() - INTERVAL 1 DAY");
$stmt->execute();
$activeUsers = $stmt->get_result()->fetch_assoc()['total'];

// Total deposits
$stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'deposit' AND status = 'completed'");
$stmt->execute();
$totalDeposits = $stmt->get_result()->fetch_assoc()['total'] ?: 0;

// Total withdrawals
$stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'withdrawal' AND status = 'completed'");
$stmt->execute();
$totalWithdrawals = $stmt->get_result()->fetch_assoc()['total'] ?: 0;

// Pending transactions
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM transactions WHERE status = 'pending'");
$stmt->execute();
$pendingTransactions = $stmt->get_result()->fetch_assoc()['total'];

// Recent activity (deposits, withdrawals)
$stmt = $conn->prepare("SELECT t.*, u.phone FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.type IN ('deposit', 'withdrawal') ORDER BY t.created_at DESC LIMIT 10");
$stmt->execute();
$recentTransactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Page title
$pageTitle = 'Admin Dashboard';

// Include header
include 'templates/header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <div class="admin-title">
            <h2><?php echo $pageTitle; ?></h2>
        </div>
        <div class="admin-user">
            <div class="admin-user-info">
                <div class="admin-user-name"><?php echo $adminData['username']; ?></div>
                <div class="admin-user-role"><?php echo ucfirst($adminData['role']); ?></div>
            </div>
            <form method="post" action="logout.php">
                <button type="submit" class="admin-logout">Logout</button>
            </form>
        </div>
    </div>
    
    <div class="admin-cards">
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">Total Users</div>
                <div class="admin-card-icon">
                    <i class="fa fa-users"></i>
                </div>
            </div>
            <div class="admin-card-value"><?php echo $totalUsers; ?></div>
            <div class="admin-card-description">Registered accounts</div>
            <div class="admin-card-footer">
                Active (24h): <?php echo $activeUsers; ?>
            </div>
        </div>
        
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">Total Deposits</div>
                <div class="admin-card-icon">
                    <i class="fa fa-arrow-down"></i>
                </div>
            </div>
            <div class="admin-card-value"><?php echo number_format($totalDeposits, 2); ?> BDT</div>
            <div class="admin-card-description">Total amount deposited</div>
        </div>
        
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">Total Withdrawals</div>
                <div class="admin-card-icon">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </div>
            <div class="admin-card-value"><?php echo number_format($totalWithdrawals, 2); ?> BDT</div>
            <div class="admin-card-description">Total amount withdrawn</div>
        </div>
        
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">Pending Transactions</div>
                <div class="admin-card-icon">
                    <i class="fa fa-clock"></i>
                </div>
            </div>
            <div class="admin-card-value"><?php echo $pendingTransactions; ?></div>
            <div class="admin-card-description">Transactions awaiting approval</div>
            <div class="admin-card-footer">
                <a href="transactions.php?status=pending">View all pending</a>
            </div>
        </div>
    </div>
    
    <div class="admin-table-container">
        <div class="admin-table-header">
            <div class="admin-table-title">Recent Transactions</div>
            <div class="admin-table-actions">
                <a href="transactions.php" class="admin-btn admin-btn-secondary">View All</a>
            </div>
        </div>
        
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentTransactions)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">No recent transactions found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentTransactions as $tx): ?>
                        <tr>
                            <td><?php echo $tx['id']; ?></td>
                            <td><?php echo $tx['phone']; ?></td>
                            <td><?php echo ucfirst($tx['type']); ?></td>
                            <td><?php echo number_format($tx['amount'], 2); ?> BDT</td>
                            <td><?php echo $tx['payment_method'] ? $tx['payment_method'] : '-'; ?></td>
                            <td>
                                <span class="admin-table-status status-<?php echo $tx['status']; ?>">
                                    <?php echo ucfirst($tx['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?></td>
                            <td class="admin-table-actions">
                                <?php if ($tx['status'] === 'pending'): ?>
                                    <button class="btn-approve" data-id="<?php echo $tx['id']; ?>" data-type="<?php echo $tx['type']; ?>">Approve</button>
                                    <button class="btn-reject" data-id="<?php echo $tx['id']; ?>" data-type="<?php echo $tx['type']; ?>">Reject</button>
                                <?php else: ?>
                                    <button class="btn-view" data-id="<?php echo $tx['id']; ?>">View</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <div class="admin-cards">
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">System Status</div>
                <div class="admin-card-icon">
                    <i class="fa fa-server"></i>
                </div>
            </div>
            <div class="admin-card-value">Online</div>
            <div class="admin-card-description">All systems operational</div>
            <div class="admin-card-footer">
                Last checked: <?php echo date('M d, Y H:i'); ?>
            </div>
        </div>
        
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="admin-card-title">Active Games</div>
                <div class="admin-card-icon">
                    <i class="fa fa-dice"></i>
                </div>
            </div>
            <div class="admin-card-value">2</div>
            <div class="admin-card-description">Running game types</div>
            <div class="admin-card-footer">
                <a href="game_results.php">Manage games</a>
            </div>
        </div>
    </div>
</div>

<!-- Transaction Action Modal -->
<div class="modal" id="transactionModal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Transaction Details</h3>
        <div id="transactionDetails"></div>
        <div class="modal-actions">
            <button id="confirmAction" class="admin-btn admin-btn-primary">Confirm</button>
            <button id="cancelAction" class="admin-btn admin-btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<script>
    // Handle transaction approval/rejection
    document.querySelectorAll('.btn-approve, .btn-reject').forEach(button => {
        button.addEventListener('click', function() {
            const txId = this.getAttribute('data-id');
            const txType = this.getAttribute('data-type');
            const action = this.classList.contains('btn-approve') ? 'approve' : 'reject';
            
            // Show confirmation modal
            const modal = document.getElementById('transactionModal');
            const details = document.getElementById('transactionDetails');
            const confirmBtn = document.getElementById('confirmAction');
            
            details.innerHTML = `Are you sure you want to <strong>${action}</strong> the ${txType} transaction #${txId}?`;
            modal.style.display = 'block';
            
            // Set up confirm button
            confirmBtn.onclick = function() {
                // Process the action
                fetch(`process_transaction.php?id=${txId}&action=${action}`, {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`Transaction ${action}d successfully!`);
                        window.location.reload();
                    } else {
                        alert(`Error: ${data.message}`);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
                
                // Close the modal
                modal.style.display = 'none';
            };
            
            // Set up cancel button
            document.getElementById('cancelAction').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close button
            document.querySelector('.close').onclick = function() {
                modal.style.display = 'none';
            };
            
            // Close modal when clicking outside
            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            };
        });
    });
    
    // Handle view transaction
    document.querySelectorAll('.btn-view').forEach(button => {
        button.addEventListener('click', function() {
            const txId = this.getAttribute('data-id');
            
            // Fetch transaction details
            fetch(`get_transaction.php?id=${txId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show details modal
                    const modal = document.getElementById('transactionModal');
                    const details = document.getElementById('transactionDetails');
                    const confirmBtn = document.getElementById('confirmAction');
                    const cancelBtn = document.getElementById('cancelAction');
                    
                    // Format transaction details
                    let detailsHtml = `
                        <div class="transaction-detail-item">
                            <strong>ID:</strong> ${data.transaction.id}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>User:</strong> ${data.transaction.phone}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Type:</strong> ${data.transaction.type}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Amount:</strong> ${parseFloat(data.transaction.amount).toFixed(2)} BDT
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Payment Method:</strong> ${data.transaction.payment_method || '-'}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Reference:</strong> ${data.transaction.transaction_ref || '-'}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Status:</strong> ${data.transaction.status}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Created:</strong> ${new Date(data.transaction.created_at).toLocaleString()}
                        </div>
                        <div class="transaction-detail-item">
                            <strong>Updated:</strong> ${data.transaction.updated_at ? new Date(data.transaction.updated_at).toLocaleString() : '-'}
                        </div>
                    `;
                    
                    details.innerHTML = detailsHtml;
                    modal.style.display = 'block';
                    
                    // Hide action buttons for view mode
                    confirmBtn.style.display = 'none';
                    cancelBtn.textContent = 'Close';
                    
                    // Set up close button
                    cancelBtn.onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close button
                    document.querySelector('.close').onclick = function() {
                        modal.style.display = 'none';
                    };
                    
                    // Close modal when clicking outside
                    window.onclick = function(event) {
                        if (event.target === modal) {
                            modal.style.display = 'none';
                        }
                    };
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
</script>

<?php
// Include footer
include 'templates/footer.php';
?>
