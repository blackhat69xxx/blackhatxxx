<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Get transaction ID
$transactionId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Validate input
if ($transactionId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid transaction ID']);
    exit;
}

// Get transaction details
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT t.*, u.phone FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.id = ?");
$stmt->bind_param("i", $transactionId);
$stmt->execute();
$transaction = $stmt->get_result()->fetch_assoc();

if (!$transaction) {
    echo json_encode(['success' => false, 'message' => 'Transaction not found']);
    exit;
}

// Return transaction details
echo json_encode([
    'success' => true,
    'transaction' => $transaction
]);
?>
