<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

$errors = [];
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get form data
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // Validate current password
        $db = Database::getInstance();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        
        if (!password_verify($currentPassword, $user['password'])) {
            $errors[] = 'Current password is incorrect.';
        }
        
        // Validate new password
        if (empty($newPassword)) {
            $errors[] = 'New password is required.';
        } elseif (strlen($newPassword) < 6) {
            $errors[] = 'New password must be at least 6 characters.';
        }
        
        // Validate password confirmation
        if ($newPassword !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }
        
        // Update password if no errors
        if (empty($errors)) {
            if (updateUserPassword($userId, $newPassword)) {
                $success = true;
            } else {
                $errors[] = 'Failed to update password. Please try again.';
            }
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Page title
$pageTitle = 'Change Password';

// Include header
include 'templates/header.php';
?>

<div class="auth-container">
    <h2>Change Password</h2>
    
    <?php if ($success): ?>
        <div class="alert alert-success">
            <p>Your password has been updated successfully!</p>
        </div>
        
        <div class="auth-links">
            <a href="dashboard.php" class="btn-3d btn-green">Back to Dashboard</a>
        </div>
    <?php else: ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            
            <div class="form-group">
                <label for="current_password">Current Password</label>
                <input type="password" id="current_password" name="current_password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" class="form-control" required>
                <small class="form-text text-muted">At least 6 characters</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            
            <button type="submit" class="auth-btn glow">Update Password</button>
        </form>
        
        <div class="auth-links">
            <a href="dashboard.php">Back to Dashboard</a>
        </div>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
