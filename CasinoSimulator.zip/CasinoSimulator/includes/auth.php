<?php
require_once 'functions.php';

/**
 * Register a new user
 */
function registerUser($phone, $password) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Check if phone already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = :phone");
    $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return ['success' => false, 'message' => 'Phone number already registered.'];
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (phone, password) VALUES (:phone, :password)");
    $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
    $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $userId = $db->getLastId('users_id_seq');
        return ['success' => true, 'user_id' => $userId];
    } else {
        return ['success' => false, 'message' => 'Registration failed. Please try again.'];
    }
}

/**
 * Authenticate user login
 */
function loginUser($phone, $password) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id, password, status FROM users WHERE phone = :phone");
    $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        return ['success' => false, 'message' => 'Phone number not registered.'];
    }
    
    $user = $stmt->fetch();
    
    if ($user['status'] != 'active') {
        return ['success' => false, 'message' => 'Your account has been suspended.'];
    }
    
    if (password_verify($password, $user['password'])) {
        // Update last login time
        $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
        $stmt->bindParam(':id', $user['id'], PDO::PARAM_INT);
        $stmt->execute();
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['login_time'] = time();
        
        return ['success' => true, 'user_id' => $user['id']];
    } else {
        return ['success' => false, 'message' => 'Invalid password.'];
    }
}

/**
 * Logout user
 */
function logoutUser() {
    if (isset($_SESSION['user_id'])) {
        unset($_SESSION['user_id']);
        unset($_SESSION['login_time']);
    }
    session_destroy();
    return true;
}

/**
 * Update user password
 */
function updateUserPassword($userId, $newPassword) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :id");
    $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * Admin login
 */
function loginAdmin($username, $password) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id, password, role FROM admin_users WHERE username = :username");
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        return ['success' => false, 'message' => 'Admin user not found.'];
    }
    
    $admin = $stmt->fetch();
    
    if (password_verify($password, $admin['password'])) {
        // Update last login time
        $stmt = $conn->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = :id");
        $stmt->bindParam(':id', $admin['id'], PDO::PARAM_INT);
        $stmt->execute();
        
        // Set session
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_role'] = $admin['role'];
        $_SESSION['admin_login_time'] = time();
        
        return ['success' => true, 'admin_id' => $admin['id'], 'role' => $admin['role']];
    } else {
        return ['success' => false, 'message' => 'Invalid password.'];
    }
}

/**
 * Logout admin
 */
function logoutAdmin() {
    if (isset($_SESSION['admin_id'])) {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_role']);
        unset($_SESSION['admin_login_time']);
    }
    session_destroy();
    return true;
}

/**
 * Reset user password using token
 */
function resetPasswordWithToken($phone, $token, $newPassword) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Verify token
    if (!verifyPasswordResetToken($phone, $token)) {
        return ['success' => false, 'message' => 'Invalid or expired token.'];
    }
    
    // Get user ID
    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = :phone");
    $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        return ['success' => false, 'message' => 'User not found.'];
    }
    
    $user = $stmt->fetch();
    
    // Update password
    if (updateUserPassword($user['id'], $newPassword)) {
        // Delete token
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE phone = :phone");
        $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
        $stmt->execute();
        
        return ['success' => true];
    } else {
        return ['success' => false, 'message' => 'Failed to update password.'];
    }
}

/**
 * Check if session is still valid
 */
function validateSession() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['login_time'])) {
        return false;
    }
    
    // Check if session has expired (24 hours)
    $sessionLifetime = 24 * 60 * 60; // 24 hours in seconds
    if (time() - $_SESSION['login_time'] > $sessionLifetime) {
        logoutUser();
        return false;
    }
    
    return true;
}

/**
 * Check if admin session is still valid
 */
function validateAdminSession() {
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_login_time'])) {
        return false;
    }
    
    // Check if session has expired (12 hours)
    $sessionLifetime = 12 * 60 * 60; // 12 hours in seconds
    if (time() - $_SESSION['admin_login_time'] > $sessionLifetime) {
        logoutAdmin();
        return false;
    }
    
    return true;
}
