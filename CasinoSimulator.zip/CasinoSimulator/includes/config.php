<?php
// Database configuration
define('DB_HOST', getenv('PGHOST'));
define('DB_USER', getenv('PGUSER'));
define('DB_PASS', getenv('PGPASSWORD'));
define('DB_NAME', getenv('PGDATABASE'));
define('DB_PORT', getenv('PGPORT'));

// Application configuration
define('SITE_NAME', 'BDT-WIN');
define('SITE_URL', 'https://' . getenv('REPL_SLUG') . '.' . getenv('REPL_OWNER') . '.repl.co');
define('ADMIN_EMAIL', 'admin@bdtwin.com');

// Game settings
define('MIN_BET_AMOUNT', 10);
define('MAX_BET_AMOUNT', 10000);
define('WINGO_PAYOUT_RED_GREEN', 2); // 1:1 payout
define('WINGO_PAYOUT_NUMBER', 9);    // 8:1 payout
define('WINGO_PAYOUT_BIG_SMALL', 2); // 1:1 payout

// Session settings
session_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Dhaka');

// Security settings
define('CSRF_TOKEN_SECRET', 'bdtwin_secure_token_' . date('Ymd'));
?>
