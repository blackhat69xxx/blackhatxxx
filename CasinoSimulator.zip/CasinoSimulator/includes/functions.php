<?php
require_once 'db.php';

/**
 * Generate a CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

/**
 * Generate a random verification code
 */
function generateVerificationCode($length = 6) {
    return rand(pow(10, $length-1), pow(10, $length)-1);
}

/**
 * Format currency amount
 */
function formatAmount($amount) {
    return number_format($amount, 2, '.', ',') . ' BDT';
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if admin is logged in
 */
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

/**
 * Check if admin has specific role
 */
function hasAdminRole($role) {
    if (!isAdminLoggedIn()) {
        return false;
    }
    
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $adminId = $_SESSION['admin_id'];
    
    $stmt = $conn->prepare("SELECT role FROM admin_users WHERE id = ?");
    $stmt->bind_param("i", $adminId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if ($row['role'] == $role || $row['role'] == 'admin') {
            return true;
        }
    }
    
    return false;
}

/**
 * Get user data by ID
 */
function getUserById($userId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch();
    }
    
    return null;
}

/**
 * Update user balance
 */
function updateUserBalance($userId, $amount) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("UPDATE users SET balance = balance + :amount WHERE id = :id");
    $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * Create a transaction record
 */
function createTransaction($userId, $type, $amount, $paymentMethod = null, $transactionRef = null, $status = 'pending') {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, payment_method, transaction_ref, status) 
                           VALUES (:user_id, :type, :amount, :payment_method, :transaction_ref, :status)");
    
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
    $stmt->bindParam(':payment_method', $paymentMethod, PDO::PARAM_STR);
    $stmt->bindParam(':transaction_ref', $transactionRef, PDO::PARAM_STR);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        return $db->getLastId('transactions_id_seq');
    }
    
    return false;
}

/**
 * Update transaction status
 */
function updateTransactionStatus($transactionId, $status) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $now = date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("UPDATE transactions SET status = :status, updated_at = :updated_at WHERE id = :id");
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':updated_at', $now, PDO::PARAM_STR);
    $stmt->bindParam(':id', $transactionId, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * Get user transactions
 */
function getUserTransactions($userId, $limit = 20) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll();
}

/**
 * Create a new game round
 */
function createGameRound($gameType, $startTime, $endTime, $adminId = null) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // For now, generate random results
    $resultNumber = rand(0, 9);
    $resultColor = ($resultNumber % 2 == 0) ? 'red' : 'green';
    $isSmall = ($resultNumber < 5) ? true : false; // Use boolean for PostgreSQL
    
    $stmt = $conn->prepare("INSERT INTO game_rounds (game_type, result_number, result_color, is_small, start_time, end_time, created_by) 
                           VALUES (:game_type, :result_number, :result_color, :is_small, :start_time, :end_time, :created_by)");
    
    $stmt->bindParam(':game_type', $gameType, PDO::PARAM_STR);
    $stmt->bindParam(':result_number', $resultNumber, PDO::PARAM_INT);
    $stmt->bindParam(':result_color', $resultColor, PDO::PARAM_STR);
    $stmt->bindParam(':is_small', $isSmall, PDO::PARAM_BOOL);
    $stmt->bindParam(':start_time', $startTime, PDO::PARAM_STR);
    $stmt->bindParam(':end_time', $endTime, PDO::PARAM_STR);
    $stmt->bindParam(':created_by', $adminId, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        return $db->getLastId('game_rounds_id_seq');
    }
    
    return false;
}

/**
 * Get active game round
 */
function getActiveGameRound($gameType) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $now = date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("SELECT * FROM game_rounds WHERE game_type = :game_type AND start_time <= :now1 AND end_time > :now2 ORDER BY start_time DESC LIMIT 1");
    $stmt->bindParam(':game_type', $gameType, PDO::PARAM_STR);
    $stmt->bindParam(':now1', $now, PDO::PARAM_STR);
    $stmt->bindParam(':now2', $now, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch();
    }
    
    return null;
}

/**
 * Get next game round
 */
function getNextGameRound($gameType) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $now = date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("SELECT * FROM game_rounds WHERE game_type = :game_type AND start_time > :now ORDER BY start_time ASC LIMIT 1");
    $stmt->bindParam(':game_type', $gameType, PDO::PARAM_STR);
    $stmt->bindParam(':now', $now, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch();
    }
    
    return null;
}

/**
 * Get game round by ID
 */
function getGameRoundById($roundId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM game_rounds WHERE id = :id");
    $stmt->bindParam(':id', $roundId, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch();
    }
    
    return null;
}

/**
 * Create a bet
 */
function createBet($userId, $gameRoundId, $betType, $betValue, $amount) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Calculate potential win
    $potentialWin = $amount;
    if ($betType == 'red' || $betType == 'green') {
        $potentialWin = $amount * WINGO_PAYOUT_RED_GREEN;
    } else if ($betType == 'number') {
        $potentialWin = $amount * WINGO_PAYOUT_NUMBER;
    } else if ($betType == 'big' || $betType == 'small') {
        $potentialWin = $amount * WINGO_PAYOUT_BIG_SMALL;
    }
    
    $db->beginTransaction();
    
    try {
        // Check user balance
        $user = getUserById($userId);
        if ($user['balance'] < $amount) {
            $db->rollback();
            return ['success' => false, 'message' => 'Insufficient balance.'];
        }
        
        // Update user balance
        updateUserBalance($userId, -$amount);
        
        // Create transaction record
        createTransaction($userId, 'bet', -$amount, null, null, 'completed');
        
        // Create bet record
        $stmt = $conn->prepare("INSERT INTO bets (user_id, game_round_id, bet_type, bet_value, amount, potential_win) 
                               VALUES (:user_id, :game_round_id, :bet_type, :bet_value, :amount, :potential_win)");
                               
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':game_round_id', $gameRoundId, PDO::PARAM_INT);
        $stmt->bindParam(':bet_type', $betType, PDO::PARAM_STR);
        $stmt->bindParam(':bet_value', $betValue, PDO::PARAM_STR);
        $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
        $stmt->bindParam(':potential_win', $potentialWin, PDO::PARAM_STR);
        
        if (!$stmt->execute()) {
            $db->rollback();
            return ['success' => false, 'message' => 'Failed to place bet.'];
        }
        
        $betId = $db->getLastId('bets_id_seq');
        $db->commit();
        
        return ['success' => true, 'bet_id' => $betId];
    } catch (Exception $e) {
        $db->rollback();
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}

/**
 * Process bets for a completed game round
 */
function processGameRoundBets($gameRoundId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Get game round details
    $gameRound = getGameRoundById($gameRoundId);
    if (!$gameRound) {
        return false;
    }
    
    // Get all pending bets for this round
    $stmt = $conn->prepare("SELECT * FROM bets WHERE game_round_id = :game_round_id AND status = 'pending'");
    $stmt->bindParam(':game_round_id', $gameRoundId, PDO::PARAM_INT);
    $stmt->execute();
    
    $db->beginTransaction();
    
    try {
        while ($bet = $stmt->fetch()) {
            $isWin = false;
            
            // Check if bet is winning
            if ($bet['bet_type'] == 'red' && $gameRound['result_color'] == 'red') {
                $isWin = true;
            } else if ($bet['bet_type'] == 'green' && $gameRound['result_color'] == 'green') {
                $isWin = true;
            } else if ($bet['bet_type'] == 'number' && $bet['bet_value'] == $gameRound['result_number']) {
                $isWin = true;
            } else if ($bet['bet_type'] == 'big' && $gameRound['is_small'] == false) {
                $isWin = true;
            } else if ($bet['bet_type'] == 'small' && $gameRound['is_small'] == true) {
                $isWin = true;
            }
            
            // Update bet status
            $betStatus = $isWin ? 'won' : 'lost';
            $updateStmt = $conn->prepare("UPDATE bets SET status = :status WHERE id = :id");
            $updateStmt->bindParam(':status', $betStatus, PDO::PARAM_STR);
            $updateStmt->bindParam(':id', $bet['id'], PDO::PARAM_INT);
            $updateStmt->execute();
            
            // If bet is winning, update user balance
            if ($isWin) {
                updateUserBalance($bet['user_id'], $bet['potential_win']);
                createTransaction($bet['user_id'], 'win', $bet['potential_win'], null, null, 'completed');
            }
        }
        
        $db->commit();
        return true;
    } catch (Exception $e) {
        $db->rollback();
        return false;
    }
}

/**
 * Get user bets for a game round
 */
function getUserBetsForRound($userId, $gameRoundId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM bets WHERE user_id = :user_id AND game_round_id = :game_round_id");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':game_round_id', $gameRoundId, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll();
}

/**
 * Get pending transactions for admin review
 */
function getPendingTransactions($type = null, $limit = 50) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $sql = "SELECT t.*, u.phone FROM transactions t 
            JOIN users u ON t.user_id = u.id 
            WHERE t.status = 'pending'";
    
    $params = [];
    
    if ($type) {
        $sql .= " AND t.type = :type";
        $params[':type'] = $type;
    }
    
    $sql .= " ORDER BY t.created_at DESC LIMIT :limit";
    $params[':limit'] = (int)$limit;
    
    $stmt = $conn->prepare($sql);
    
    // Bind parameters
    foreach ($params as $param => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $stmt->bindValue($param, $value, $paramType);
    }
    
    $stmt->execute();
    
    return $stmt->fetchAll();
}

/**
 * Clean user input
 */
function cleanInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

/**
 * Validate phone number (Bangladesh format)
 */
function validatePhone($phone) {
    return preg_match('/^01[3-9][0-9]{8}$/', $phone);
}

/**
 * Generate a password reset token
 */
function generatePasswordResetToken($phone) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Delete any existing tokens for this phone
    $stmt = $conn->prepare("DELETE FROM password_resets WHERE phone = ?");
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    
    // Generate a new token
    $token = bin2hex(random_bytes(16));
    $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    $stmt = $conn->prepare("INSERT INTO password_resets (phone, token, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $phone, $token, $expiresAt);
    
    if ($stmt->execute()) {
        return $token;
    }
    
    return false;
}

/**
 * Verify password reset token
 */
function verifyPasswordResetToken($phone, $token) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $now = date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE phone = :phone AND token = :token AND expires_at > :now LIMIT 1");
    $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->bindParam(':now', $now, PDO::PARAM_STR);
    $stmt->execute();
    
    return $stmt->rowCount() > 0;
}
