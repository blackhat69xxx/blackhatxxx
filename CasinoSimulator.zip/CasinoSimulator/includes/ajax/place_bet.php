<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get the JSON data from the request
$jsonData = file_get_contents('php://input');
$data = json_decode($jsonData, true);

// Validate the data
if (!isset($data['game_round_id']) || !isset($data['bet_type']) || !isset($data['amount'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Validate bet amount
if (!is_numeric($data['amount']) || $data['amount'] < MIN_BET_AMOUNT || $data['amount'] > MAX_BET_AMOUNT) {
    echo json_encode(['success' => false, 'message' => 'Invalid bet amount']);
    exit;
}

// Validate bet type
$validBetTypes = ['red', 'green', 'number', 'big', 'small'];
if (!in_array($data['bet_type'], $validBetTypes)) {
    echo json_encode(['success' => false, 'message' => 'Invalid bet type']);
    exit;
}

// Validate bet value for number bet
if ($data['bet_type'] === 'number' && (!isset($data['bet_value']) || !is_numeric($data['bet_value']) || $data['bet_value'] < 0 || $data['bet_value'] > 9)) {
    echo json_encode(['success' => false, 'message' => 'Invalid number value']);
    exit;
}

// Get game round
$gameRound = getGameRoundById($data['game_round_id']);
if (!$gameRound) {
    echo json_encode(['success' => false, 'message' => 'Invalid game round']);
    exit;
}

// Check if game round is still active
$now = new DateTime();
$endTime = new DateTime($gameRound['end_time']);
if ($now >= $endTime) {
    echo json_encode(['success' => false, 'message' => 'Game round has ended']);
    exit;
}

// Place the bet
$userId = $_SESSION['user_id'];
$betResult = createBet(
    $userId, 
    $data['game_round_id'], 
    $data['bet_type'], 
    $data['bet_type'] === 'number' ? $data['bet_value'] : null, 
    $data['amount']
);

// Return the result
echo json_encode($betResult);
?>
