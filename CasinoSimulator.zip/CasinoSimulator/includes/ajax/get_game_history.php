<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get game type from request
$gameType = isset($_GET['game_type']) ? $_GET['game_type'] : 'wingo_1min';

// Validate game type
if (!in_array($gameType, ['wingo_1min', 'wingo_30sec'])) {
    $gameType = 'wingo_1min';
}

// Get database connection
$db = Database::getInstance();
$conn = $db->getConnection();

// Build query - always filter by game type
$query = "SELECT * FROM game_rounds WHERE game_type = :game_type";
$params = [':game_type' => $gameType];

$query .= " ORDER BY end_time DESC LIMIT 20";

// Prepare and execute query
$stmt = $conn->prepare($query);

// Bind parameters
if (!empty($params)) {
    foreach ($params as $param => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $stmt->bindValue($param, $value, $paramType);
    }
}

$stmt->execute();

// Fetch all rounds
$rounds = $stmt->fetchAll();

// Format rounds with period
$formattedRounds = [];
foreach ($rounds as $round) {
    // Generate period in the format YYYYMMDDHHmmssXXX (like 20250514100052737)
    $periodDate = new DateTime($round['start_time']);
    $period = $periodDate->format('YmdHis');
    $period .= sprintf('%03d', $round['id'] % 1000); // Add last 3 digits of round ID
    
    $round['period'] = $period;
    $formattedRounds[] = $round;
}

// Return game history
echo json_encode([
    'success' => true,
    'rounds' => $formattedRounds
]);
?>
