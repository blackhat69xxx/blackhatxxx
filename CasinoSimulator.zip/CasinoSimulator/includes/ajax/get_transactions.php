<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get user ID
$userId = $_SESSION['user_id'];

// Get limit from request or default to 20
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
$limit = max(1, min(100, $limit)); // Limit between 1 and 100

// Get transactions
$transactions = getUserTransactions($userId, $limit);

// Return transactions
echo json_encode([
    'success' => true,
    'transactions' => $transactions
]);
?>
