<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get user ID and data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

// Get post data
$amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
$paymentMethod = isset($_POST['withdraw_method']) ? $_POST['withdraw_method'] : '';
$accountNumber = isset($_POST['account_number']) ? $_POST['account_number'] : '';

// Validate data
if ($amount <= 0 || $amount < 500) { // Minimum withdrawal amount
    echo json_encode(['success' => false, 'message' => 'Minimum withdrawal amount is 500 BDT']);
    exit;
}

if ($amount > $userData['balance']) {
    echo json_encode(['success' => false, 'message' => 'Insufficient balance']);
    exit;
}

if (empty($paymentMethod) || !in_array($paymentMethod, ['bkash', 'nagad'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid payment method']);
    exit;
}

if (empty($accountNumber) || !validatePhone($accountNumber)) {
    echo json_encode(['success' => false, 'message' => 'Invalid account number']);
    exit;
}

// Start transaction
$db = Database::getInstance();
$db->beginTransaction();

try {
    // Deduct amount from user balance
    updateUserBalance($userId, -$amount);
    
    // Create transaction
    $transactionId = createTransaction($userId, 'withdrawal', -$amount, $paymentMethod, $accountNumber);
    
    if (!$transactionId) {
        throw new Exception('Failed to create withdrawal transaction');
    }
    
    // Commit transaction
    $db->commit();
    
    // Return success
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request submitted successfully',
        'transaction_id' => $transactionId,
        'amount' => $amount,
        'payment_method' => $paymentMethod,
        'account' => $accountNumber
    ]);
} catch (Exception $e) {
    // Rollback transaction
    $db->rollback();
    
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
