<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get user balance
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit;
}

// Format balance for display
$formattedBalance = formatAmount($userData['balance']);

// Return the balance
echo json_encode([
    'success' => true, 
    'balance' => $formattedBalance,
    'raw_balance' => $userData['balance']
]);
?>
