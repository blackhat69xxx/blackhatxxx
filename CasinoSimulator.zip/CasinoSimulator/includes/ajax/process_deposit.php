<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get user ID
$userId = $_SESSION['user_id'];

// Get post data
$amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
$paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
$transactionId = isset($_POST['transaction_id']) ? $_POST['transaction_id'] : '';

// Validate data
if ($amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid amount']);
    exit;
}

if (empty($paymentMethod) || !in_array($paymentMethod, ['bkash', 'nagad'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid payment method']);
    exit;
}

if (empty($transactionId)) {
    echo json_encode(['success' => false, 'message' => 'Transaction ID is required']);
    exit;
}

// Check if transaction ID already exists
$db = Database::getInstance();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT id FROM transactions WHERE transaction_ref = ? AND type = 'deposit'");
$stmt->bind_param("s", $transactionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'This transaction ID has already been used']);
    exit;
}

// Create transaction
$transactionResult = createTransaction($userId, 'deposit', $amount, $paymentMethod, $transactionId);

if (!$transactionResult) {
    echo json_encode(['success' => false, 'message' => 'Failed to create deposit transaction']);
    exit;
}

// Return success
echo json_encode([
    'success' => true,
    'message' => 'Deposit request submitted successfully',
    'transaction_id' => $transactionResult,
    'amount' => $amount,
    'payment_method' => $paymentMethod
]);
?>
