<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get game type from request
$gameType = isset($_GET['game_type']) ? $_GET['game_type'] : 'wingo_1min';

// Validate game type
if (!in_array($gameType, ['wingo_1min', 'wingo_30sec'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid game type']);
    exit;
}

// Get active game round
$activeRound = getActiveGameRound($gameType);

// If no active round, create one
if (!$activeRound) {
    $now = new DateTime();
    $startTime = $now->format('Y-m-d H:i:s');
    
    // Set end time based on game type
    if ($gameType === 'wingo_1min') {
        $endTime = $now->modify('+1 minute')->format('Y-m-d H:i:s');
    } else {
        $endTime = $now->modify('+30 seconds')->format('Y-m-d H:i:s');
    }
    
    // Create new game round
    $gameRoundId = createGameRound($gameType, $startTime, $endTime);
    
    // Reload active round
    $activeRound = getGameRoundById($gameRoundId);
}

// Get user's bets for this round
$userId = $_SESSION['user_id'];
$userBets = getUserBetsForRound($userId, $activeRound['id']);

// Generate period in the format YYYYMMDDHHmmssXXX (like 20250514100052737)
$periodDate = new DateTime($activeRound['start_time']);
$period = $periodDate->format('YmdHis');
$period .= sprintf('%03d', $activeRound['id'] % 1000); // Add last 3 digits of round ID

// Format response
$response = [
    'success' => true,
    'round_id' => $activeRound['id'],
    'period' => $period,
    'game_type' => $activeRound['game_type'],
    'start_time' => $activeRound['start_time'],
    'end_time' => $activeRound['end_time'],
    'user_bets' => $userBets
];

echo json_encode($response);
?>
