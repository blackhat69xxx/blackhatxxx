<?php
require_once 'config.php';

class Database {
    private $conn;
    private static $instance = null;
    
    private function __construct() {
        try {
            $dsn = "pgsql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";user=" . DB_USER . ";password=" . DB_PASS;
            $this->conn = new PDO($dsn);
            
            // Set error mode to exceptions
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Use consistent fetch mode
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            die("Database Error: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    public function query($sql) {
        return $this->conn->query($sql);
    }
    
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }
    
    public function escapeString($string) {
        return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
    
    public function getLastId($sequence = null) {
        return $this->conn->lastInsertId($sequence);
    }
    
    public function getError() {
        $errorInfo = $this->conn->errorInfo();
        return $errorInfo[2];
    }
    
    public function close() {
        $this->conn = null;
    }
    
    public function beginTransaction() {
        $this->conn->beginTransaction();
    }
    
    public function commit() {
        $this->conn->commit();
    }
    
    public function rollback() {
        $this->conn->rollBack();
    }
}

// Generate tables if they don't exist
function createDatabaseTables() {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Create enum types in PostgreSQL
    try {
        // Helper function to create enum if it doesn't exist
        function createEnumIfNotExists($conn, $typeName, $values) {
            $checkType = $conn->query("SELECT 1 FROM pg_type WHERE typname = '$typeName'");
            
            if ($checkType->rowCount() == 0) {
                $valuesString = implode("', '", $values);
                $conn->query("CREATE TYPE $typeName AS ENUM ('$valuesString')");
            }
        }
        
        createEnumIfNotExists($conn, 'user_status', ['active', 'suspended']);
        createEnumIfNotExists($conn, 'admin_role', ['admin', 'moderator']);
        createEnumIfNotExists($conn, 'transaction_type', ['deposit', 'withdrawal', 'bet', 'win', 'refund']);
        createEnumIfNotExists($conn, 'transaction_status', ['pending', 'completed', 'rejected']);
        createEnumIfNotExists($conn, 'game_type', ['wingo_1min', 'wingo_30sec']);
        createEnumIfNotExists($conn, 'color_type', ['red', 'green']);
        createEnumIfNotExists($conn, 'bet_type', ['red', 'green', 'number', 'big', 'small']);
        createEnumIfNotExists($conn, 'bet_status', ['pending', 'won', 'lost']);
    } catch (PDOException $e) {
        // Log the error but don't stop execution
        error_log("Error creating enum types: " . $e->getMessage());
    }
    
    // Users table
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        phone VARCHAR(20) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        balance DECIMAL(15,2) DEFAULT 0.00,
        status user_status DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL
    )");
    
    // Admin users table
    $conn->query("CREATE TABLE IF NOT EXISTS admin_users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role admin_role DEFAULT 'moderator',
        last_login TIMESTAMP NULL
    )");
    
    // Create default admin if it doesn't exist
    $checkAdmin = $conn->query("SELECT * FROM admin_users WHERE username = 'admin' LIMIT 1");
    if ($checkAdmin->rowCount() == 0) {
        $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $conn->query("INSERT INTO admin_users (username, password, role) VALUES ('admin', '$hashedPassword', 'admin')");
    }
    
    // Transactions table
    $conn->query("CREATE TABLE IF NOT EXISTS transactions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        type transaction_type NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        payment_method VARCHAR(50) NULL,
        transaction_ref VARCHAR(100) NULL,
        status transaction_status DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    
    // We'll skip the trigger creation for now to avoid syntax errors
    // Instead, we'll manually update the 'updated_at' column in our code when needed
    try {
        // Check if the updated_at column exists
        $checkColumn = $conn->query("
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'transactions' 
            AND column_name = 'updated_at'
        ");
        
        // If column exists, we'll handle timestamps in our application code
        if ($checkColumn->rowCount() > 0) {
            error_log("Updated_at column exists, will handle timestamps in application code");
        }
    } catch (PDOException $e) {
        // Just log the error but don't stop execution
        error_log("Error checking updated_at column: " . $e->getMessage());
    }
    
    // Game rounds table
    $conn->query("CREATE TABLE IF NOT EXISTS game_rounds (
        id SERIAL PRIMARY KEY,
        game_type game_type NOT NULL,
        result_number INTEGER NOT NULL,
        result_color color_type NOT NULL,
        is_small BOOLEAN NOT NULL,
        start_time TIMESTAMP NOT NULL,
        end_time TIMESTAMP NOT NULL,
        created_by INTEGER NULL
    )");
    
    // Bets table
    $conn->query("CREATE TABLE IF NOT EXISTS bets (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        game_round_id INTEGER NOT NULL,
        bet_type bet_type NOT NULL,
        bet_value VARCHAR(10) NULL,
        amount DECIMAL(15,2) NOT NULL,
        potential_win DECIMAL(15,2) NOT NULL,
        status bet_status DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (game_round_id) REFERENCES game_rounds(id) ON DELETE CASCADE
    )");
    
    // Password resets table
    $conn->query("CREATE TABLE IF NOT EXISTS password_resets (
        id SERIAL PRIMARY KEY,
        phone VARCHAR(20) NOT NULL,
        token VARCHAR(100) NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
}

// Initialize tables
createDatabaseTables();
?>
