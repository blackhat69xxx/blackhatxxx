<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$success = false;

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid request, please try again.';
    } else {
        // Get and sanitize input
        $phone = cleanInput($_POST['phone']);
        $password = $_POST['password'];
        $remember = isset($_POST['remember']) ? true : false;
        
        // Validate phone number
        if (empty($phone)) {
            $errors[] = 'Phone number is required.';
        } elseif (!validatePhone($phone)) {
            $errors[] = 'Please enter a valid Bangladesh phone number.';
        }
        
        // Validate password
        if (empty($password)) {
            $errors[] = 'Password is required.';
        }
        
        // Attempt login if no errors
        if (empty($errors)) {
            $result = loginUser($phone, $password);
            
            if ($result['success']) {
                // Set remember me cookie if requested
                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    setcookie('remember_token', $token, time() + (86400 * 30), '/'); // 30 days
                    
                    // Store token in database (this would require additional table/column)
                    // storeRememberToken($result['user_id'], $token);
                }
                
                // Redirect to dashboard or intended page
                $redirect = isset($_SESSION['redirect_after_login']) ? $_SESSION['redirect_after_login'] : 'dashboard.php';
                unset($_SESSION['redirect_after_login']);
                
                header("Location: $redirect");
                exit;
            } else {
                $errors[] = $result['message'];
            }
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
include 'templates/header.php';
?>

<div class="auth-container">
    <h2>Login to Your Account</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <form id="login-form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
        
        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text" id="login-phone" name="phone" class="form-control" placeholder="01XXXXXXXXX" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="login-password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        
        <div class="form-group">
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                <label class="form-check-label" for="remember">Remember me</label>
            </div>
        </div>
        
        <button type="submit" class="auth-btn glow">Login</button>
    </form>
    
    <div class="auth-links">
        <p><a href="reset_password.php">Forgot your password?</a></p>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>

<?php
// Include footer
include 'templates/footer.php';
?>
