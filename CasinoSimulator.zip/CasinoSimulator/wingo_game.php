<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'wingo_game.php';
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$userData = getUserById($userId);

if (!$userData) {
    // Handle invalid user ID
    session_destroy();
    header('Location: login.php');
    exit;
}

// Determine game type from URL or default to 1min
$gameType = isset($_GET['type']) && $_GET['type'] === 'wingo_30sec' ? 'wingo_30sec' : 'wingo_1min';

// Get active game round
$activeRound = getActiveGameRound($gameType);

// If no active round, create one
if (!$activeRound) {
    $now = new DateTime();
    $startTime = $now->format('Y-m-d H:i:s');
    
    // Set end time based on game type
    if ($gameType === 'wingo_1min') {
        $endTime = $now->modify('+1 minute')->format('Y-m-d H:i:s');
    } else {
        $endTime = $now->modify('+30 seconds')->format('Y-m-d H:i:s');
    }
    
    // Create new game round
    $gameRoundId = createGameRound($gameType, $startTime, $endTime);
    
    // Reload active round
    $activeRound = getGameRoundById($gameRoundId);
}

// Get user's bets for this round
$userBets = getUserBetsForRound($userId, $activeRound['id']);

// Get game history
$db = Database::getInstance();
$conn = $db->getConnection();
$stmt = $conn->prepare("SELECT * FROM game_rounds WHERE game_type = :game_type ORDER BY end_time DESC LIMIT 10");
$stmt->bindParam(':game_type', $gameType, PDO::PARAM_STR);
$stmt->execute();
$gameHistory = $stmt->fetchAll();

// Modified header for game
$pageTitle = "Wingo Game";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    
    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/wingo_game.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
</head>
<body>

<div class="wingo-game-container">
    <!-- Game Header Section -->
    <div class="wingo-header">
        <a href="index.php" class="wingo-back-button">
            <i class="fas fa-chevron-left"></i>
        </a>
        <div class="wingo-logo">
            <span class="bdt-text">BDT-</span><span class="win-text">WIN</span>
        </div>
        
        <div class="wingo-balance">
            <div class="wingo-balance-amount"><?php echo formatAmount($userData['balance']); ?></div>
            <div class="wingo-balance-label">
                <i class="fas fa-wallet"></i> Wallet balance
            </div>
        </div>
        
        <div class="wingo-action-buttons">
            <a href="withdraw.php" class="wingo-button wingo-button-withdraw">Withdraw</a>
            <a href="deposit.php" class="wingo-button wingo-button-deposit">Deposit</a>
        </div>
    </div>
    
    <!-- Search Bar -->
    <div class="wingo-search">
        <input type="text" placeholder="Search...">
        <button>Search</button>
    </div>
    
    <!-- Game Tabs -->
    <div class="wingo-game-tabs">
        <div class="wingo-game-tab <?php echo $gameType === 'wingo_1min' ? 'active' : ''; ?>" data-game-type="wingo_1min">
            <div class="wingo-game-tab-icon">
                <i class="fas fa-dice"></i>
            </div>
            <div class="wingo-game-tab-name">Wingo 1</div>
            <div class="wingo-game-tab-type">1 MIN</div>
        </div>
        <div class="wingo-game-tab <?php echo $gameType === 'wingo_30sec' ? 'active' : ''; ?>" data-game-type="wingo_30sec">
            <div class="wingo-game-tab-icon">
                <i class="fas fa-dice"></i>
            </div>
            <div class="wingo-game-tab-name">Wingo 2</div>
            <div class="wingo-game-tab-type">30 SEC</div>
        </div>
    </div>
    
    <!-- Countdown Section -->
    <div class="wingo-countdown-wrapper">
        <div class="wingo-countdown-container">
            <div class="wingo-countdown-info">
                <div class="wingo-time-left">
                    <i class="fas fa-clock"></i> Time left
                </div>
                <div class="wingo-game-round">
                    Round: <span id="game-round-id"><?php echo $activeRound['id']; ?></span>
                </div>
            </div>
            
            <div class="wingo-countdown-numbers">
                <div class="wingo-number-box" id="countdown-min">0</div>
                <div class="wingo-number-box" id="countdown-sec1">0</div>
                <div class="wingo-number-box" id="countdown-sec2">0</div>
                <div class="wingo-number-box" id="countdown-ms">0</div>
            </div>
            
            <div class="wingo-period-number"><?php echo $activeRound['id']; ?></div>
            
            <div class="wingo-progress-indicators">
                <div class="wingo-indicator green"></div>
                <div class="wingo-indicator red"></div>
                <div class="wingo-indicator red"></div>
                <div class="wingo-indicator green"></div>
                <div class="wingo-indicator purple"></div>
            </div>
        </div>
        
        <!-- Betting Color Buttons -->
        <div class="wingo-bet-buttons">
            <div class="wingo-bet-button wingo-bet-green" data-bet-type="green">Green</div>
            <div class="wingo-bet-button wingo-bet-violet" data-bet-type="violet">Violet</div>
            <div class="wingo-bet-button wingo-bet-red" data-bet-type="red">Red</div>
        </div>
        
        <!-- Number Betting Grid -->
        <div class="wingo-numbers-grid">
            <?php 
            $numberColors = [
                0 => 'green', 1 => 'green', 2 => 'red', 3 => 'green', 4 => 'red',
                5 => 'green', 6 => 'red', 7 => 'green', 8 => 'red', 9 => 'green'
            ];
            for ($i = 0; $i <= 9; $i++): 
            ?>
                <div class="wingo-number-bet <?php echo $numberColors[$i]; ?>" data-number="<?php echo $i; ?>">
                    <?php echo $i; ?>
                </div>
            <?php endfor; ?>
        </div>
        
        <!-- Amount Selection -->
        <div class="wingo-amount-selection">
            <div class="wingo-amount-option">Random</div>
            <div class="wingo-amount-option active">₹1</div>
            <div class="wingo-amount-option">₹5</div>
            <div class="wingo-amount-option">₹10</div>
            <div class="wingo-amount-option">₹50</div>
            <div class="wingo-amount-option">₹100</div>
            <div class="wingo-amount-option">₹500</div>
        </div>
        
        <!-- Big/Small Betting -->
        <div class="wingo-size-betting">
            <div class="wingo-size-option" data-bet-type="big">Big</div>
            <div class="wingo-size-option" data-bet-type="small">Small</div>
        </div>
    </div>
    
    <!-- Game History Tabs -->
    <div class="wingo-history-tabs">
        <div class="wingo-history-tab active">
            Game history for <?php echo $gameType === 'wingo_1min' ? '1 Minute' : '30 Second'; ?> Game
        </div>
    </div>
    
    <!-- Game History Content -->
    <div class="wingo-history-content">
        <table class="wingo-history-table">
            <thead>
                <tr>
                    <th>Period</th>
                    <th>Number</th>
                    <th>Size</th>
                    <th>Color</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($gameHistory as $round): 
                    $resultNumber = $round['result_number'];
                    $resultColor = $round['result_color'];
                    $isSmall = $round['is_small'] === true || $round['is_small'] === 't' || $round['is_small'] === '1' || $round['is_small'] === 1;
                ?>
                <tr>
                    <td>
                        <?php 
                        // Generate period in the format YYYYMMDDHHmmssXXX
                        $periodDate = new DateTime($round['start_time']);
                        $period = $periodDate->format('YmdHis');
                        $period .= sprintf('%03d', $round['id'] % 1000);
                        echo $period;
                        ?>
                    </td>
                    <td>
                        <div class="wingo-result-number <?php echo $resultColor; ?>">
                            <?php echo $resultNumber; ?>
                        </div>
                    </td>
                    <td>
                        <div class="wingo-result-size">
                            <?php echo $isSmall ? 'Small' : 'Big'; ?>
                        </div>
                    </td>
                    <td>
                        <div class="wingo-result-indicator">
                            <?php if($resultColor === 'red'): ?>
                                <div class="wingo-result-dot red"></div>
                            <?php elseif($resultColor === 'green'): ?>
                                <div class="wingo-result-dot green"></div>
                            <?php else: ?>
                                <div class="wingo-result-dot purple"></div>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <div class="wingo-pagination">
            <div class="wingo-pagination-button">
                <i class="fas fa-chevron-left"></i>
            </div>
            <div class="wingo-pagination-button active">1</div>
            <div class="wingo-pagination-button">
                <i class="fas fa-chevron-right"></i>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Libraries -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/wingo.js"></script>

<script>
// Specific initialization for new layout
document.addEventListener('DOMContentLoaded', function() {
    // Function to refresh game data
    function refreshGameData() {
        loadGameData();
        loadGameHistory();
    }
    
    // Set up automatic refresh every 5 seconds
    setInterval(refreshGameData, 5000);
    
    // Initialize countdown display with new layout
    function updateCountdownDisplay() {
        if (!currentGame.endTime) return;
        
        const now = new Date().getTime();
        const distance = currentGame.endTime - now;
        
        if (distance < 0) {
            document.getElementById('countdown-min').textContent = '0';
            document.getElementById('countdown-sec1').textContent = '0';
            document.getElementById('countdown-sec2').textContent = '0';
            document.getElementById('countdown-ms').textContent = '0';
            
            // Auto-reload immediately when countdown reaches zero
            refreshGameData();
            return;
        }
        
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        const milliseconds = Math.floor((distance % 1000) / 100);
        
        document.getElementById('countdown-min').textContent = minutes;
        document.getElementById('countdown-sec1').textContent = Math.floor(seconds / 10);
        document.getElementById('countdown-sec2').textContent = seconds % 10;
        document.getElementById('countdown-ms').textContent = milliseconds;
    }
    
    // Replace standard countdown with our new version
    if (currentGame.countdown) {
        clearInterval(currentGame.countdown);
    }
    
    currentGame.countdown = setInterval(updateCountdownDisplay, 100);
    
    // Set up game tabs
    const gameTabs = document.querySelectorAll('.wingo-game-tab');
    gameTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const gameType = this.getAttribute('data-game-type');
            if (!gameType) return;
            
            // Update active tab
            gameTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Update current game type
            currentGame.type = gameType;
            
            // Redirect to update the page with new game type
            window.location.href = `wingo_game.php?type=${gameType}`;
        });
    });
    
    // Connect new UI elements to betting functions
    const newBetButtons = document.querySelectorAll('.wingo-bet-button, .wingo-number-bet, .wingo-size-option');
    newBetButtons.forEach(button => {
        button.addEventListener('click', function() {
            const betType = this.getAttribute('data-bet-type');
            const betNumber = this.getAttribute('data-number');
            
            if (betType) {
                currentGame.selectedBetType = betType;
                currentGame.selectedBetValue = null;
            } else if (betNumber) {
                currentGame.selectedBetType = 'number';
                currentGame.selectedBetValue = betNumber;
            }
            
            // Highlight selected option
            newBetButtons.forEach(btn => btn.classList.remove('selected'));
            this.classList.add('selected');
            
            updatePotentialWin();
        });
    });
    
    // Connect amount options
    const amountOptions = document.querySelectorAll('.wingo-amount-option');
    amountOptions.forEach(option => {
        option.addEventListener('click', function() {
            amountOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            const amount = parseInt(this.textContent.replace(/[^\d]/g, ''));
            if (!isNaN(amount)) {
                currentGame.betAmount = amount;
                updatePotentialWin();
            }
        });
    });
    
    // Initial update
    updateCountdownDisplay();
});
</script>
</body>
</html>
