<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
$isLoggedIn = isLoggedIn();
$userData = null;

if ($isLoggedIn) {
    $userData = getUserById($_SESSION['user_id']);
}

// Include header
include 'templates/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <h1>Welcome to <span>BDT-WIN</span> Casino</h1>
    <p>Experience the thrill of real-time Wingo games with instant payouts. Join thousands of players winning big daily!</p>
    <div class="hero-buttons">
        <?php if (!$isLoggedIn): ?>
            <a href="register.php" class="btn-3d btn-red">Register Now</a>
            <a href="login.php" class="btn-3d btn-green">Login</a>
        <?php else: ?>
            <a href="wingo_game.php" class="btn-3d btn-red">Play Now</a>
            <a href="deposit.php" class="btn-3d btn-green">Deposit</a>
        <?php endif; ?>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="feature-card">
                    <img src="assets/images/dice.svg" alt="Game Variety">
                    <h3>Exciting Games</h3>
                    <p>Play our popular Wingo games with 1-minute and 30-second modes. Bet on colors, numbers, and more!</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <i class="fa fa-wallet fa-3x"></i>
                    <h3>Fast Payments</h3>
                    <p>Instant deposits and quick withdrawals using popular Bangladesh payment methods like bKash and Nagad.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <i class="fa fa-shield-alt fa-3x"></i>
                    <h3>Secure Platform</h3>
                    <p>Your data and transactions are always secure with our advanced encryption and protection systems.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How to Play Section -->
<section class="how-to-play">
    <div class="container">
        <h2 class="section-title">How to Play</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">1</div>
                    <h4>Register/Login</h4>
                    <p>Create an account or login to access games</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">2</div>
                    <h4>Deposit Funds</h4>
                    <p>Add money to your account using bKash or Nagad</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">3</div>
                    <h4>Place Bets</h4>
                    <p>Choose a game and place your bets</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="step-card">
                    <div class="step-number">4</div>
                    <h4>Win & Withdraw</h4>
                    <p>Collect your winnings and withdraw them anytime</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Game Preview Section -->
<section class="game-preview">
    <div class="container">
        <h2 class="section-title">Our Games</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="game-preview-card">
                    <img src="https://pixabay.com/get/g34adfa88d6b5236aa78c81766589c37ae3327a3637ada7e856283b7a2823c5c8625400d0c1981c058b9d568852cace0d915740b126547f6268cc1d6aa4df9520_1280.jpg" alt="Wingo 1 Minute" class="img-fluid">
                    <div class="game-preview-info">
                        <h3>Wingo 1 Minute</h3>
                        <p>Classic Wingo game with 1-minute rounds. Bet on red/green, big/small, or specific numbers.</p>
                        <a href="wingo_game.php?type=wingo_1min" class="btn-3d btn-red">Play Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="game-preview-card">
                    <img src="https://pixabay.com/get/g10faa99350edc89dc45258ea9279536895bc898b4106ccba13c45917e3f46ea02828d183d76c127bb3395300823e9e639f72a98a908ad026365a880b20aba8e5_1280.jpg" alt="Wingo 30 Seconds" class="img-fluid">
                    <div class="game-preview-info">
                        <h3>Wingo 30 Seconds</h3>
                        <p>Fast-paced Wingo game with 30-second rounds. Quick decisions, quick results!</p>
                        <a href="wingo_game.php?type=wingo_30sec" class="btn-3d btn-green">Play Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials">
    <div class="container">
        <h2 class="section-title">What Our Players Say</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p>"Won 5000 BDT on my first day! The withdraw process was super quick and easy."</p>
                    <div class="testimonial-author">Rahul K.</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p>"The best online casino in Bangladesh. Great games and very responsive support team."</p>
                    <div class="testimonial-author">Fatima M.</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p>"I love the 30-second Wingo game! Perfect for quick plays when I have a short break."</p>
                    <div class="testimonial-author">Kabir A.</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h2>Ready to Start Winning?</h2>
        <p>Join BDT-WIN Casino today and experience the thrill of winning real money!</p>
        <?php if (!$isLoggedIn): ?>
            <a href="register.php" class="btn-3d btn-gold pulse">Register Now</a>
        <?php else: ?>
            <a href="wingo_game.php" class="btn-3d btn-gold pulse">Play Now</a>
        <?php endif; ?>
    </div>
</section>

<?php
// Include footer
include 'templates/footer.php';
?>
